import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import backupF8e9bb from './backup'
/**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::index
 * @see app/Http/Controllers/SettingController.php:12
 * @route '/settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SettingController::update
 * @see app/Http/Controllers/SettingController.php:23
 * @route '/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SettingController::update
 * @see app/Http/Controllers/SettingController.php:23
 * @route '/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::update
 * @see app/Http/Controllers/SettingController.php:23
 * @route '/settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SettingController::update
 * @see app/Http/Controllers/SettingController.php:23
 * @route '/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SettingController::update
 * @see app/Http/Controllers/SettingController.php:23
 * @route '/settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
export const general = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})

general.definition = {
    methods: ["get","head"],
    url: '/settings/general',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
general.url = (options?: RouteQueryOptions) => {
    return general.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
general.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
general.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: general.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
    const generalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: general.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
        generalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: general.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::general
 * @see app/Http/Controllers/SettingController.php:85
 * @route '/settings/general'
 */
        generalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: general.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    general.form = generalForm
/**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
export const academic = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academic.url(options),
    method: 'get',
})

academic.definition = {
    methods: ["get","head"],
    url: '/settings/academic',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
academic.url = (options?: RouteQueryOptions) => {
    return academic.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
academic.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academic.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
academic.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: academic.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
    const academicForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: academic.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
        academicForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academic.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::academic
 * @see app/Http/Controllers/SettingController.php:122
 * @route '/settings/academic'
 */
        academicForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academic.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    academic.form = academicForm
/**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
export const fee = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fee.url(options),
    method: 'get',
})

fee.definition = {
    methods: ["get","head"],
    url: '/settings/fee',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
fee.url = (options?: RouteQueryOptions) => {
    return fee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
fee.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fee.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
fee.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fee.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
    const feeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: fee.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
        feeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fee.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::fee
 * @see app/Http/Controllers/SettingController.php:139
 * @route '/settings/fee'
 */
        feeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fee.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    fee.form = feeForm
/**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
export const email = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: email.url(options),
    method: 'get',
})

email.definition = {
    methods: ["get","head"],
    url: '/settings/email',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
email.url = (options?: RouteQueryOptions) => {
    return email.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
email.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: email.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
email.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: email.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
    const emailForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: email.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
        emailForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: email.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::email
 * @see app/Http/Controllers/SettingController.php:155
 * @route '/settings/email'
 */
        emailForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: email.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    email.form = emailForm
/**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
export const notification = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notification.url(options),
    method: 'get',
})

notification.definition = {
    methods: ["get","head"],
    url: '/settings/notification',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
notification.url = (options?: RouteQueryOptions) => {
    return notification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
notification.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notification.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
notification.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: notification.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
    const notificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: notification.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
        notificationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notification.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::notification
 * @see app/Http/Controllers/SettingController.php:174
 * @route '/settings/notification'
 */
        notificationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notification.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    notification.form = notificationForm
/**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
export const backup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: backup.url(options),
    method: 'get',
})

backup.definition = {
    methods: ["get","head"],
    url: '/settings/backup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
backup.url = (options?: RouteQueryOptions) => {
    return backup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
backup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: backup.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
backup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: backup.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
    const backupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: backup.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
        backupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: backup.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SettingController::backup
 * @see app/Http/Controllers/SettingController.php:191
 * @route '/settings/backup'
 */
        backupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: backup.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    backup.form = backupForm
const settings = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
general: Object.assign(general, general),
academic: Object.assign(academic, academic),
fee: Object.assign(fee, fee),
email: Object.assign(email, email),
notification: Object.assign(notification, notification),
backup: Object.assign(backup, backupF8e9bb),
}

export default settings