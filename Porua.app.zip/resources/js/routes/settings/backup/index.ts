import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SettingController::create
 * @see app/Http/Controllers/SettingController.php:198
 * @route '/settings/backup/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

create.definition = {
    methods: ["post"],
    url: '/settings/backup/create',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SettingController::create
 * @see app/Http/Controllers/SettingController.php:198
 * @route '/settings/backup/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SettingController::create
 * @see app/Http/Controllers/SettingController.php:198
 * @route '/settings/backup/create'
 */
create.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SettingController::create
 * @see app/Http/Controllers/SettingController.php:198
 * @route '/settings/backup/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: create.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SettingController::create
 * @see app/Http/Controllers/SettingController.php:198
 * @route '/settings/backup/create'
 */
        createForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: create.url(options),
            method: 'post',
        })
    
    create.form = createForm
const backup = {
    create: Object.assign(create, create),
}

export default backup