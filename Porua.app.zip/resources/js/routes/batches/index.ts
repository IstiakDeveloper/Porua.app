import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/batches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchController::index
 * @see app/Http/Controllers/Coaching/BatchController.php:15
 * @route '/batches'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/batches/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchController::create
 * @see app/Http/Controllers/Coaching/BatchController.php:57
 * @route '/batches/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::store
 * @see app/Http/Controllers/Coaching/BatchController.php:71
 * @route '/batches'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/batches',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::store
 * @see app/Http/Controllers/Coaching/BatchController.php:71
 * @route '/batches'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::store
 * @see app/Http/Controllers/Coaching/BatchController.php:71
 * @route '/batches'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::store
 * @see app/Http/Controllers/Coaching/BatchController.php:71
 * @route '/batches'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::store
 * @see app/Http/Controllers/Coaching/BatchController.php:71
 * @route '/batches'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
export const show = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/batches/{batch}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
show.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return show.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
show.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
show.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
    const showForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
        showForm.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchController::show
 * @see app/Http/Controllers/Coaching/BatchController.php:98
 * @route '/batches/{batch}'
 */
        showForm.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
export const edit = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/batches/{batch}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
edit.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return edit.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
edit.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
edit.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
    const editForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
        editForm.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchController::edit
 * @see app/Http/Controllers/Coaching/BatchController.php:143
 * @route '/batches/{batch}/edit'
 */
        editForm.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
export const update = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/batches/{batch}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
update.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return update.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
update.put = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
update.patch = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
    const updateForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
        updateForm.put = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchController::update
 * @see app/Http/Controllers/Coaching/BatchController.php:157
 * @route '/batches/{batch}'
 */
        updateForm.patch = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Coaching\BatchController::destroy
 * @see app/Http/Controllers/Coaching/BatchController.php:184
 * @route '/batches/{batch}'
 */
export const destroy = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/batches/{batch}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Coaching\BatchController::destroy
 * @see app/Http/Controllers/Coaching/BatchController.php:184
 * @route '/batches/{batch}'
 */
destroy.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return destroy.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchController::destroy
 * @see app/Http/Controllers/Coaching/BatchController.php:184
 * @route '/batches/{batch}'
 */
destroy.delete = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchController::destroy
 * @see app/Http/Controllers/Coaching/BatchController.php:184
 * @route '/batches/{batch}'
 */
    const destroyForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchController::destroy
 * @see app/Http/Controllers/Coaching/BatchController.php:184
 * @route '/batches/{batch}'
 */
        destroyForm.delete = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const batches = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default batches