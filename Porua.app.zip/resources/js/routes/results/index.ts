import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import tabulationB70fc4 from './tabulation'
/**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
export const tabulation = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tabulation.url(options),
    method: 'get',
})

tabulation.definition = {
    methods: ["get","head"],
    url: '/results/tabulation',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
tabulation.url = (options?: RouteQueryOptions) => {
    return tabulation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
tabulation.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tabulation.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
tabulation.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tabulation.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
    const tabulationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tabulation.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
        tabulationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tabulation.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ResultController::tabulation
 * @see app/Http/Controllers/Exam/ResultController.php:105
 * @route '/results/tabulation'
 */
        tabulationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tabulation.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tabulation.form = tabulationForm
/**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/results',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ResultController::index
 * @see app/Http/Controllers/Exam/ResultController.php:23
 * @route '/results'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
export const show = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/results/{result}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
show.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return show.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
show.get = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
show.head = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
    const showForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
        showForm.get = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ResultController::show
 * @see app/Http/Controllers/Exam/ResultController.php:88
 * @route '/results/{result}'
 */
        showForm.head = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Exam\ResultController::destroy
 * @see app/Http/Controllers/Exam/ResultController.php:222
 * @route '/results/{result}'
 */
export const destroy = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/results/{result}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::destroy
 * @see app/Http/Controllers/Exam/ResultController.php:222
 * @route '/results/{result}'
 */
destroy.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return destroy.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::destroy
 * @see app/Http/Controllers/Exam/ResultController.php:222
 * @route '/results/{result}'
 */
destroy.delete = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::destroy
 * @see app/Http/Controllers/Exam/ResultController.php:222
 * @route '/results/{result}'
 */
    const destroyForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::destroy
 * @see app/Http/Controllers/Exam/ResultController.php:222
 * @route '/results/{result}'
 */
        destroyForm.delete = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Exam\ResultController::generate
 * @see app/Http/Controllers/Exam/ResultController.php:43
 * @route '/results/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/results/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::generate
 * @see app/Http/Controllers/Exam/ResultController.php:43
 * @route '/results/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::generate
 * @see app/Http/Controllers/Exam/ResultController.php:43
 * @route '/results/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::generate
 * @see app/Http/Controllers/Exam/ResultController.php:43
 * @route '/results/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::generate
 * @see app/Http/Controllers/Exam/ResultController.php:43
 * @route '/results/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Exam\ResultController::publish
 * @see app/Http/Controllers/Exam/ResultController.php:70
 * @route '/results/publish'
 */
export const publish = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/results/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::publish
 * @see app/Http/Controllers/Exam/ResultController.php:70
 * @route '/results/publish'
 */
publish.url = (options?: RouteQueryOptions) => {
    return publish.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::publish
 * @see app/Http/Controllers/Exam/ResultController.php:70
 * @route '/results/publish'
 */
publish.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::publish
 * @see app/Http/Controllers/Exam/ResultController.php:70
 * @route '/results/publish'
 */
    const publishForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::publish
 * @see app/Http/Controllers/Exam/ResultController.php:70
 * @route '/results/publish'
 */
        publishForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
export const student = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})

student.definition = {
    methods: ["get","head"],
    url: '/students/{student}/exams/{exam}/result',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
student.url = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                    exam: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: args.student,
                                exam: args.exam,
                }

    return student.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace('{exam}', parsedArgs.exam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
student.get = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
student.head = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: student.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
    const studentForm = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: student.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
        studentForm.get = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ResultController::student
 * @see app/Http/Controllers/Exam/ResultController.php:0
 * @route '/students/{student}/exams/{exam}/result'
 */
        studentForm.head = (args: { student: string | number, exam: string | number } | [student: string | number, exam: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    student.form = studentForm
/**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
export const print = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/results/{result}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
print.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return print.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
print.get = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
print.head = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
    const printForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: print.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
        printForm.get = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ResultController::print
 * @see app/Http/Controllers/Exam/ResultController.php:174
 * @route '/results/{result}/print'
 */
        printForm.head = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    print.form = printForm
const results = {
    tabulation: Object.assign(tabulation, tabulationB70fc4),
index: Object.assign(index, index),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
generate: Object.assign(generate, generate),
publish: Object.assign(publish, publish),
student: Object.assign(student, student),
print: Object.assign(print, print),
}

export default results