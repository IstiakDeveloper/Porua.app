import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/fee-structures',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::index
 * @see app/Http/Controllers/Fee/FeeStructureController.php:15
 * @route '/fee-structures'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/fee-structures/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::create
 * @see app/Http/Controllers/Fee/FeeStructureController.php:34
 * @route '/fee-structures/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::store
 * @see app/Http/Controllers/Fee/FeeStructureController.php:45
 * @route '/fee-structures'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/fee-structures',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::store
 * @see app/Http/Controllers/Fee/FeeStructureController.php:45
 * @route '/fee-structures'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::store
 * @see app/Http/Controllers/Fee/FeeStructureController.php:45
 * @route '/fee-structures'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::store
 * @see app/Http/Controllers/Fee/FeeStructureController.php:45
 * @route '/fee-structures'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::store
 * @see app/Http/Controllers/Fee/FeeStructureController.php:45
 * @route '/fee-structures'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
export const edit = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/fee-structures/{fee_structure}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
edit.url = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_structure: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_structure: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_structure: args.fee_structure,
                }

    return edit.definition.url
            .replace('{fee_structure}', parsedArgs.fee_structure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
edit.get = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
edit.head = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
    const editForm = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
        editForm.get = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::edit
 * @see app/Http/Controllers/Fee/FeeStructureController.php:67
 * @route '/fee-structures/{fee_structure}/edit'
 */
        editForm.head = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
export const update = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/fee-structures/{fee_structure}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
update.url = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_structure: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_structure: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_structure: args.fee_structure,
                }

    return update.definition.url
            .replace('{fee_structure}', parsedArgs.fee_structure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
update.put = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
update.patch = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
    const updateForm = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
        updateForm.put = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::update
 * @see app/Http/Controllers/Fee/FeeStructureController.php:81
 * @route '/fee-structures/{fee_structure}'
 */
        updateForm.patch = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Fee\FeeStructureController::destroy
 * @see app/Http/Controllers/Fee/FeeStructureController.php:103
 * @route '/fee-structures/{fee_structure}'
 */
export const destroy = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/fee-structures/{fee_structure}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::destroy
 * @see app/Http/Controllers/Fee/FeeStructureController.php:103
 * @route '/fee-structures/{fee_structure}'
 */
destroy.url = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_structure: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_structure: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_structure: args.fee_structure,
                }

    return destroy.definition.url
            .replace('{fee_structure}', parsedArgs.fee_structure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeStructureController::destroy
 * @see app/Http/Controllers/Fee/FeeStructureController.php:103
 * @route '/fee-structures/{fee_structure}'
 */
destroy.delete = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Fee\FeeStructureController::destroy
 * @see app/Http/Controllers/Fee/FeeStructureController.php:103
 * @route '/fee-structures/{fee_structure}'
 */
    const destroyForm = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeStructureController::destroy
 * @see app/Http/Controllers/Fee/FeeStructureController.php:103
 * @route '/fee-structures/{fee_structure}'
 */
        destroyForm.delete = (args: { fee_structure: string | number } | [fee_structure: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const feeStructures = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default feeStructures