import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
export const attendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})

attendance.definition = {
    methods: ["get","head"],
    url: '/reports/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendance.url = (options?: RouteQueryOptions) => {
    return attendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
    const attendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
        attendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::attendance
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
        attendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendance.form = attendanceForm
/**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
export const fees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fees.url(options),
    method: 'get',
})

fees.definition = {
    methods: ["get","head"],
    url: '/reports/fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
fees.url = (options?: RouteQueryOptions) => {
    return fees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
fees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
fees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
    const feesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: fees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
        feesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::fees
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
        feesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    fees.form = feesForm
/**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
export const academic = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academic.url(options),
    method: 'get',
})

academic.definition = {
    methods: ["get","head"],
    url: '/reports/academic',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academic.url = (options?: RouteQueryOptions) => {
    return academic.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academic.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academic.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academic.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: academic.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
    const academicForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: academic.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
        academicForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academic.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::academic
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
        academicForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academic.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    academic.form = academicForm
/**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
export const student = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})

student.definition = {
    methods: ["get","head"],
    url: '/reports/student/{student}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
student.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return student.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
student.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
student.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: student.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
    const studentForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: student.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
        studentForm.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::student
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
        studentForm.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    student.form = studentForm
/**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
export const teacher = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacher.url(args, options),
    method: 'get',
})

teacher.definition = {
    methods: ["get","head"],
    url: '/reports/teacher/{teacher}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacher.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return teacher.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacher.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacher.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacher.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: teacher.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
    const teacherForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: teacher.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
        teacherForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacher.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::teacher
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
        teacherForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacher.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    teacher.form = teacherForm
/**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
export const classMethod = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classMethod.url(args, options),
    method: 'get',
})

classMethod.definition = {
    methods: ["get","head"],
    url: '/reports/class/{class}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classMethod.url = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { class: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { class: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    class: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        class: typeof args.class === 'object'
                ? args.class.id
                : args.class,
                }

    return classMethod.definition.url
            .replace('{class}', parsedArgs.class.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classMethod.get = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classMethod.head = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
    const classMethodForm = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: classMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
        classMethodForm.get = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::classMethod
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
        classMethodForm.head = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    classMethod.form = classMethodForm
/**
* @see \App\Http\Controllers\ReportController::exportMethod
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(options),
    method: 'post',
})

exportMethod.definition = {
    methods: ["post"],
    url: '/reports/export',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::exportMethod
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::exportMethod
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
exportMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::exportMethod
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: exportMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::exportMethod
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
        exportMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: exportMethod.url(options),
            method: 'post',
        })
    
    exportMethod.form = exportMethodForm
const reports = {
    index: Object.assign(index, index),
attendance: Object.assign(attendance, attendance),
fees: Object.assign(fees, fees),
academic: Object.assign(academic, academic),
student: Object.assign(student, student),
teacher: Object.assign(teacher, teacher),
class: Object.assign(classMethod, classMethod),
export: Object.assign(exportMethod, exportMethod),
}

export default reports