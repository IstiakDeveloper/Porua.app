import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
export const students = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})

students.definition = {
    methods: ["get","head"],
    url: '/student-promotions/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
students.url = (options?: RouteQueryOptions) => {
    return students.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
students.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
students.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: students.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
    const studentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: students.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
        studentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::students
 * @see app/Http/Controllers/Student/StudentPromotionController.php:108
 * @route '/student-promotions/students'
 */
        studentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    students.form = studentsForm
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student-promotions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::index
 * @see app/Http/Controllers/Student/StudentPromotionController.php:17
 * @route '/student-promotions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/student-promotions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::create
 * @see app/Http/Controllers/Student/StudentPromotionController.php:40
 * @route '/student-promotions/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::store
 * @see app/Http/Controllers/Student/StudentPromotionController.php:50
 * @route '/student-promotions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student-promotions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::store
 * @see app/Http/Controllers/Student/StudentPromotionController.php:50
 * @route '/student-promotions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::store
 * @see app/Http/Controllers/Student/StudentPromotionController.php:50
 * @route '/student-promotions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::store
 * @see app/Http/Controllers/Student/StudentPromotionController.php:50
 * @route '/student-promotions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::store
 * @see app/Http/Controllers/Student/StudentPromotionController.php:50
 * @route '/student-promotions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
export const show = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student-promotions/{student_promotion}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
show.url = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_promotion: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_promotion: args.student_promotion,
                }

    return show.definition.url
            .replace('{student_promotion}', parsedArgs.student_promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
show.get = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
show.head = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
    const showForm = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
        showForm.get = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::show
 * @see app/Http/Controllers/Student/StudentPromotionController.php:0
 * @route '/student-promotions/{student_promotion}'
 */
        showForm.head = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Student\StudentPromotionController::destroy
 * @see app/Http/Controllers/Student/StudentPromotionController.php:134
 * @route '/student-promotions/{student_promotion}'
 */
export const destroy = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/student-promotions/{student_promotion}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::destroy
 * @see app/Http/Controllers/Student/StudentPromotionController.php:134
 * @route '/student-promotions/{student_promotion}'
 */
destroy.url = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_promotion: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_promotion: args.student_promotion,
                }

    return destroy.definition.url
            .replace('{student_promotion}', parsedArgs.student_promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentPromotionController::destroy
 * @see app/Http/Controllers/Student/StudentPromotionController.php:134
 * @route '/student-promotions/{student_promotion}'
 */
destroy.delete = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Student\StudentPromotionController::destroy
 * @see app/Http/Controllers/Student/StudentPromotionController.php:134
 * @route '/student-promotions/{student_promotion}'
 */
    const destroyForm = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentPromotionController::destroy
 * @see app/Http/Controllers/Student/StudentPromotionController.php:134
 * @route '/student-promotions/{student_promotion}'
 */
        destroyForm.delete = (args: { student_promotion: string | number } | [student_promotion: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const studentPromotions = {
    students: Object.assign(students, students),
index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
}

export default studentPromotions