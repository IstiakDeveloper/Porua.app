import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/salary-payments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::index
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:28
 * @route '/salary-payments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::store
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:124
 * @route '/salary-payments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/salary-payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::store
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:124
 * @route '/salary-payments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::store
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:124
 * @route '/salary-payments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::store
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:124
 * @route '/salary-payments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::store
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:124
 * @route '/salary-payments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulk
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:356
 * @route '/salary-payments/bulk'
 */
export const bulk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulk.url(options),
    method: 'post',
})

bulk.definition = {
    methods: ["post"],
    url: '/salary-payments/bulk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulk
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:356
 * @route '/salary-payments/bulk'
 */
bulk.url = (options?: RouteQueryOptions) => {
    return bulk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulk
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:356
 * @route '/salary-payments/bulk'
 */
bulk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulk
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:356
 * @route '/salary-payments/bulk'
 */
    const bulkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulk
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:356
 * @route '/salary-payments/bulk'
 */
        bulkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulk.url(options),
            method: 'post',
        })
    
    bulk.form = bulkForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulkChangeMonth
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:533
 * @route '/salary-payments/bulk-change-month'
 */
export const bulkChangeMonth = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkChangeMonth.url(options),
    method: 'post',
})

bulkChangeMonth.definition = {
    methods: ["post"],
    url: '/salary-payments/bulk-change-month',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulkChangeMonth
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:533
 * @route '/salary-payments/bulk-change-month'
 */
bulkChangeMonth.url = (options?: RouteQueryOptions) => {
    return bulkChangeMonth.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulkChangeMonth
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:533
 * @route '/salary-payments/bulk-change-month'
 */
bulkChangeMonth.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkChangeMonth.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulkChangeMonth
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:533
 * @route '/salary-payments/bulk-change-month'
 */
    const bulkChangeMonthForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkChangeMonth.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::bulkChangeMonth
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:533
 * @route '/salary-payments/bulk-change-month'
 */
        bulkChangeMonthForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkChangeMonth.url(options),
            method: 'post',
        })
    
    bulkChangeMonth.form = bulkChangeMonthForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
export const edit = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/salary-payments/{payment}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
edit.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return edit.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
edit.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
edit.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
    const editForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
        editForm.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::edit
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:210
 * @route '/salary-payments/{payment}/edit'
 */
        editForm.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::update
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:228
 * @route '/salary-payments/{payment}'
 */
export const update = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/salary-payments/{payment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::update
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:228
 * @route '/salary-payments/{payment}'
 */
update.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return update.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::update
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:228
 * @route '/salary-payments/{payment}'
 */
update.put = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::update
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:228
 * @route '/salary-payments/{payment}'
 */
    const updateForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::update
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:228
 * @route '/salary-payments/{payment}'
 */
        updateForm.put = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
export const show = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/salary-payments/{payment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
show.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return show.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
show.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
show.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
    const showForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
        showForm.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::show
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:325
 * @route '/salary-payments/{payment}'
 */
        showForm.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::destroy
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:337
 * @route '/salary-payments/{payment}'
 */
export const destroy = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/salary-payments/{payment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::destroy
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:337
 * @route '/salary-payments/{payment}'
 */
destroy.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return destroy.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::destroy
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:337
 * @route '/salary-payments/{payment}'
 */
destroy.delete = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::destroy
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:337
 * @route '/salary-payments/{payment}'
 */
    const destroyForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\SalaryPaymentController::destroy
 * @see app/Http/Controllers/Salary/SalaryPaymentController.php:337
 * @route '/salary-payments/{payment}'
 */
        destroyForm.delete = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const salaryPayments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
bulk: Object.assign(bulk, bulk),
bulkChangeMonth: Object.assign(bulkChangeMonth, bulkChangeMonth),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
}

export default salaryPayments