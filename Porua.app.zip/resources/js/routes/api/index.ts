import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import coaching from './coaching'
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
export const feeStructures = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feeStructures.url(options),
    method: 'get',
})

feeStructures.definition = {
    methods: ["get","head"],
    url: '/api/fee-structures',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
feeStructures.url = (options?: RouteQueryOptions) => {
    return feeStructures.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
feeStructures.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feeStructures.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
feeStructures.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: feeStructures.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
    const feeStructuresForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: feeStructures.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
        feeStructuresForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: feeStructures.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::feeStructures
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:865
 * @route '/api/fee-structures'
 */
        feeStructuresForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: feeStructures.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    feeStructures.form = feeStructuresForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
export const studentDues = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentDues.url(options),
    method: 'get',
})

studentDues.definition = {
    methods: ["get","head"],
    url: '/api/fee-collections/student-dues',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
studentDues.url = (options?: RouteQueryOptions) => {
    return studentDues.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
studentDues.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentDues.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
studentDues.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: studentDues.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
    const studentDuesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: studentDues.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
        studentDuesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentDues.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:903
 * @route '/api/fee-collections/student-dues'
 */
        studentDuesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentDues.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    studentDues.form = studentDuesForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
export const resyncStudentDues = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resyncStudentDues.url(options),
    method: 'get',
})

resyncStudentDues.definition = {
    methods: ["get","post","head"],
    url: '/api/fee-collections/resync-student-dues',
} satisfies RouteDefinition<["get","post","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
resyncStudentDues.url = (options?: RouteQueryOptions) => {
    return resyncStudentDues.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
resyncStudentDues.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resyncStudentDues.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
resyncStudentDues.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resyncStudentDues.url(options),
    method: 'post',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
resyncStudentDues.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resyncStudentDues.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
    const resyncStudentDuesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resyncStudentDues.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
        resyncStudentDuesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resyncStudentDues.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
        resyncStudentDuesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resyncStudentDues.url(options),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::resyncStudentDues
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:1093
 * @route '/api/fee-collections/resync-student-dues'
 */
        resyncStudentDuesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resyncStudentDues.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resyncStudentDues.form = resyncStudentDuesForm
const api = {
    coaching: Object.assign(coaching, coaching),
feeStructures: Object.assign(feeStructures, feeStructures),
studentDues: Object.assign(studentDues, studentDues),
resyncStudentDues: Object.assign(resyncStudentDues, resyncStudentDues),
}

export default api