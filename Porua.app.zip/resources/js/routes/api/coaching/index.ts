import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
export const searchStudents = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchStudents.url(options),
    method: 'get',
})

searchStudents.definition = {
    methods: ["get","head"],
    url: '/api/coaching/search-students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
searchStudents.url = (options?: RouteQueryOptions) => {
    return searchStudents.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
searchStudents.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchStudents.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
searchStudents.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchStudents.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
    const searchStudentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: searchStudents.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
        searchStudentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchStudents.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchEnrollmentController::searchStudents
 * @see app/Http/Controllers/Coaching/BatchEnrollmentController.php:105
 * @route '/api/coaching/search-students'
 */
        searchStudentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchStudents.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    searchStudents.form = searchStudentsForm
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
export const enrollment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enrollment.url(options),
    method: 'get',
})

enrollment.definition = {
    methods: ["get","head"],
    url: '/api/coaching/enrollment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
enrollment.url = (options?: RouteQueryOptions) => {
    return enrollment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
enrollment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enrollment.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
enrollment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: enrollment.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
    const enrollmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: enrollment.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
        enrollmentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enrollment.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::enrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
        enrollmentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enrollment.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    enrollment.form = enrollmentForm
const coaching = {
    searchStudents: Object.assign(searchStudents, searchStudents),
enrollment: Object.assign(enrollment, enrollment),
}

export default coaching