import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/activity-logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:12
 * @route '/activity-logs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
export const show = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/activity-logs/{activity_log}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
show.url = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activity_log: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    activity_log: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        activity_log: args.activity_log,
                }

    return show.definition.url
            .replace('{activity_log}', parsedArgs.activity_log.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
show.get = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
show.head = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
    const showForm = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
        showForm.get = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:31
 * @route '/activity-logs/{activity_log}'
 */
        showForm.head = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ActivityLogController::destroy
 * @see app/Http/Controllers/ActivityLogController.php:42
 * @route '/activity-logs/{activity_log}'
 */
export const destroy = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/activity-logs/{activity_log}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ActivityLogController::destroy
 * @see app/Http/Controllers/ActivityLogController.php:42
 * @route '/activity-logs/{activity_log}'
 */
destroy.url = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activity_log: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    activity_log: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        activity_log: args.activity_log,
                }

    return destroy.definition.url
            .replace('{activity_log}', parsedArgs.activity_log.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::destroy
 * @see app/Http/Controllers/ActivityLogController.php:42
 * @route '/activity-logs/{activity_log}'
 */
destroy.delete = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::destroy
 * @see app/Http/Controllers/ActivityLogController.php:42
 * @route '/activity-logs/{activity_log}'
 */
    const destroyForm = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::destroy
 * @see app/Http/Controllers/ActivityLogController.php:42
 * @route '/activity-logs/{activity_log}'
 */
        destroyForm.delete = (args: { activity_log: string | number } | [activity_log: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ActivityLogController::clear
 * @see app/Http/Controllers/ActivityLogController.php:51
 * @route '/activity-logs/clear'
 */
export const clear = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear.url(options),
    method: 'post',
})

clear.definition = {
    methods: ["post"],
    url: '/activity-logs/clear',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ActivityLogController::clear
 * @see app/Http/Controllers/ActivityLogController.php:51
 * @route '/activity-logs/clear'
 */
clear.url = (options?: RouteQueryOptions) => {
    return clear.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::clear
 * @see app/Http/Controllers/ActivityLogController.php:51
 * @route '/activity-logs/clear'
 */
clear.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::clear
 * @see app/Http/Controllers/ActivityLogController.php:51
 * @route '/activity-logs/clear'
 */
    const clearForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::clear
 * @see app/Http/Controllers/ActivityLogController.php:51
 * @route '/activity-logs/clear'
 */
        clearForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear.url(options),
            method: 'post',
        })
    
    clear.form = clearForm
const activityLogs = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
clear: Object.assign(clear, clear),
}

export default activityLogs