import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
export const wizard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wizard.url(options),
    method: 'get',
})

wizard.definition = {
    methods: ["get","head"],
    url: '/setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
wizard.url = (options?: RouteQueryOptions) => {
    return wizard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
wizard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wizard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
wizard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: wizard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
    const wizardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: wizard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
        wizardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: wizard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OnboardingController::wizard
 * @see app/Http/Controllers/OnboardingController.php:20
 * @route '/setup'
 */
        wizardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: wizard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    wizard.form = wizardForm
/**
* @see \App\Http\Controllers\OnboardingController::save
 * @see app/Http/Controllers/OnboardingController.php:70
 * @route '/setup'
 */
export const save = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(options),
    method: 'post',
})

save.definition = {
    methods: ["post"],
    url: '/setup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OnboardingController::save
 * @see app/Http/Controllers/OnboardingController.php:70
 * @route '/setup'
 */
save.url = (options?: RouteQueryOptions) => {
    return save.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OnboardingController::save
 * @see app/Http/Controllers/OnboardingController.php:70
 * @route '/setup'
 */
save.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OnboardingController::save
 * @see app/Http/Controllers/OnboardingController.php:70
 * @route '/setup'
 */
    const saveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: save.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OnboardingController::save
 * @see app/Http/Controllers/OnboardingController.php:70
 * @route '/setup'
 */
        saveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: save.url(options),
            method: 'post',
        })
    
    save.form = saveForm
const onboarding = {
    wizard: Object.assign(wizard, wizard),
save: Object.assign(save, save),
}

export default onboarding