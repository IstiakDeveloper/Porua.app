import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/fee-collections/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::create
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/fee-collections',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::index
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:28
 * @route '/fee-collections'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::store
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:307
 * @route '/fee-collections'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/fee-collections',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::store
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:307
 * @route '/fee-collections'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::store
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:307
 * @route '/fee-collections'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::store
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:307
 * @route '/fee-collections'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::store
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:307
 * @route '/fee-collections'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
export const edit = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/fee-collections/{fee_collection}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
edit.url = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_collection: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_collection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_collection: args.fee_collection,
                }

    return edit.definition.url
            .replace('{fee_collection}', parsedArgs.fee_collection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
edit.get = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
edit.head = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
    const editForm = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
        editForm.get = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::edit
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:591
 * @route '/fee-collections/{fee_collection}/edit'
 */
        editForm.head = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
export const update = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/fee-collections/{fee_collection}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
update.url = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_collection: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_collection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_collection: args.fee_collection,
                }

    return update.definition.url
            .replace('{fee_collection}', parsedArgs.fee_collection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
update.put = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
update.patch = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
    const updateForm = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
        updateForm.put = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::update
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:641
 * @route '/fee-collections/{fee_collection}'
 */
        updateForm.patch = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::destroy
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:824
 * @route '/fee-collections/{fee_collection}'
 */
export const destroy = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/fee-collections/{fee_collection}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::destroy
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:824
 * @route '/fee-collections/{fee_collection}'
 */
destroy.url = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_collection: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_collection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_collection: args.fee_collection,
                }

    return destroy.definition.url
            .replace('{fee_collection}', parsedArgs.fee_collection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::destroy
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:824
 * @route '/fee-collections/{fee_collection}'
 */
destroy.delete = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::destroy
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:824
 * @route '/fee-collections/{fee_collection}'
 */
    const destroyForm = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::destroy
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:824
 * @route '/fee-collections/{fee_collection}'
 */
        destroyForm.delete = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
export const studentFees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentFees.url(options),
    method: 'get',
})

studentFees.definition = {
    methods: ["get","head"],
    url: '/fee-collections/student-fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
studentFees.url = (options?: RouteQueryOptions) => {
    return studentFees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
studentFees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentFees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
studentFees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: studentFees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
    const studentFeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: studentFees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
        studentFeesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentFees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::studentFees
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:235
 * @route '/fee-collections/student-fees'
 */
        studentFeesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentFees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    studentFees.form = studentFeesForm
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
export const receipt = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

receipt.definition = {
    methods: ["get","head"],
    url: '/fee-collections/{fee_collection}/receipt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
receipt.url = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_collection: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_collection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_collection: args.fee_collection,
                }

    return receipt.definition.url
            .replace('{fee_collection}', parsedArgs.fee_collection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
receipt.get = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
receipt.head = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipt.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
    const receiptForm = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: receipt.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
        receiptForm.get = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receipt.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeCollectionController::receipt
 * @see app/Http/Controllers/Fee/FeeCollectionController.php:795
 * @route '/fee-collections/{fee_collection}/receipt'
 */
        receiptForm.head = (args: { fee_collection: string | number } | [fee_collection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receipt.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    receipt.form = receiptForm
const feeCollections = {
    create: Object.assign(create, create),
index: Object.assign(index, index),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
studentFees: Object.assign(studentFees, studentFees),
receipt: Object.assign(receipt, receipt),
}

export default feeCollections