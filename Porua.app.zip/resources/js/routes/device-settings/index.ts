import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import update603324 from './update'
/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/device-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/device-settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DeviceSettingController::test
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
export const test = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/device-settings/test-connection',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::test
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
test.url = (options?: RouteQueryOptions) => {
    return test.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::test
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
test.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::test
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
    const testForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::test
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
        testForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(options),
            method: 'post',
        })
    
    test.form = testForm
const deviceSettings = {
    index: Object.assign(index, index),
update: Object.assign(update, update603324),
test: Object.assign(test, test),
}

export default deviceSettings