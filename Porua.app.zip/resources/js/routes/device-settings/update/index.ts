import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DeviceSettingController::device
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
export const device = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: device.url(options),
    method: 'put',
})

device.definition = {
    methods: ["put"],
    url: '/device-settings/device',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::device
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
device.url = (options?: RouteQueryOptions) => {
    return device.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::device
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
device.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: device.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::device
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
    const deviceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: device.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::device
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
        deviceForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: device.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    device.form = deviceForm
/**
* @see \App\Http\Controllers\DeviceSettingController::teacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
export const teacher = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: teacher.url(options),
    method: 'put',
})

teacher.definition = {
    methods: ["put"],
    url: '/device-settings/teacher',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::teacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
teacher.url = (options?: RouteQueryOptions) => {
    return teacher.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::teacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
teacher.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: teacher.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::teacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
    const teacherForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: teacher.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::teacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
        teacherForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: teacher.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    teacher.form = teacherForm
/**
* @see \App\Http\Controllers\DeviceSettingController::student
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
export const student = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: student.url(options),
    method: 'put',
})

student.definition = {
    methods: ["put"],
    url: '/device-settings/student',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::student
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
student.url = (options?: RouteQueryOptions) => {
    return student.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::student
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
student.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: student.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::student
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
    const studentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: student.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::student
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
        studentForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: student.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    student.form = studentForm
/**
* @see \App\Http\Controllers\DeviceSettingController::weekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
export const weekend = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: weekend.url(options),
    method: 'put',
})

weekend.definition = {
    methods: ["put"],
    url: '/device-settings/weekend',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::weekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
weekend.url = (options?: RouteQueryOptions) => {
    return weekend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::weekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
weekend.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: weekend.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::weekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
    const weekendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: weekend.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::weekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
        weekendForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: weekend.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    weekend.form = weekendForm
/**
* @see \App\Http\Controllers\DeviceSettingController::automation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
export const automation = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: automation.url(options),
    method: 'put',
})

automation.definition = {
    methods: ["put"],
    url: '/device-settings/automation',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::automation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
automation.url = (options?: RouteQueryOptions) => {
    return automation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::automation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
automation.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: automation.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::automation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
    const automationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: automation.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::automation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
        automationForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: automation.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    automation.form = automationForm
const update = {
    device: Object.assign(device, device),
teacher: Object.assign(teacher, teacher),
student: Object.assign(student, student),
weekend: Object.assign(weekend, weekend),
automation: Object.assign(automation, automation),
}

export default update