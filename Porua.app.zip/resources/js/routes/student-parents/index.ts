import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student-parents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentParentController::index
 * @see app/Http/Controllers/Student/StudentParentController.php:16
 * @route '/student-parents'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/student-parents/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentParentController::create
 * @see app/Http/Controllers/Student/StudentParentController.php:34
 * @route '/student-parents/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::store
 * @see app/Http/Controllers/Student/StudentParentController.php:43
 * @route '/student-parents'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student-parents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::store
 * @see app/Http/Controllers/Student/StudentParentController.php:43
 * @route '/student-parents'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::store
 * @see app/Http/Controllers/Student/StudentParentController.php:43
 * @route '/student-parents'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::store
 * @see app/Http/Controllers/Student/StudentParentController.php:43
 * @route '/student-parents'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::store
 * @see app/Http/Controllers/Student/StudentParentController.php:43
 * @route '/student-parents'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
export const show = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student-parents/{student_parent}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
show.url = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_parent: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_parent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_parent: args.student_parent,
                }

    return show.definition.url
            .replace('{student_parent}', parsedArgs.student_parent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
show.get = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
show.head = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
    const showForm = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
        showForm.get = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentParentController::show
 * @see app/Http/Controllers/Student/StudentParentController.php:108
 * @route '/student-parents/{student_parent}'
 */
        showForm.head = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
export const edit = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/student-parents/{student_parent}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
edit.url = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_parent: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_parent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_parent: args.student_parent,
                }

    return edit.definition.url
            .replace('{student_parent}', parsedArgs.student_parent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
edit.get = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
edit.head = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
    const editForm = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
        editForm.get = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentParentController::edit
 * @see app/Http/Controllers/Student/StudentParentController.php:119
 * @route '/student-parents/{student_parent}/edit'
 */
        editForm.head = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
export const update = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/student-parents/{student_parent}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
update.url = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_parent: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_parent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_parent: args.student_parent,
                }

    return update.definition.url
            .replace('{student_parent}', parsedArgs.student_parent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
update.put = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
update.patch = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
    const updateForm = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
        updateForm.put = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Student\StudentParentController::update
 * @see app/Http/Controllers/Student/StudentParentController.php:131
 * @route '/student-parents/{student_parent}'
 */
        updateForm.patch = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Student\StudentParentController::destroy
 * @see app/Http/Controllers/Student/StudentParentController.php:189
 * @route '/student-parents/{student_parent}'
 */
export const destroy = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/student-parents/{student_parent}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Student\StudentParentController::destroy
 * @see app/Http/Controllers/Student/StudentParentController.php:189
 * @route '/student-parents/{student_parent}'
 */
destroy.url = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_parent: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_parent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_parent: args.student_parent,
                }

    return destroy.definition.url
            .replace('{student_parent}', parsedArgs.student_parent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentParentController::destroy
 * @see app/Http/Controllers/Student/StudentParentController.php:189
 * @route '/student-parents/{student_parent}'
 */
destroy.delete = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Student\StudentParentController::destroy
 * @see app/Http/Controllers/Student/StudentParentController.php:189
 * @route '/student-parents/{student_parent}'
 */
    const destroyForm = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentParentController::destroy
 * @see app/Http/Controllers/Student/StudentParentController.php:189
 * @route '/student-parents/{student_parent}'
 */
        destroyForm.delete = (args: { student_parent: string | number } | [student_parent: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const studentParents = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default studentParents