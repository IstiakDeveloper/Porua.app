import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/marks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\MarkController::index
 * @see app/Http/Controllers/Exam/MarkController.php:18
 * @route '/marks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/marks/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\MarkController::create
 * @see app/Http/Controllers/Exam/MarkController.php:38
 * @route '/marks/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Exam\MarkController::store
 * @see app/Http/Controllers/Exam/MarkController.php:66
 * @route '/marks'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/marks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::store
 * @see app/Http/Controllers/Exam/MarkController.php:66
 * @route '/marks'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::store
 * @see app/Http/Controllers/Exam/MarkController.php:66
 * @route '/marks'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::store
 * @see app/Http/Controllers/Exam/MarkController.php:66
 * @route '/marks'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::store
 * @see app/Http/Controllers/Exam/MarkController.php:66
 * @route '/marks'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
export const edit = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/marks/{mark}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
edit.url = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mark: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    mark: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mark: args.mark,
                }

    return edit.definition.url
            .replace('{mark}', parsedArgs.mark.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
edit.get = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
edit.head = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
    const editForm = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
        editForm.get = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\MarkController::edit
 * @see app/Http/Controllers/Exam/MarkController.php:132
 * @route '/marks/{mark}/edit'
 */
        editForm.head = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
export const update = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/marks/{mark}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
update.url = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mark: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    mark: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mark: args.mark,
                }

    return update.definition.url
            .replace('{mark}', parsedArgs.mark.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
update.put = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
update.patch = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
    const updateForm = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
        updateForm.put = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Exam\MarkController::update
 * @see app/Http/Controllers/Exam/MarkController.php:0
 * @route '/marks/{mark}'
 */
        updateForm.patch = (args: { mark: string | number } | [mark: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Exam\MarkController::destroy
 * @see app/Http/Controllers/Exam/MarkController.php:150
 * @route '/marks/{mark}'
 */
export const destroy = (args: { mark: number | { id: number } } | [mark: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/marks/{mark}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::destroy
 * @see app/Http/Controllers/Exam/MarkController.php:150
 * @route '/marks/{mark}'
 */
destroy.url = (args: { mark: number | { id: number } } | [mark: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mark: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { mark: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mark: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mark: typeof args.mark === 'object'
                ? args.mark.id
                : args.mark,
                }

    return destroy.definition.url
            .replace('{mark}', parsedArgs.mark.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::destroy
 * @see app/Http/Controllers/Exam/MarkController.php:150
 * @route '/marks/{mark}'
 */
destroy.delete = (args: { mark: number | { id: number } } | [mark: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::destroy
 * @see app/Http/Controllers/Exam/MarkController.php:150
 * @route '/marks/{mark}'
 */
    const destroyForm = (args: { mark: number | { id: number } } | [mark: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::destroy
 * @see app/Http/Controllers/Exam/MarkController.php:150
 * @route '/marks/{mark}'
 */
        destroyForm.delete = (args: { mark: number | { id: number } } | [mark: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
export const students = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})

students.definition = {
    methods: ["get","head"],
    url: '/marks/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
students.url = (options?: RouteQueryOptions) => {
    return students.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
students.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
students.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: students.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
    const studentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: students.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
        studentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\MarkController::students
 * @see app/Http/Controllers/Exam/MarkController.php:49
 * @route '/marks/students'
 */
        studentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    students.form = studentsForm
const marks = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
students: Object.assign(students, students),
}

export default marks