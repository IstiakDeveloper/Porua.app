import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parent/messages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentMessageController::index
 * @see app/Http/Controllers/Parent/ParentMessageController.php:13
 * @route '/parent/messages'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Parent\ParentMessageController::send
 * @see app/Http/Controllers/Parent/ParentMessageController.php:89
 * @route '/parent/messages/send'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/parent/messages/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::send
 * @see app/Http/Controllers/Parent/ParentMessageController.php:89
 * @route '/parent/messages/send'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::send
 * @see app/Http/Controllers/Parent/ParentMessageController.php:89
 * @route '/parent/messages/send'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Parent\ParentMessageController::send
 * @see app/Http/Controllers/Parent/ParentMessageController.php:89
 * @route '/parent/messages/send'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentMessageController::send
 * @see app/Http/Controllers/Parent/ParentMessageController.php:89
 * @route '/parent/messages/send'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
export const show = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parent/messages/{message}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
show.url = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: args.message,
                }

    return show.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
show.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
show.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
    const showForm = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
        showForm.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentMessageController::show
 * @see app/Http/Controllers/Parent/ParentMessageController.php:59
 * @route '/parent/messages/{message}'
 */
        showForm.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const messages = {
    index: Object.assign(index, index),
send: Object.assign(send, send),
show: Object.assign(show, show),
}

export default messages