import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parent/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentProfileController::show
 * @see app/Http/Controllers/Parent/ParentProfileController.php:15
 * @route '/parent/profile'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Parent\ParentProfileController::update
 * @see app/Http/Controllers/Parent/ParentProfileController.php:52
 * @route '/parent/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/parent/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::update
 * @see app/Http/Controllers/Parent/ParentProfileController.php:52
 * @route '/parent/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::update
 * @see app/Http/Controllers/Parent/ParentProfileController.php:52
 * @route '/parent/profile'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Parent\ParentProfileController::update
 * @see app/Http/Controllers/Parent/ParentProfileController.php:52
 * @route '/parent/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentProfileController::update
 * @see app/Http/Controllers/Parent/ParentProfileController.php:52
 * @route '/parent/profile'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Parent\ParentProfileController::photo
 * @see app/Http/Controllers/Parent/ParentProfileController.php:73
 * @route '/parent/profile/photo'
 */
export const photo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: photo.url(options),
    method: 'post',
})

photo.definition = {
    methods: ["post"],
    url: '/parent/profile/photo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::photo
 * @see app/Http/Controllers/Parent/ParentProfileController.php:73
 * @route '/parent/profile/photo'
 */
photo.url = (options?: RouteQueryOptions) => {
    return photo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::photo
 * @see app/Http/Controllers/Parent/ParentProfileController.php:73
 * @route '/parent/profile/photo'
 */
photo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: photo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Parent\ParentProfileController::photo
 * @see app/Http/Controllers/Parent/ParentProfileController.php:73
 * @route '/parent/profile/photo'
 */
    const photoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: photo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentProfileController::photo
 * @see app/Http/Controllers/Parent/ParentProfileController.php:73
 * @route '/parent/profile/photo'
 */
        photoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: photo.url(options),
            method: 'post',
        })
    
    photo.form = photoForm
/**
* @see \App\Http\Controllers\Parent\ParentProfileController::password
 * @see app/Http/Controllers/Parent/ParentProfileController.php:93
 * @route '/parent/profile/password'
 */
export const password = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: password.url(options),
    method: 'put',
})

password.definition = {
    methods: ["put"],
    url: '/parent/profile/password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::password
 * @see app/Http/Controllers/Parent/ParentProfileController.php:93
 * @route '/parent/profile/password'
 */
password.url = (options?: RouteQueryOptions) => {
    return password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentProfileController::password
 * @see app/Http/Controllers/Parent/ParentProfileController.php:93
 * @route '/parent/profile/password'
 */
password.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: password.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Parent\ParentProfileController::password
 * @see app/Http/Controllers/Parent/ParentProfileController.php:93
 * @route '/parent/profile/password'
 */
    const passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: password.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentProfileController::password
 * @see app/Http/Controllers/Parent/ParentProfileController.php:93
 * @route '/parent/profile/password'
 */
        passwordForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: password.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    password.form = passwordForm
const profile = {
    show: Object.assign(show, show),
update: Object.assign(update, update),
photo: Object.assign(photo, photo),
password: Object.assign(password, password),
}

export default profile