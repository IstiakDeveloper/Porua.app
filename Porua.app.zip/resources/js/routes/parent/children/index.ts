import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parent/children',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentStudentController::index
 * @see app/Http/Controllers/Parent/ParentStudentController.php:13
 * @route '/parent/children'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
export const show = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parent/children/{student}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
show.url = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: args.student,
                }

    return show.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
show.get = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
show.head = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
    const showForm = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
        showForm.get = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentStudentController::show
 * @see app/Http/Controllers/Parent/ParentStudentController.php:41
 * @route '/parent/children/{student}'
 */
        showForm.head = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const children = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default children