import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import profile from './profile'
import children from './children'
import attendance from './attendance'
import exams from './exams'
import fees from './fees'
import messages from './messages'
import notices from './notices'
/**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/parent/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentDashboardController::dashboard
 * @see app/Http/Controllers/Parent/ParentDashboardController.php:19
 * @route '/parent/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
const parent = {
    dashboard: Object.assign(dashboard, dashboard),
profile: Object.assign(profile, profile),
children: Object.assign(children, children),
attendance: Object.assign(attendance, attendance),
exams: Object.assign(exams, exams),
fees: Object.assign(fees, fees),
messages: Object.assign(messages, messages),
notices: Object.assign(notices, notices),
}

export default parent