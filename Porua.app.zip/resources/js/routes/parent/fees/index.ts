import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parent/fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentFeeController::index
 * @see app/Http/Controllers/Parent/ParentFeeController.php:14
 * @route '/parent/fees'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
export const show = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parent/fees/{feeCollection}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
show.url = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { feeCollection: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    feeCollection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        feeCollection: args.feeCollection,
                }

    return show.definition.url
            .replace('{feeCollection}', parsedArgs.feeCollection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
show.get = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
show.head = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
    const showForm = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
        showForm.get = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentFeeController::show
 * @see app/Http/Controllers/Parent/ParentFeeController.php:84
 * @route '/parent/fees/{feeCollection}'
 */
        showForm.head = (args: { feeCollection: string | number } | [feeCollection: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const fees = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default fees