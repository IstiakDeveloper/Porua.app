import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/messages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::index
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:14
 * @route '/teacher/messages'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/teacher/messages/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::create
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:89
 * @route '/teacher/messages/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::send
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:125
 * @route '/teacher/messages/send'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/teacher/messages/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::send
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:125
 * @route '/teacher/messages/send'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::send
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:125
 * @route '/teacher/messages/send'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::send
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:125
 * @route '/teacher/messages/send'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::send
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:125
 * @route '/teacher/messages/send'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
export const show = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teacher/messages/{message}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
show.url = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: args.message,
                }

    return show.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
show.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
show.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
    const showForm = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
        showForm.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherMessageController::show
 * @see app/Http/Controllers/Teacher/TeacherMessageController.php:59
 * @route '/teacher/messages/{message}'
 */
        showForm.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const messages = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
send: Object.assign(send, send),
show: Object.assign(show, show),
}

export default messages