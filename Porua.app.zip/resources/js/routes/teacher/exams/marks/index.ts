import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
export const entry = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entry.url(options),
    method: 'get',
})

entry.definition = {
    methods: ["get","head"],
    url: '/teacher/exams/marks/entry',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
entry.url = (options?: RouteQueryOptions) => {
    return entry.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
entry.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entry.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
entry.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: entry.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
    const entryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: entry.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
        entryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: entry.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::entry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
        entryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: entry.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    entry.form = entryForm
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::store
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teacher/exams/marks/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::store
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::store
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::store
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::store
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
export const view = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(options),
    method: 'get',
})

view.definition = {
    methods: ["get","head"],
    url: '/teacher/exams/marks/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
view.url = (options?: RouteQueryOptions) => {
    return view.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
view.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
view.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
    const viewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: view.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
        viewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: view.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::view
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
        viewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: view.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    view.form = viewForm
const marks = {
    entry: Object.assign(entry, entry),
store: Object.assign(store, store),
view: Object.assign(view, view),
}

export default marks