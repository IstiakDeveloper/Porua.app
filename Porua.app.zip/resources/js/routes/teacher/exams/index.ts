import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import marks from './marks'
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/exams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const exams = {
    index: Object.assign(index, index),
marks: Object.assign(marks, marks),
}

export default exams