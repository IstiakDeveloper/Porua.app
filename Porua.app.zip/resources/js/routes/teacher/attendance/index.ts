import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
export const mark = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mark.url(options),
    method: 'get',
})

mark.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/mark',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
mark.url = (options?: RouteQueryOptions) => {
    return mark.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
mark.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mark.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
mark.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mark.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
    const markForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: mark.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
        markForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mark.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::mark
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
        markForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mark.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    mark.form = markForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::store
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teacher/attendance/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::store
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::store
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::store
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::store
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
    const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
        historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
        historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
export const my = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/my',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
my.url = (options?: RouteQueryOptions) => {
    return my.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
my.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
my.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
    const myForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: my.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
        myForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::my
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
        myForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    my.form = myForm
const attendance = {
    index: Object.assign(index, index),
mark: Object.assign(mark, mark),
store: Object.assign(store, store),
history: Object.assign(history, history),
my: Object.assign(my, my),
}

export default attendance