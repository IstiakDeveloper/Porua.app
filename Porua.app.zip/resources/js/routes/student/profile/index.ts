import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentProfileController::show
 * @see app/Http/Controllers/Student/StudentProfileController.php:15
 * @route '/student/profile'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Student\StudentProfileController::update
 * @see app/Http/Controllers/Student/StudentProfileController.php:99
 * @route '/student/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/student/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Student\StudentProfileController::update
 * @see app/Http/Controllers/Student/StudentProfileController.php:99
 * @route '/student/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentProfileController::update
 * @see app/Http/Controllers/Student/StudentProfileController.php:99
 * @route '/student/profile'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Student\StudentProfileController::update
 * @see app/Http/Controllers/Student/StudentProfileController.php:99
 * @route '/student/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentProfileController::update
 * @see app/Http/Controllers/Student/StudentProfileController.php:99
 * @route '/student/profile'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Student\StudentProfileController::photo
 * @see app/Http/Controllers/Student/StudentProfileController.php:123
 * @route '/student/profile/photo'
 */
export const photo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: photo.url(options),
    method: 'post',
})

photo.definition = {
    methods: ["post"],
    url: '/student/profile/photo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentProfileController::photo
 * @see app/Http/Controllers/Student/StudentProfileController.php:123
 * @route '/student/profile/photo'
 */
photo.url = (options?: RouteQueryOptions) => {
    return photo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentProfileController::photo
 * @see app/Http/Controllers/Student/StudentProfileController.php:123
 * @route '/student/profile/photo'
 */
photo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: photo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentProfileController::photo
 * @see app/Http/Controllers/Student/StudentProfileController.php:123
 * @route '/student/profile/photo'
 */
    const photoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: photo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentProfileController::photo
 * @see app/Http/Controllers/Student/StudentProfileController.php:123
 * @route '/student/profile/photo'
 */
        photoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: photo.url(options),
            method: 'post',
        })
    
    photo.form = photoForm
/**
* @see \App\Http\Controllers\Student\StudentProfileController::password
 * @see app/Http/Controllers/Student/StudentProfileController.php:148
 * @route '/student/profile/password'
 */
export const password = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: password.url(options),
    method: 'put',
})

password.definition = {
    methods: ["put"],
    url: '/student/profile/password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Student\StudentProfileController::password
 * @see app/Http/Controllers/Student/StudentProfileController.php:148
 * @route '/student/profile/password'
 */
password.url = (options?: RouteQueryOptions) => {
    return password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentProfileController::password
 * @see app/Http/Controllers/Student/StudentProfileController.php:148
 * @route '/student/profile/password'
 */
password.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: password.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Student\StudentProfileController::password
 * @see app/Http/Controllers/Student/StudentProfileController.php:148
 * @route '/student/profile/password'
 */
    const passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: password.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentProfileController::password
 * @see app/Http/Controllers/Student/StudentProfileController.php:148
 * @route '/student/profile/password'
 */
        passwordForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: password.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    password.form = passwordForm
const profile = {
    show: Object.assign(show, show),
update: Object.assign(update, update),
photo: Object.assign(photo, photo),
password: Object.assign(password, password),
}

export default profile