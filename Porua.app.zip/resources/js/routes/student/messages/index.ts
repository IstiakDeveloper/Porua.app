import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/messages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentMessageController::index
 * @see app/Http/Controllers/Student/StudentMessageController.php:15
 * @route '/student/messages'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentMessageController::store
 * @see app/Http/Controllers/Student/StudentMessageController.php:93
 * @route '/student/messages'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student/messages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentMessageController::store
 * @see app/Http/Controllers/Student/StudentMessageController.php:93
 * @route '/student/messages'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentMessageController::store
 * @see app/Http/Controllers/Student/StudentMessageController.php:93
 * @route '/student/messages'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentMessageController::store
 * @see app/Http/Controllers/Student/StudentMessageController.php:93
 * @route '/student/messages'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentMessageController::store
 * @see app/Http/Controllers/Student/StudentMessageController.php:93
 * @route '/student/messages'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
export const show = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student/messages/{message}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
show.url = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: args.message,
                }

    return show.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
show.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
show.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
    const showForm = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
        showForm.get = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentMessageController::show
 * @see app/Http/Controllers/Student/StudentMessageController.php:113
 * @route '/student/messages/{message}'
 */
        showForm.head = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Student\StudentMessageController::reply
 * @see app/Http/Controllers/Student/StudentMessageController.php:151
 * @route '/student/messages/{message}/reply'
 */
export const reply = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

reply.definition = {
    methods: ["post"],
    url: '/student/messages/{message}/reply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentMessageController::reply
 * @see app/Http/Controllers/Student/StudentMessageController.php:151
 * @route '/student/messages/{message}/reply'
 */
reply.url = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: args.message,
                }

    return reply.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentMessageController::reply
 * @see app/Http/Controllers/Student/StudentMessageController.php:151
 * @route '/student/messages/{message}/reply'
 */
reply.post = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentMessageController::reply
 * @see app/Http/Controllers/Student/StudentMessageController.php:151
 * @route '/student/messages/{message}/reply'
 */
    const replyForm = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reply.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentMessageController::reply
 * @see app/Http/Controllers/Student/StudentMessageController.php:151
 * @route '/student/messages/{message}/reply'
 */
        replyForm.post = (args: { message: string | number } | [message: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reply.url(args, options),
            method: 'post',
        })
    
    reply.form = replyForm
const messages = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
reply: Object.assign(reply, reply),
}

export default messages