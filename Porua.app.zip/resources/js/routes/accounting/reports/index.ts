import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
export const bankReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankReport.url(options),
    method: 'get',
})

bankReport.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/bank-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
bankReport.url = (options?: RouteQueryOptions) => {
    return bankReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
bankReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
bankReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bankReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
    const bankReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bankReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
        bankReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\BankReportController::bankReport
 * @see app/Http/Controllers/Accounting/Reports/BankReportController.php:18
 * @route '/accounting/reports/bank-report'
 */
        bankReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bankReport.form = bankReportForm
/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
export const receiptPayment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receiptPayment.url(options),
    method: 'get',
})

receiptPayment.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/receipt-payment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
receiptPayment.url = (options?: RouteQueryOptions) => {
    return receiptPayment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
receiptPayment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receiptPayment.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
receiptPayment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receiptPayment.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
    const receiptPaymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: receiptPayment.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
        receiptPaymentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receiptPayment.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::receiptPayment
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
        receiptPaymentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receiptPayment.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    receiptPayment.form = receiptPaymentForm
/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
export const incomeExpenditure = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: incomeExpenditure.url(options),
    method: 'get',
})

incomeExpenditure.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/income-expenditure',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
incomeExpenditure.url = (options?: RouteQueryOptions) => {
    return incomeExpenditure.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
incomeExpenditure.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: incomeExpenditure.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
incomeExpenditure.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: incomeExpenditure.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
    const incomeExpenditureForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: incomeExpenditure.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
        incomeExpenditureForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: incomeExpenditure.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::incomeExpenditure
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
        incomeExpenditureForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: incomeExpenditure.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    incomeExpenditure.form = incomeExpenditureForm
/**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
export const balanceSheet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})

balanceSheet.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/balance-sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
balanceSheet.url = (options?: RouteQueryOptions) => {
    return balanceSheet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
balanceSheet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
balanceSheet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balanceSheet.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
    const balanceSheetForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: balanceSheet.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
        balanceSheetForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: balanceSheet.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\BalanceSheetReportController::balanceSheet
 * @see app/Http/Controllers/Accounting/Reports/BalanceSheetReportController.php:18
 * @route '/accounting/reports/balance-sheet'
 */
        balanceSheetForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: balanceSheet.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    balanceSheet.form = balanceSheetForm
/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
export const dueReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dueReport.url(options),
    method: 'get',
})

dueReport.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/due-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
dueReport.url = (options?: RouteQueryOptions) => {
    return dueReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
dueReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dueReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
dueReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dueReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
    const dueReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dueReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
        dueReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dueReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::dueReport
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
        dueReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dueReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dueReport.form = dueReportForm
/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
export const staffWelfareLoanLedger = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staffWelfareLoanLedger.url(options),
    method: 'get',
})

staffWelfareLoanLedger.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/staff-welfare-loan-ledger',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
staffWelfareLoanLedger.url = (options?: RouteQueryOptions) => {
    return staffWelfareLoanLedger.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
staffWelfareLoanLedger.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staffWelfareLoanLedger.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
staffWelfareLoanLedger.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: staffWelfareLoanLedger.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
    const staffWelfareLoanLedgerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: staffWelfareLoanLedger.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
        staffWelfareLoanLedgerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staffWelfareLoanLedger.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::staffWelfareLoanLedger
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
        staffWelfareLoanLedgerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staffWelfareLoanLedger.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    staffWelfareLoanLedger.form = staffWelfareLoanLedgerForm
const reports = {
    bankReport: Object.assign(bankReport, bankReport),
receiptPayment: Object.assign(receiptPayment, receiptPayment),
incomeExpenditure: Object.assign(incomeExpenditure, incomeExpenditure),
balanceSheet: Object.assign(balanceSheet, balanceSheet),
dueReport: Object.assign(dueReport, dueReport),
staffWelfareLoanLedger: Object.assign(staffWelfareLoanLedger, staffWelfareLoanLedger),
}

export default reports