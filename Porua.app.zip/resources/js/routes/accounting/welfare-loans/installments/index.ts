import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::pay
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
export const pay = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/installments/{installment}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::pay
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
pay.url = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { installment: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    installment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        installment: args.installment,
                }

    return pay.definition.url
            .replace('{installment}', parsedArgs.installment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::pay
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
pay.post = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::pay
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
    const payForm = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pay.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::pay
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
        payForm.post = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pay.url(args, options),
            method: 'post',
        })
    
    pay.form = payForm
const installments = {
    pay: Object.assign(pay, pay),
}

export default installments