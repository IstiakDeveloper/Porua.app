import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/donations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::destroy
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
export const destroy = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/accounting/welfare-loans/donations/{donation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::destroy
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
destroy.url = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { donation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    donation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        donation: args.donation,
                }

    return destroy.definition.url
            .replace('{donation}', parsedArgs.donation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::destroy
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
destroy.delete = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::destroy
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
    const destroyForm = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::destroy
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
        destroyForm.delete = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const donations = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default donations