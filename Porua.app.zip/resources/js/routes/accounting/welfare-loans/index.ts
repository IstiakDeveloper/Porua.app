import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import donations from './donations'
import installments from './installments'
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/welfare-loans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
export const show = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/accounting/welfare-loans/{loan}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return show.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
    const showForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
        showForm.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
        showForm.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::update
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
export const update = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/accounting/welfare-loans/{loan}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::update
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
update.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return update.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::update
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
update.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::update
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
    const updateForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::update
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
        updateForm.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
export const cancel = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/{loan}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
cancel.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return cancel.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
cancel.post = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
    const cancelForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
        cancelForm.post = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const welfareLoans = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
store: Object.assign(store, store),
update: Object.assign(update, update),
donations: Object.assign(donations, donations),
installments: Object.assign(installments, installments),
cancel: Object.assign(cancel, cancel),
}

export default welfareLoans