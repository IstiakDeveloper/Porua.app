import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/income-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::index
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:12
 * @route '/accounting/income-categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::store
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:25
 * @route '/accounting/income-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/income-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::store
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:25
 * @route '/accounting/income-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::store
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:25
 * @route '/accounting/income-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::store
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:25
 * @route '/accounting/income-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::store
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:25
 * @route '/accounting/income-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
export const update = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/accounting/income-categories/{income_category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
update.url = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { income_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    income_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        income_category: args.income_category,
                }

    return update.definition.url
            .replace('{income_category}', parsedArgs.income_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
update.put = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
update.patch = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
    const updateForm = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
        updateForm.put = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::update
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:43
 * @route '/accounting/income-categories/{income_category}'
 */
        updateForm.patch = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::destroy
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:61
 * @route '/accounting/income-categories/{income_category}'
 */
export const destroy = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/accounting/income-categories/{income_category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::destroy
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:61
 * @route '/accounting/income-categories/{income_category}'
 */
destroy.url = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { income_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    income_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        income_category: args.income_category,
                }

    return destroy.definition.url
            .replace('{income_category}', parsedArgs.income_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::destroy
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:61
 * @route '/accounting/income-categories/{income_category}'
 */
destroy.delete = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::destroy
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:61
 * @route '/accounting/income-categories/{income_category}'
 */
    const destroyForm = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\IncomeCategoryController::destroy
 * @see app/Http/Controllers/Accounting/IncomeCategoryController.php:61
 * @route '/accounting/income-categories/{income_category}'
 */
        destroyForm.delete = (args: { income_category: string | number } | [income_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const incomeCategories = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default incomeCategories