import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import items from './items'
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/fixed-assets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::index
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:29
 * @route '/accounting/fixed-assets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/accounting/fixed-assets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::create
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:81
 * @route '/accounting/fixed-assets/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:109
 * @route '/accounting/fixed-assets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/fixed-assets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:109
 * @route '/accounting/fixed-assets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:109
 * @route '/accounting/fixed-assets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:109
 * @route '/accounting/fixed-assets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:109
 * @route '/accounting/fixed-assets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
export const show = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/accounting/fixed-assets/{fixed_asset}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
show.url = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fixed_asset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fixed_asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fixed_asset: args.fixed_asset,
                }

    return show.definition.url
            .replace('{fixed_asset}', parsedArgs.fixed_asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
show.get = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
show.head = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
    const showForm = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
        showForm.get = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::show
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:253
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
        showForm.head = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
export const edit = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/accounting/fixed-assets/{fixed_asset}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
edit.url = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fixed_asset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fixed_asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fixed_asset: args.fixed_asset,
                }

    return edit.definition.url
            .replace('{fixed_asset}', parsedArgs.fixed_asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
edit.get = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
edit.head = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
    const editForm = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
        editForm.get = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::edit
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:277
 * @route '/accounting/fixed-assets/{fixed_asset}/edit'
 */
        editForm.head = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
export const update = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/accounting/fixed-assets/{fixed_asset}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
update.url = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fixed_asset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fixed_asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fixed_asset: args.fixed_asset,
                }

    return update.definition.url
            .replace('{fixed_asset}', parsedArgs.fixed_asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
update.put = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
update.patch = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
    const updateForm = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
        updateForm.put = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::update
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:295
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
        updateForm.patch = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::destroy
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:373
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
export const destroy = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/accounting/fixed-assets/{fixed_asset}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::destroy
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:373
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
destroy.url = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fixed_asset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fixed_asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fixed_asset: args.fixed_asset,
                }

    return destroy.definition.url
            .replace('{fixed_asset}', parsedArgs.fixed_asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::destroy
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:373
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
destroy.delete = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::destroy
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:373
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
    const destroyForm = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::destroy
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:373
 * @route '/accounting/fixed-assets/{fixed_asset}'
 */
        destroyForm.delete = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const fixedAssets = {
    items: Object.assign(items, items),
index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default fixedAssets