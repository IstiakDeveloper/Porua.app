import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:397
 * @route '/accounting/fixed-assets/{fixed_asset}/items'
 */
export const store = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/fixed-assets/{fixed_asset}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:397
 * @route '/accounting/fixed-assets/{fixed_asset}/items'
 */
store.url = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fixed_asset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fixed_asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fixed_asset: args.fixed_asset,
                }

    return store.definition.url
            .replace('{fixed_asset}', parsedArgs.fixed_asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:397
 * @route '/accounting/fixed-assets/{fixed_asset}/items'
 */
store.post = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:397
 * @route '/accounting/fixed-assets/{fixed_asset}/items'
 */
    const storeForm = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FixedAssetController::store
 * @see app/Http/Controllers/Accounting/FixedAssetController.php:397
 * @route '/accounting/fixed-assets/{fixed_asset}/items'
 */
        storeForm.post = (args: { fixed_asset: string | number } | [fixed_asset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const items = {
    store: Object.assign(store, store),
}

export default items