import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import accounts from './accounts'
import transactions from './transactions'
import fixedAssets from './fixed-assets'
import expenseCategories from './expense-categories'
import incomeCategories from './income-categories'
import investors from './investors'
import funds from './funds'
import welfareLoans from './welfare-loans'
import reports from './reports'
/**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/accounting/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\DashboardController::dashboard
 * @see app/Http/Controllers/Accounting/DashboardController.php:16
 * @route '/accounting/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
const accounting = {
    dashboard: Object.assign(dashboard, dashboard),
accounts: Object.assign(accounts, accounts),
transactions: Object.assign(transactions, transactions),
fixedAssets: Object.assign(fixedAssets, fixedAssets),
expenseCategories: Object.assign(expenseCategories, expenseCategories),
incomeCategories: Object.assign(incomeCategories, incomeCategories),
investors: Object.assign(investors, investors),
funds: Object.assign(funds, funds),
welfareLoans: Object.assign(welfareLoans, welfareLoans),
reports: Object.assign(reports, reports),
}

export default accounting