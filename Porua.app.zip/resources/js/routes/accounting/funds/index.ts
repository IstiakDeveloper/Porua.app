import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import transactions from './transactions'
/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/funds',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\FundController::inMethod
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
export const inMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: inMethod.url(options),
    method: 'post',
})

inMethod.definition = {
    methods: ["post"],
    url: '/accounting/funds/in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::inMethod
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
inMethod.url = (options?: RouteQueryOptions) => {
    return inMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::inMethod
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
inMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: inMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::inMethod
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
    const inMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: inMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::inMethod
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
        inMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: inMethod.url(options),
            method: 'post',
        })
    
    inMethod.form = inMethodForm
/**
* @see \App\Http\Controllers\Accounting\FundController::out
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
export const out = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: out.url(options),
    method: 'post',
})

out.definition = {
    methods: ["post"],
    url: '/accounting/funds/out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::out
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
out.url = (options?: RouteQueryOptions) => {
    return out.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::out
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
out.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: out.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::out
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
    const outForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: out.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::out
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
        outForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: out.url(options),
            method: 'post',
        })
    
    out.form = outForm
const funds = {
    index: Object.assign(index, index),
in: Object.assign(inMethod, inMethod),
out: Object.assign(out, out),
transactions: Object.assign(transactions, transactions),
}

export default funds