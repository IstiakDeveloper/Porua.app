import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\NotificationController::index
 * @see app/Http/Controllers/Communication/NotificationController.php:13
 * @route '/notifications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
export const unread = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unread.url(options),
    method: 'get',
})

unread.definition = {
    methods: ["get","head"],
    url: '/notifications/unread',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
unread.url = (options?: RouteQueryOptions) => {
    return unread.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
unread.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unread.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
unread.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: unread.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
    const unreadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: unread.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
        unreadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unread.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\NotificationController::unread
 * @see app/Http/Controllers/Communication/NotificationController.php:24
 * @route '/notifications/unread'
 */
        unreadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unread.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    unread.form = unreadForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::read
 * @see app/Http/Controllers/Communication/NotificationController.php:37
 * @route '/notifications/{notification}/read'
 */
export const read = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

read.definition = {
    methods: ["post"],
    url: '/notifications/{notification}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::read
 * @see app/Http/Controllers/Communication/NotificationController.php:37
 * @route '/notifications/{notification}/read'
 */
read.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return read.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::read
 * @see app/Http/Controllers/Communication/NotificationController.php:37
 * @route '/notifications/{notification}/read'
 */
read.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::read
 * @see app/Http/Controllers/Communication/NotificationController.php:37
 * @route '/notifications/{notification}/read'
 */
    const readForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::read
 * @see app/Http/Controllers/Communication/NotificationController.php:37
 * @route '/notifications/{notification}/read'
 */
        readForm.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, options),
            method: 'post',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::readAll
 * @see app/Http/Controllers/Communication/NotificationController.php:51
 * @route '/notifications/read-all'
 */
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

readAll.definition = {
    methods: ["post"],
    url: '/notifications/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::readAll
 * @see app/Http/Controllers/Communication/NotificationController.php:51
 * @route '/notifications/read-all'
 */
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::readAll
 * @see app/Http/Controllers/Communication/NotificationController.php:51
 * @route '/notifications/read-all'
 */
readAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::readAll
 * @see app/Http/Controllers/Communication/NotificationController.php:51
 * @route '/notifications/read-all'
 */
    const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: readAll.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::readAll
 * @see app/Http/Controllers/Communication/NotificationController.php:51
 * @route '/notifications/read-all'
 */
        readAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: readAll.url(options),
            method: 'post',
        })
    
    readAll.form = readAllForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::destroy
 * @see app/Http/Controllers/Communication/NotificationController.php:63
 * @route '/notifications/{notification}'
 */
export const destroy = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/notifications/{notification}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::destroy
 * @see app/Http/Controllers/Communication/NotificationController.php:63
 * @route '/notifications/{notification}'
 */
destroy.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return destroy.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::destroy
 * @see app/Http/Controllers/Communication/NotificationController.php:63
 * @route '/notifications/{notification}'
 */
destroy.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::destroy
 * @see app/Http/Controllers/Communication/NotificationController.php:63
 * @route '/notifications/{notification}'
 */
    const destroyForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::destroy
 * @see app/Http/Controllers/Communication/NotificationController.php:63
 * @route '/notifications/{notification}'
 */
        destroyForm.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::deleteAll
 * @see app/Http/Controllers/Communication/NotificationController.php:74
 * @route '/notifications/delete-all'
 */
export const deleteAll = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAll.url(options),
    method: 'delete',
})

deleteAll.definition = {
    methods: ["delete"],
    url: '/notifications/delete-all',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::deleteAll
 * @see app/Http/Controllers/Communication/NotificationController.php:74
 * @route '/notifications/delete-all'
 */
deleteAll.url = (options?: RouteQueryOptions) => {
    return deleteAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::deleteAll
 * @see app/Http/Controllers/Communication/NotificationController.php:74
 * @route '/notifications/delete-all'
 */
deleteAll.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAll.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::deleteAll
 * @see app/Http/Controllers/Communication/NotificationController.php:74
 * @route '/notifications/delete-all'
 */
    const deleteAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteAll.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::deleteAll
 * @see app/Http/Controllers/Communication/NotificationController.php:74
 * @route '/notifications/delete-all'
 */
        deleteAllForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteAll.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteAll.form = deleteAllForm
/**
* @see \App\Http\Controllers\Communication\NotificationController::send
 * @see app/Http/Controllers/Communication/NotificationController.php:83
 * @route '/notifications/send'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/notifications/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Communication\NotificationController::send
 * @see app/Http/Controllers/Communication/NotificationController.php:83
 * @route '/notifications/send'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\NotificationController::send
 * @see app/Http/Controllers/Communication/NotificationController.php:83
 * @route '/notifications/send'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Communication\NotificationController::send
 * @see app/Http/Controllers/Communication/NotificationController.php:83
 * @route '/notifications/send'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\NotificationController::send
 * @see app/Http/Controllers/Communication/NotificationController.php:83
 * @route '/notifications/send'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
const notifications = {
    index: Object.assign(index, index),
unread: Object.assign(unread, unread),
read: Object.assign(read, read),
readAll: Object.assign(readAll, readAll),
destroy: Object.assign(destroy, destroy),
deleteAll: Object.assign(deleteAll, deleteAll),
send: Object.assign(send, send),
}

export default notifications