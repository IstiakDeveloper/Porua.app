import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/fee-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::index
 * @see app/Http/Controllers/Fee/FeeTypeController.php:12
 * @route '/fee-types'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/fee-types/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::create
 * @see app/Http/Controllers/Fee/FeeTypeController.php:23
 * @route '/fee-types/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::store
 * @see app/Http/Controllers/Fee/FeeTypeController.php:30
 * @route '/fee-types'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/fee-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::store
 * @see app/Http/Controllers/Fee/FeeTypeController.php:30
 * @route '/fee-types'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::store
 * @see app/Http/Controllers/Fee/FeeTypeController.php:30
 * @route '/fee-types'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::store
 * @see app/Http/Controllers/Fee/FeeTypeController.php:30
 * @route '/fee-types'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::store
 * @see app/Http/Controllers/Fee/FeeTypeController.php:30
 * @route '/fee-types'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
export const edit = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/fee-types/{fee_type}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
edit.url = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_type: args.fee_type,
                }

    return edit.definition.url
            .replace('{fee_type}', parsedArgs.fee_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
edit.get = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
edit.head = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
    const editForm = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
        editForm.get = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::edit
 * @see app/Http/Controllers/Fee/FeeTypeController.php:50
 * @route '/fee-types/{fee_type}/edit'
 */
        editForm.head = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
export const update = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/fee-types/{fee_type}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
update.url = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_type: args.fee_type,
                }

    return update.definition.url
            .replace('{fee_type}', parsedArgs.fee_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
update.put = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
update.patch = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
    const updateForm = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
        updateForm.put = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::update
 * @see app/Http/Controllers/Fee/FeeTypeController.php:59
 * @route '/fee-types/{fee_type}'
 */
        updateForm.patch = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Fee\FeeTypeController::destroy
 * @see app/Http/Controllers/Fee/FeeTypeController.php:79
 * @route '/fee-types/{fee_type}'
 */
export const destroy = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/fee-types/{fee_type}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::destroy
 * @see app/Http/Controllers/Fee/FeeTypeController.php:79
 * @route '/fee-types/{fee_type}'
 */
destroy.url = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_type: args.fee_type,
                }

    return destroy.definition.url
            .replace('{fee_type}', parsedArgs.fee_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeTypeController::destroy
 * @see app/Http/Controllers/Fee/FeeTypeController.php:79
 * @route '/fee-types/{fee_type}'
 */
destroy.delete = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Fee\FeeTypeController::destroy
 * @see app/Http/Controllers/Fee/FeeTypeController.php:79
 * @route '/fee-types/{fee_type}'
 */
    const destroyForm = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeTypeController::destroy
 * @see app/Http/Controllers/Fee/FeeTypeController.php:79
 * @route '/fee-types/{fee_type}'
 */
        destroyForm.delete = (args: { fee_type: string | number } | [fee_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const feeTypes = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default feeTypes