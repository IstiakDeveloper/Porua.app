import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exam-schedules',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::index
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:15
 * @route '/exam-schedules'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/exam-schedules/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::create
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:34
 * @route '/exam-schedules/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::store
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:45
 * @route '/exam-schedules'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/exam-schedules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::store
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:45
 * @route '/exam-schedules'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::store
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:45
 * @route '/exam-schedules'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::store
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:45
 * @route '/exam-schedules'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::store
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:45
 * @route '/exam-schedules'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
export const show = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/exam-schedules/{exam_schedule}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
show.url = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_schedule: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_schedule: args.exam_schedule,
                }

    return show.definition.url
            .replace('{exam_schedule}', parsedArgs.exam_schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
show.get = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
show.head = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
    const showForm = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
        showForm.get = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::show
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:72
 * @route '/exam-schedules/{exam_schedule}'
 */
        showForm.head = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
export const edit = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/exam-schedules/{exam_schedule}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
edit.url = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_schedule: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_schedule: args.exam_schedule,
                }

    return edit.definition.url
            .replace('{exam_schedule}', parsedArgs.exam_schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
edit.get = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
edit.head = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
    const editForm = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
        editForm.get = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::edit
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:83
 * @route '/exam-schedules/{exam_schedule}/edit'
 */
        editForm.head = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
export const update = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/exam-schedules/{exam_schedule}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
update.url = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_schedule: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_schedule: args.exam_schedule,
                }

    return update.definition.url
            .replace('{exam_schedule}', parsedArgs.exam_schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
update.put = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
update.patch = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
    const updateForm = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
        updateForm.put = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::update
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:97
 * @route '/exam-schedules/{exam_schedule}'
 */
        updateForm.patch = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::destroy
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:124
 * @route '/exam-schedules/{exam_schedule}'
 */
export const destroy = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/exam-schedules/{exam_schedule}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::destroy
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:124
 * @route '/exam-schedules/{exam_schedule}'
 */
destroy.url = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_schedule: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_schedule: args.exam_schedule,
                }

    return destroy.definition.url
            .replace('{exam_schedule}', parsedArgs.exam_schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamScheduleController::destroy
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:124
 * @route '/exam-schedules/{exam_schedule}'
 */
destroy.delete = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::destroy
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:124
 * @route '/exam-schedules/{exam_schedule}'
 */
    const destroyForm = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamScheduleController::destroy
 * @see app/Http/Controllers/Exam/ExamScheduleController.php:124
 * @route '/exam-schedules/{exam_schedule}'
 */
        destroyForm.delete = (args: { exam_schedule: string | number } | [exam_schedule: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const examSchedules = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default examSchedules