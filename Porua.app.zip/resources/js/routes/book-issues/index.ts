import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/book-issues',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Library\BookIssueController::index
 * @see app/Http/Controllers/Library/BookIssueController.php:16
 * @route '/book-issues'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/book-issues/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Library\BookIssueController::create
 * @see app/Http/Controllers/Library/BookIssueController.php:32
 * @route '/book-issues/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::store
 * @see app/Http/Controllers/Library/BookIssueController.php:43
 * @route '/book-issues'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/book-issues',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::store
 * @see app/Http/Controllers/Library/BookIssueController.php:43
 * @route '/book-issues'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::store
 * @see app/Http/Controllers/Library/BookIssueController.php:43
 * @route '/book-issues'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::store
 * @see app/Http/Controllers/Library/BookIssueController.php:43
 * @route '/book-issues'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::store
 * @see app/Http/Controllers/Library/BookIssueController.php:43
 * @route '/book-issues'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
export const show = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/book-issues/{book_issue}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
show.url = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book_issue: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    book_issue: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book_issue: args.book_issue,
                }

    return show.definition.url
            .replace('{book_issue}', parsedArgs.book_issue.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
show.get = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
show.head = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
    const showForm = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
        showForm.get = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Library\BookIssueController::show
 * @see app/Http/Controllers/Library/BookIssueController.php:133
 * @route '/book-issues/{book_issue}'
 */
        showForm.head = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::destroy
 * @see app/Http/Controllers/Library/BookIssueController.php:144
 * @route '/book-issues/{book_issue}'
 */
export const destroy = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/book-issues/{book_issue}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::destroy
 * @see app/Http/Controllers/Library/BookIssueController.php:144
 * @route '/book-issues/{book_issue}'
 */
destroy.url = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book_issue: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    book_issue: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book_issue: args.book_issue,
                }

    return destroy.definition.url
            .replace('{book_issue}', parsedArgs.book_issue.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::destroy
 * @see app/Http/Controllers/Library/BookIssueController.php:144
 * @route '/book-issues/{book_issue}'
 */
destroy.delete = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::destroy
 * @see app/Http/Controllers/Library/BookIssueController.php:144
 * @route '/book-issues/{book_issue}'
 */
    const destroyForm = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::destroy
 * @see app/Http/Controllers/Library/BookIssueController.php:144
 * @route '/book-issues/{book_issue}'
 */
        destroyForm.delete = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::returnMethod
 * @see app/Http/Controllers/Library/BookIssueController.php:97
 * @route '/book-issues/{book_issue}/return'
 */
export const returnMethod = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

returnMethod.definition = {
    methods: ["post"],
    url: '/book-issues/{book_issue}/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::returnMethod
 * @see app/Http/Controllers/Library/BookIssueController.php:97
 * @route '/book-issues/{book_issue}/return'
 */
returnMethod.url = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book_issue: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    book_issue: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book_issue: args.book_issue,
                }

    return returnMethod.definition.url
            .replace('{book_issue}', parsedArgs.book_issue.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::returnMethod
 * @see app/Http/Controllers/Library/BookIssueController.php:97
 * @route '/book-issues/{book_issue}/return'
 */
returnMethod.post = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::returnMethod
 * @see app/Http/Controllers/Library/BookIssueController.php:97
 * @route '/book-issues/{book_issue}/return'
 */
    const returnMethodForm = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: returnMethod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::returnMethod
 * @see app/Http/Controllers/Library/BookIssueController.php:97
 * @route '/book-issues/{book_issue}/return'
 */
        returnMethodForm.post = (args: { book_issue: string | number } | [book_issue: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: returnMethod.url(args, options),
            method: 'post',
        })
    
    returnMethod.form = returnMethodForm
/**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
export const overdue = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overdue.url(options),
    method: 'get',
})

overdue.definition = {
    methods: ["get","head"],
    url: '/book-issues/overdue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
overdue.url = (options?: RouteQueryOptions) => {
    return overdue.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
overdue.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overdue.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
overdue.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: overdue.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
    const overdueForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: overdue.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
        overdueForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overdue.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Library\BookIssueController::overdue
 * @see app/Http/Controllers/Library/BookIssueController.php:161
 * @route '/book-issues/overdue'
 */
        overdueForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overdue.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    overdue.form = overdueForm
const bookIssues = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
return: Object.assign(returnMethod, returnMethod),
overdue: Object.assign(overdue, overdue),
}

export default bookIssues