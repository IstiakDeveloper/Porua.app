import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/attendance-summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::index
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:16
 * @route '/attendance-summary'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::destroy
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:146
 * @route '/attendance-summary/{attendance_summary}'
 */
export const destroy = (args: { attendance_summary: string | number } | [attendance_summary: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/attendance-summary/{attendance_summary}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::destroy
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:146
 * @route '/attendance-summary/{attendance_summary}'
 */
destroy.url = (args: { attendance_summary: string | number } | [attendance_summary: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendance_summary: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attendance_summary: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attendance_summary: args.attendance_summary,
                }

    return destroy.definition.url
            .replace('{attendance_summary}', parsedArgs.attendance_summary.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::destroy
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:146
 * @route '/attendance-summary/{attendance_summary}'
 */
destroy.delete = (args: { attendance_summary: string | number } | [attendance_summary: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::destroy
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:146
 * @route '/attendance-summary/{attendance_summary}'
 */
    const destroyForm = (args: { attendance_summary: string | number } | [attendance_summary: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::destroy
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:146
 * @route '/attendance-summary/{attendance_summary}'
 */
        destroyForm.delete = (args: { attendance_summary: string | number } | [attendance_summary: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::generate
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:36
 * @route '/attendance-summary/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/attendance-summary/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::generate
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:36
 * @route '/attendance-summary/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::generate
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:36
 * @route '/attendance-summary/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::generate
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:36
 * @route '/attendance-summary/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::generate
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:36
 * @route '/attendance-summary/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
export const student = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})

student.definition = {
    methods: ["get","head"],
    url: '/attendance-summary/student/{student}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
student.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return student.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
student.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: student.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
student.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: student.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
    const studentForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: student.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
        studentForm.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::student
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:99
 * @route '/attendance-summary/student/{student}'
 */
        studentForm.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: student.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    student.form = studentForm
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
export const classMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classMethod.url(options),
    method: 'get',
})

classMethod.definition = {
    methods: ["get","head"],
    url: '/attendance-summary/class',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
classMethod.url = (options?: RouteQueryOptions) => {
    return classMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
classMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
classMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
    const classMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: classMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
        classMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\AttendanceSummaryController::classMethod
 * @see app/Http/Controllers/Attendance/AttendanceSummaryController.php:114
 * @route '/attendance-summary/class'
 */
        classMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    classMethod.form = classMethodForm
const attendanceSummary = {
    index: Object.assign(index, index),
destroy: Object.assign(destroy, destroy),
generate: Object.assign(generate, generate),
student: Object.assign(student, student),
class: Object.assign(classMethod, classMethod),
}

export default attendanceSummary