import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
export const storageLink = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storageLink.url(options),
    method: 'get',
})

storageLink.definition = {
    methods: ["get","head"],
    url: '/storage-link',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
storageLink.url = (options?: RouteQueryOptions) => {
    return storageLink.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
storageLink.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storageLink.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
storageLink.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: storageLink.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
    const storageLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: storageLink.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
        storageLinkForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storageLink.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:665
 * @route '/storage-link'
 */
        storageLinkForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storageLink.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    storageLink.form = storageLinkForm
/**
 * @see routes/web.php:682
 * @route '/migrate'
 */
export const migrate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: migrate.url(options),
    method: 'get',
})

migrate.definition = {
    methods: ["get","head"],
    url: '/migrate',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:682
 * @route '/migrate'
 */
migrate.url = (options?: RouteQueryOptions) => {
    return migrate.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:682
 * @route '/migrate'
 */
migrate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: migrate.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:682
 * @route '/migrate'
 */
migrate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: migrate.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:682
 * @route '/migrate'
 */
    const migrateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: migrate.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:682
 * @route '/migrate'
 */
        migrateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: migrate.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:682
 * @route '/migrate'
 */
        migrateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: migrate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    migrate.form = migrateForm
const setup = {
    storageLink: Object.assign(storageLink, storageLink),
migrate: Object.assign(migrate, migrate),
}

export default setup