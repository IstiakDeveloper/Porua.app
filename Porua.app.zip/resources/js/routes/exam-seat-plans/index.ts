import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exam-seat-plans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::index
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:17
 * @route '/exam-seat-plans'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::destroy
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:97
 * @route '/exam-seat-plans/{exam_seat_plan}'
 */
export const destroy = (args: { exam_seat_plan: string | number } | [exam_seat_plan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/exam-seat-plans/{exam_seat_plan}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::destroy
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:97
 * @route '/exam-seat-plans/{exam_seat_plan}'
 */
destroy.url = (args: { exam_seat_plan: string | number } | [exam_seat_plan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_seat_plan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_seat_plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_seat_plan: args.exam_seat_plan,
                }

    return destroy.definition.url
            .replace('{exam_seat_plan}', parsedArgs.exam_seat_plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::destroy
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:97
 * @route '/exam-seat-plans/{exam_seat_plan}'
 */
destroy.delete = (args: { exam_seat_plan: string | number } | [exam_seat_plan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::destroy
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:97
 * @route '/exam-seat-plans/{exam_seat_plan}'
 */
    const destroyForm = (args: { exam_seat_plan: string | number } | [exam_seat_plan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::destroy
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:97
 * @route '/exam-seat-plans/{exam_seat_plan}'
 */
        destroyForm.delete = (args: { exam_seat_plan: string | number } | [exam_seat_plan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::generate
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:36
 * @route '/exam-seat-plans/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/exam-seat-plans/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::generate
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:36
 * @route '/exam-seat-plans/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::generate
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:36
 * @route '/exam-seat-plans/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::generate
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:36
 * @route '/exam-seat-plans/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::generate
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:36
 * @route '/exam-seat-plans/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/exam-seat-plans/show',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::show
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:80
 * @route '/exam-seat-plans/show'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::clear
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:108
 * @route '/exam-seat-plans/clear'
 */
export const clear = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear.url(options),
    method: 'post',
})

clear.definition = {
    methods: ["post"],
    url: '/exam-seat-plans/clear',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::clear
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:108
 * @route '/exam-seat-plans/clear'
 */
clear.url = (options?: RouteQueryOptions) => {
    return clear.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::clear
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:108
 * @route '/exam-seat-plans/clear'
 */
clear.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::clear
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:108
 * @route '/exam-seat-plans/clear'
 */
    const clearForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamSeatPlanController::clear
 * @see app/Http/Controllers/Exam/ExamSeatPlanController.php:108
 * @route '/exam-seat-plans/clear'
 */
        clearForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear.url(options),
            method: 'post',
        })
    
    clear.form = clearForm
const examSeatPlans = {
    index: Object.assign(index, index),
destroy: Object.assign(destroy, destroy),
generate: Object.assign(generate, generate),
show: Object.assign(show, show),
clear: Object.assign(clear, clear),
}

export default examSeatPlans