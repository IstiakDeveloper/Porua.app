import fees from './fees'
import attendance from './attendance'
import routine from './routine'
const coaching = {
    fees: Object.assign(fees, fees),
attendance: Object.assign(attendance, attendance),
routine: Object.assign(routine, routine),
}

export default coaching