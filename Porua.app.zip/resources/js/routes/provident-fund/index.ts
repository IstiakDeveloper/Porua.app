import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/provident-fund',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::index
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:24
 * @route '/provident-fund'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
export const show = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/provident-fund/{teacher}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
show.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return show.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
show.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
show.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
    const showForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
        showForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::show
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:122
 * @route '/provident-fund/{teacher}'
 */
        showForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::openingEntry
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:231
 * @route '/provident-fund/{teacher}/opening-entry'
 */
export const openingEntry = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: openingEntry.url(args, options),
    method: 'post',
})

openingEntry.definition = {
    methods: ["post"],
    url: '/provident-fund/{teacher}/opening-entry',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::openingEntry
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:231
 * @route '/provident-fund/{teacher}/opening-entry'
 */
openingEntry.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return openingEntry.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::openingEntry
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:231
 * @route '/provident-fund/{teacher}/opening-entry'
 */
openingEntry.post = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: openingEntry.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::openingEntry
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:231
 * @route '/provident-fund/{teacher}/opening-entry'
 */
    const openingEntryForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: openingEntry.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::openingEntry
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:231
 * @route '/provident-fund/{teacher}/opening-entry'
 */
        openingEntryForm.post = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: openingEntry.url(args, options),
            method: 'post',
        })
    
    openingEntry.form = openingEntryForm
/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::withdraw
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:319
 * @route '/provident-fund/{teacher}/withdraw'
 */
export const withdraw = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: withdraw.url(args, options),
    method: 'post',
})

withdraw.definition = {
    methods: ["post"],
    url: '/provident-fund/{teacher}/withdraw',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::withdraw
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:319
 * @route '/provident-fund/{teacher}/withdraw'
 */
withdraw.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return withdraw.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Salary\ProvidentFundController::withdraw
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:319
 * @route '/provident-fund/{teacher}/withdraw'
 */
withdraw.post = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: withdraw.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::withdraw
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:319
 * @route '/provident-fund/{teacher}/withdraw'
 */
    const withdrawForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: withdraw.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Salary\ProvidentFundController::withdraw
 * @see app/Http/Controllers/Salary/ProvidentFundController.php:319
 * @route '/provident-fund/{teacher}/withdraw'
 */
        withdrawForm.post = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: withdraw.url(args, options),
            method: 'post',
        })
    
    withdraw.form = withdrawForm
const providentFund = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
openingEntry: Object.assign(openingEntry, openingEntry),
withdraw: Object.assign(withdraw, withdraw),
}

export default providentFund