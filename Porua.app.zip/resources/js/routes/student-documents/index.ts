import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
export const index = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/students/{student}/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
index.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return index.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
index.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
index.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
    const indexForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
        indexForm.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::index
 * @see app/Http/Controllers/Student/StudentDocumentController.php:14
 * @route '/students/{student}/documents'
 */
        indexForm.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::store
 * @see app/Http/Controllers/Student/StudentDocumentController.php:32
 * @route '/students/{student}/documents'
 */
export const store = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/students/{student}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::store
 * @see app/Http/Controllers/Student/StudentDocumentController.php:32
 * @route '/students/{student}/documents'
 */
store.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return store.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::store
 * @see app/Http/Controllers/Student/StudentDocumentController.php:32
 * @route '/students/{student}/documents'
 */
store.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\StudentDocumentController::store
 * @see app/Http/Controllers/Student/StudentDocumentController.php:32
 * @route '/students/{student}/documents'
 */
    const storeForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::store
 * @see app/Http/Controllers/Student/StudentDocumentController.php:32
 * @route '/students/{student}/documents'
 */
        storeForm.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::destroy
 * @see app/Http/Controllers/Student/StudentDocumentController.php:65
 * @route '/student-documents/{student_document}'
 */
export const destroy = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/student-documents/{student_document}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::destroy
 * @see app/Http/Controllers/Student/StudentDocumentController.php:65
 * @route '/student-documents/{student_document}'
 */
destroy.url = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_document: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_document: args.student_document,
                }

    return destroy.definition.url
            .replace('{student_document}', parsedArgs.student_document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::destroy
 * @see app/Http/Controllers/Student/StudentDocumentController.php:65
 * @route '/student-documents/{student_document}'
 */
destroy.delete = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Student\StudentDocumentController::destroy
 * @see app/Http/Controllers/Student/StudentDocumentController.php:65
 * @route '/student-documents/{student_document}'
 */
    const destroyForm = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::destroy
 * @see app/Http/Controllers/Student/StudentDocumentController.php:65
 * @route '/student-documents/{student_document}'
 */
        destroyForm.delete = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
export const download = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/student-documents/{student_document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
download.url = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_document: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_document: args.student_document,
                }

    return download.definition.url
            .replace('{student_document}', parsedArgs.student_document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
download.get = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
download.head = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
    const downloadForm = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
        downloadForm.get = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentDocumentController::download
 * @see app/Http/Controllers/Student/StudentDocumentController.php:80
 * @route '/student-documents/{student_document}/download'
 */
        downloadForm.head = (args: { student_document: string | number } | [student_document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const studentDocuments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
download: Object.assign(download, download),
}

export default studentDocuments