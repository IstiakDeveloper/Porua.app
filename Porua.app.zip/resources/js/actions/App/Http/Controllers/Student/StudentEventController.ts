import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentEventController::index
 * @see app/Http/Controllers/Student/StudentEventController.php:15
 * @route '/student/events'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
export const calendar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})

calendar.definition = {
    methods: ["get","head"],
    url: '/student/events/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
calendar.url = (options?: RouteQueryOptions) => {
    return calendar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
calendar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
calendar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calendar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
    const calendarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calendar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
        calendarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentEventController::calendar
 * @see app/Http/Controllers/Student/StudentEventController.php:63
 * @route '/student/events/calendar'
 */
        calendarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calendar.form = calendarForm
const StudentEventController = { index, calendar }

export default StudentEventController