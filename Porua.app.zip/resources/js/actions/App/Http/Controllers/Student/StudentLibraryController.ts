import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/library',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::index
 * @see app/Http/Controllers/Student/StudentLibraryController.php:16
 * @route '/student/library'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
export const books = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: books.url(options),
    method: 'get',
})

books.definition = {
    methods: ["get","head"],
    url: '/student/library/books',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
books.url = (options?: RouteQueryOptions) => {
    return books.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
books.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: books.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
books.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: books.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
    const booksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: books.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
        booksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: books.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::books
 * @see app/Http/Controllers/Student/StudentLibraryController.php:77
 * @route '/student/library/books'
 */
        booksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: books.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    books.form = booksForm
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
export const issued = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: issued.url(options),
    method: 'get',
})

issued.definition = {
    methods: ["get","head"],
    url: '/student/library/issued',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
issued.url = (options?: RouteQueryOptions) => {
    return issued.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
issued.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: issued.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
issued.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: issued.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
    const issuedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: issued.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
        issuedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: issued.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentLibraryController::issued
 * @see app/Http/Controllers/Student/StudentLibraryController.php:119
 * @route '/student/library/issued'
 */
        issuedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: issued.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    issued.form = issuedForm
const StudentLibraryController = { index, books, issued }

export default StudentLibraryController