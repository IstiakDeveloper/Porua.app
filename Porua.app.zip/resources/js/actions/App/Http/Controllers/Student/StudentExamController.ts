import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/exams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentExamController::index
 * @see app/Http/Controllers/Student/StudentExamController.php:18
 * @route '/student/exams'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
export const show = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student/exams/{exam}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
show.url = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam: args.exam,
                }

    return show.definition.url
            .replace('{exam}', parsedArgs.exam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
show.get = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
show.head = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
    const showForm = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
        showForm.get = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentExamController::show
 * @see app/Http/Controllers/Student/StudentExamController.php:86
 * @route '/student/exams/{exam}'
 */
        showForm.head = (args: { exam: string | number } | [exam: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
export const results = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(options),
    method: 'get',
})

results.definition = {
    methods: ["get","head"],
    url: '/student/results',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
results.url = (options?: RouteQueryOptions) => {
    return results.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
results.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
results.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: results.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
    const resultsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: results.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
        resultsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: results.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentExamController::results
 * @see app/Http/Controllers/Student/StudentExamController.php:147
 * @route '/student/results'
 */
        resultsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: results.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    results.form = resultsForm
/**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
export const resultDetail = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resultDetail.url(args, options),
    method: 'get',
})

resultDetail.definition = {
    methods: ["get","head"],
    url: '/student/results/{result}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
resultDetail.url = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: args.result,
                }

    return resultDetail.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
resultDetail.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resultDetail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
resultDetail.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resultDetail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
    const resultDetailForm = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resultDetail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
        resultDetailForm.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resultDetail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentExamController::resultDetail
 * @see app/Http/Controllers/Student/StudentExamController.php:187
 * @route '/student/results/{result}'
 */
        resultDetailForm.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resultDetail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resultDetail.form = resultDetailForm
/**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
export const downloadMarksheet = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadMarksheet.url(args, options),
    method: 'get',
})

downloadMarksheet.definition = {
    methods: ["get","head"],
    url: '/student/results/{result}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
downloadMarksheet.url = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: args.result,
                }

    return downloadMarksheet.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
downloadMarksheet.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadMarksheet.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
downloadMarksheet.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadMarksheet.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
    const downloadMarksheetForm = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadMarksheet.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
        downloadMarksheetForm.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadMarksheet.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentExamController::downloadMarksheet
 * @see app/Http/Controllers/Student/StudentExamController.php:245
 * @route '/student/results/{result}/download'
 */
        downloadMarksheetForm.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadMarksheet.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadMarksheet.form = downloadMarksheetForm
const StudentExamController = { index, show, results, resultDetail, downloadMarksheet }

export default StudentExamController