import StudentController from './StudentController'
import StudentParentController from './StudentParentController'
import StudentDocumentController from './StudentDocumentController'
import StudentPromotionController from './StudentPromotionController'
import StudentDashboardController from './StudentDashboardController'
import StudentProfileController from './StudentProfileController'
import StudentAttendanceController from './StudentAttendanceController'
import StudentExamController from './StudentExamController'
import StudentFeeController from './StudentFeeController'
import StudentLibraryController from './StudentLibraryController'
import StudentMessageController from './StudentMessageController'
import StudentNoticeController from './StudentNoticeController'
import StudentEventController from './StudentEventController'
const Student = {
    StudentController: Object.assign(StudentController, StudentController),
StudentParentController: Object.assign(StudentParentController, StudentParentController),
StudentDocumentController: Object.assign(StudentDocumentController, StudentDocumentController),
StudentPromotionController: Object.assign(StudentPromotionController, StudentPromotionController),
StudentDashboardController: Object.assign(StudentDashboardController, StudentDashboardController),
StudentProfileController: Object.assign(StudentProfileController, StudentProfileController),
StudentAttendanceController: Object.assign(StudentAttendanceController, StudentAttendanceController),
StudentExamController: Object.assign(StudentExamController, StudentExamController),
StudentFeeController: Object.assign(StudentFeeController, StudentFeeController),
StudentLibraryController: Object.assign(StudentLibraryController, StudentLibraryController),
StudentMessageController: Object.assign(StudentMessageController, StudentMessageController),
StudentNoticeController: Object.assign(StudentNoticeController, StudentNoticeController),
StudentEventController: Object.assign(StudentEventController, StudentEventController),
}

export default Student