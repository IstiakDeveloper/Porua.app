import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::index
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:16
 * @route '/student/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
export const summary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/student/attendance/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
summary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
summary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
    const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summary.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
        summaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentAttendanceController::summary
 * @see app/Http/Controllers/Student/StudentAttendanceController.php:86
 * @route '/student/attendance/summary'
 */
        summaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summary.form = summaryForm
const StudentAttendanceController = { index, summary }

export default StudentAttendanceController