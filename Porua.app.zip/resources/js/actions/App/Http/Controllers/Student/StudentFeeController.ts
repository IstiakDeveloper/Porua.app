import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentFeeController::index
 * @see app/Http/Controllers/Student/StudentFeeController.php:16
 * @route '/student/fees'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
export const receipt = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

receipt.definition = {
    methods: ["get","head"],
    url: '/student/fees/{fee}/receipt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
receipt.url = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee: args.fee,
                }

    return receipt.definition.url
            .replace('{fee}', parsedArgs.fee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
receipt.get = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
receipt.head = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipt.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
    const receiptForm = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: receipt.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
        receiptForm.get = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receipt.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentFeeController::receipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:114
 * @route '/student/fees/{fee}/receipt'
 */
        receiptForm.head = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receipt.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    receipt.form = receiptForm
/**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
export const downloadReceipt = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReceipt.url(args, options),
    method: 'get',
})

downloadReceipt.definition = {
    methods: ["get","head"],
    url: '/student/fees/{fee}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
downloadReceipt.url = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee: args.fee,
                }

    return downloadReceipt.definition.url
            .replace('{fee}', parsedArgs.fee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
downloadReceipt.get = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReceipt.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
downloadReceipt.head = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadReceipt.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
    const downloadReceiptForm = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadReceipt.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
        downloadReceiptForm.get = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadReceipt.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Student\StudentFeeController::downloadReceipt
 * @see app/Http/Controllers/Student/StudentFeeController.php:155
 * @route '/student/fees/{fee}/download'
 */
        downloadReceiptForm.head = (args: { fee: string | number } | [fee: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadReceipt.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadReceipt.form = downloadReceiptForm
const StudentFeeController = { index, receipt, downloadReceipt }

export default StudentFeeController