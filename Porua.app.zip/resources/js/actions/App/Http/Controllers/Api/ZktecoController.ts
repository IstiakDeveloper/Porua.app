import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
export const getTeachers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTeachers.url(options),
    method: 'get',
})

getTeachers.definition = {
    methods: ["get","head"],
    url: '/api/zkteco/teachers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
getTeachers.url = (options?: RouteQueryOptions) => {
    return getTeachers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
getTeachers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTeachers.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
getTeachers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTeachers.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
    const getTeachersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTeachers.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
        getTeachersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTeachers.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ZktecoController::getTeachers
 * @see app/Http/Controllers/Api/ZktecoController.php:320
 * @route '/api/zkteco/teachers'
 */
        getTeachersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTeachers.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTeachers.form = getTeachersForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
export const getStudents = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStudents.url(options),
    method: 'get',
})

getStudents.definition = {
    methods: ["get","head"],
    url: '/api/zkteco/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
getStudents.url = (options?: RouteQueryOptions) => {
    return getStudents.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
getStudents.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStudents.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
getStudents.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStudents.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
    const getStudentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStudents.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
        getStudentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStudents.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ZktecoController::getStudents
 * @see app/Http/Controllers/Api/ZktecoController.php:355
 * @route '/api/zkteco/students'
 */
        getStudentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStudents.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStudents.form = getStudentsForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
export const getOtherStaff = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOtherStaff.url(options),
    method: 'get',
})

getOtherStaff.definition = {
    methods: ["get","head"],
    url: '/api/zkteco/other-staff',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
getOtherStaff.url = (options?: RouteQueryOptions) => {
    return getOtherStaff.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
getOtherStaff.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOtherStaff.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
getOtherStaff.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getOtherStaff.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
    const getOtherStaffForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getOtherStaff.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
        getOtherStaffForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getOtherStaff.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ZktecoController::getOtherStaff
 * @see app/Http/Controllers/Api/ZktecoController.php:705
 * @route '/api/zkteco/other-staff'
 */
        getOtherStaffForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getOtherStaff.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getOtherStaff.form = getOtherStaffForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::syncAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:24
 * @route '/api/zkteco/sync'
 */
export const syncAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAttendance.url(options),
    method: 'post',
})

syncAttendance.definition = {
    methods: ["post"],
    url: '/api/zkteco/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::syncAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:24
 * @route '/api/zkteco/sync'
 */
syncAttendance.url = (options?: RouteQueryOptions) => {
    return syncAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::syncAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:24
 * @route '/api/zkteco/sync'
 */
syncAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAttendance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::syncAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:24
 * @route '/api/zkteco/sync'
 */
    const syncAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: syncAttendance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::syncAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:24
 * @route '/api/zkteco/sync'
 */
        syncAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: syncAttendance.url(options),
            method: 'post',
        })
    
    syncAttendance.form = syncAttendanceForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::storeAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:397
 * @route '/api/zkteco/attendance/store'
 */
export const storeAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendance.url(options),
    method: 'post',
})

storeAttendance.definition = {
    methods: ["post"],
    url: '/api/zkteco/attendance/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:397
 * @route '/api/zkteco/attendance/store'
 */
storeAttendance.url = (options?: RouteQueryOptions) => {
    return storeAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:397
 * @route '/api/zkteco/attendance/store'
 */
storeAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::storeAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:397
 * @route '/api/zkteco/attendance/store'
 */
    const storeAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAttendance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::storeAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:397
 * @route '/api/zkteco/attendance/store'
 */
        storeAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAttendance.url(options),
            method: 'post',
        })
    
    storeAttendance.form = storeAttendanceForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::storeTeacherAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:467
 * @route '/api/zkteco/attendance/teacher'
 */
export const storeTeacherAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTeacherAttendance.url(options),
    method: 'post',
})

storeTeacherAttendance.definition = {
    methods: ["post"],
    url: '/api/zkteco/attendance/teacher',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeTeacherAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:467
 * @route '/api/zkteco/attendance/teacher'
 */
storeTeacherAttendance.url = (options?: RouteQueryOptions) => {
    return storeTeacherAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeTeacherAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:467
 * @route '/api/zkteco/attendance/teacher'
 */
storeTeacherAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTeacherAttendance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::storeTeacherAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:467
 * @route '/api/zkteco/attendance/teacher'
 */
    const storeTeacherAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTeacherAttendance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::storeTeacherAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:467
 * @route '/api/zkteco/attendance/teacher'
 */
        storeTeacherAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTeacherAttendance.url(options),
            method: 'post',
        })
    
    storeTeacherAttendance.form = storeTeacherAttendanceForm
/**
* @see \App\Http\Controllers\Api\ZktecoController::storeStudentAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:521
 * @route '/api/zkteco/attendance/student'
 */
export const storeStudentAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStudentAttendance.url(options),
    method: 'post',
})

storeStudentAttendance.definition = {
    methods: ["post"],
    url: '/api/zkteco/attendance/student',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeStudentAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:521
 * @route '/api/zkteco/attendance/student'
 */
storeStudentAttendance.url = (options?: RouteQueryOptions) => {
    return storeStudentAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ZktecoController::storeStudentAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:521
 * @route '/api/zkteco/attendance/student'
 */
storeStudentAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStudentAttendance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ZktecoController::storeStudentAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:521
 * @route '/api/zkteco/attendance/student'
 */
    const storeStudentAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStudentAttendance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ZktecoController::storeStudentAttendance
 * @see app/Http/Controllers/Api/ZktecoController.php:521
 * @route '/api/zkteco/attendance/student'
 */
        storeStudentAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStudentAttendance.url(options),
            method: 'post',
        })
    
    storeStudentAttendance.form = storeStudentAttendanceForm
const ZktecoController = { getTeachers, getStudents, getOtherStaff, syncAttendance, storeAttendance, storeTeacherAttendance, storeStudentAttendance }

export default ZktecoController