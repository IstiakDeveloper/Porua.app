import ZktecoController from './ZktecoController'
const Api = {
    ZktecoController: Object.assign(ZktecoController, ZktecoController),
}

export default Api