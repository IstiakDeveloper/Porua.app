import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
export const report = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})

report.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
report.url = (options?: RouteQueryOptions) => {
    return report.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
report.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
report.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: report.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
    const reportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: report.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
        reportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::report
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:229
 * @route '/teacher-attendance/report'
 */
        reportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    report.form = reportForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
export const reportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportPdf.url(options),
    method: 'get',
})

reportPdf.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/report/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
reportPdf.url = (options?: RouteQueryOptions) => {
    return reportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
reportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
reportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reportPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
    const reportPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reportPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
        reportPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::reportPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:271
 * @route '/teacher-attendance/report/pdf'
 */
        reportPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reportPdf.form = reportPdfForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
export const monthly = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthly.url(options),
    method: 'get',
})

monthly.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/monthly',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
monthly.url = (options?: RouteQueryOptions) => {
    return monthly.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
monthly.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthly.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
monthly.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monthly.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
    const monthlyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monthly.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
        monthlyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthly.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthly
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:208
 * @route '/teacher-attendance/monthly'
 */
        monthlyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthly.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monthly.form = monthlyForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
export const monthlyPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthlyPdf.url(options),
    method: 'get',
})

monthlyPdf.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/monthly/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
monthlyPdf.url = (options?: RouteQueryOptions) => {
    return monthlyPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
monthlyPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthlyPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
monthlyPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monthlyPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
    const monthlyPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monthlyPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
        monthlyPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthlyPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::monthlyPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:218
 * @route '/teacher-attendance/monthly/pdf'
 */
        monthlyPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthlyPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monthlyPdf.form = monthlyPdfForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
export const calendar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})

calendar.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
calendar.url = (options?: RouteQueryOptions) => {
    return calendar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
calendar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
calendar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calendar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
    const calendarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calendar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
        calendarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:203
 * @route '/teacher-attendance/calendar'
 */
        calendarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calendar.form = calendarForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
export const sheetReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheetReport.url(options),
    method: 'get',
})

sheetReport.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/sheet-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
sheetReport.url = (options?: RouteQueryOptions) => {
    return sheetReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
sheetReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheetReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
sheetReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sheetReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
    const sheetReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sheetReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
        sheetReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheetReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetReport
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:297
 * @route '/teacher-attendance/sheet-report'
 */
        sheetReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheetReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sheetReport.form = sheetReportForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
export const sheetPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheetPdf.url(options),
    method: 'get',
})

sheetPdf.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/sheet-report/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
sheetPdf.url = (options?: RouteQueryOptions) => {
    return sheetPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
sheetPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheetPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
sheetPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sheetPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
    const sheetPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sheetPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
        sheetPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheetPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::sheetPdf
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:317
 * @route '/teacher-attendance/sheet-report/pdf'
 */
        sheetPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheetPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sheetPdf.form = sheetPdfForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::index
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:24
 * @route '/teacher-attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/teacher-attendance/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::create
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:110
 * @route '/teacher-attendance/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::store
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:144
 * @route '/teacher-attendance'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teacher-attendance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::store
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:144
 * @route '/teacher-attendance'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::store
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:144
 * @route '/teacher-attendance'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::store
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:144
 * @route '/teacher-attendance'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::store
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:144
 * @route '/teacher-attendance'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:192
 * @route '/teacher-attendance/{teacher_attendance}'
 */
export const destroy = (args: { teacher_attendance: string | number } | [teacher_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/teacher-attendance/{teacher_attendance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:192
 * @route '/teacher-attendance/{teacher_attendance}'
 */
destroy.url = (args: { teacher_attendance: string | number } | [teacher_attendance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher_attendance: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    teacher_attendance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher_attendance: args.teacher_attendance,
                }

    return destroy.definition.url
            .replace('{teacher_attendance}', parsedArgs.teacher_attendance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:192
 * @route '/teacher-attendance/{teacher_attendance}'
 */
destroy.delete = (args: { teacher_attendance: string | number } | [teacher_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:192
 * @route '/teacher-attendance/{teacher_attendance}'
 */
    const destroyForm = (args: { teacher_attendance: string | number } | [teacher_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\TeacherAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/TeacherAttendanceController.php:192
 * @route '/teacher-attendance/{teacher_attendance}'
 */
        destroyForm.delete = (args: { teacher_attendance: string | number } | [teacher_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TeacherAttendanceController = { report, reportPdf, monthly, monthlyPdf, calendar, sheetReport, sheetPdf, index, create, store, destroy }

export default TeacherAttendanceController