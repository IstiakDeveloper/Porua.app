import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
export const getStudents = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStudents.url(options),
    method: 'get',
})

getStudents.definition = {
    methods: ["get","head"],
    url: '/student-attendance/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
getStudents.url = (options?: RouteQueryOptions) => {
    return getStudents.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
getStudents.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStudents.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
getStudents.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStudents.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
    const getStudentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStudents.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
        getStudentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStudents.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::getStudents
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:36
 * @route '/student-attendance/students'
 */
        getStudentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStudents.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStudents.form = getStudentsForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
export const report = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})

report.definition = {
    methods: ["get","head"],
    url: '/student-attendance/report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
report.url = (options?: RouteQueryOptions) => {
    return report.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
report.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
report.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: report.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
    const reportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: report.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
        reportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::report
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:112
 * @route '/student-attendance/report'
 */
        reportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    report.form = reportForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
export const calendar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})

calendar.definition = {
    methods: ["get","head"],
    url: '/student-attendance/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
calendar.url = (options?: RouteQueryOptions) => {
    return calendar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
calendar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
calendar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calendar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
    const calendarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calendar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
        calendarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::calendar
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:131
 * @route '/student-attendance/calendar'
 */
        calendarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calendar.form = calendarForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student-attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::index
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:17
 * @route '/student-attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/student-attendance/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::create
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:25
 * @route '/student-attendance/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::store
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:52
 * @route '/student-attendance'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student-attendance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::store
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:52
 * @route '/student-attendance'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::store
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:52
 * @route '/student-attendance'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::store
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:52
 * @route '/student-attendance'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::store
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:52
 * @route '/student-attendance'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
export const show = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student-attendance/{student_attendance}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
show.url = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_attendance: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_attendance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_attendance: args.student_attendance,
                }

    return show.definition.url
            .replace('{student_attendance}', parsedArgs.student_attendance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
show.get = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
show.head = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
    const showForm = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
        showForm.get = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::show
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:0
 * @route '/student-attendance/{student_attendance}'
 */
        showForm.head = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:120
 * @route '/student-attendance/{student_attendance}'
 */
export const destroy = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/student-attendance/{student_attendance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:120
 * @route '/student-attendance/{student_attendance}'
 */
destroy.url = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student_attendance: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student_attendance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student_attendance: args.student_attendance,
                }

    return destroy.definition.url
            .replace('{student_attendance}', parsedArgs.student_attendance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:120
 * @route '/student-attendance/{student_attendance}'
 */
destroy.delete = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:120
 * @route '/student-attendance/{student_attendance}'
 */
    const destroyForm = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Attendance\StudentAttendanceController::destroy
 * @see app/Http/Controllers/Attendance/StudentAttendanceController.php:120
 * @route '/student-attendance/{student_attendance}'
 */
        destroyForm.delete = (args: { student_attendance: string | number } | [student_attendance: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const StudentAttendanceController = { getStudents, report, calendar, index, create, store, show, destroy }

export default StudentAttendanceController