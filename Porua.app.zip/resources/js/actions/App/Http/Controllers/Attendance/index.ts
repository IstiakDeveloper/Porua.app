import StudentAttendanceController from './StudentAttendanceController'
import TeacherAttendanceController from './TeacherAttendanceController'
import AttendanceSummaryController from './AttendanceSummaryController'
const Attendance = {
    StudentAttendanceController: Object.assign(StudentAttendanceController, StudentAttendanceController),
TeacherAttendanceController: Object.assign(TeacherAttendanceController, TeacherAttendanceController),
AttendanceSummaryController: Object.assign(AttendanceSummaryController, AttendanceSummaryController),
}

export default Attendance