import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/model-tests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::index
 * @see app/Http/Controllers/Coaching/ModelTestController.php:17
 * @route '/model-tests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/model-tests/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::create
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::store
 * @see app/Http/Controllers/Coaching/ModelTestController.php:68
 * @route '/model-tests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/model-tests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::store
 * @see app/Http/Controllers/Coaching/ModelTestController.php:68
 * @route '/model-tests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::store
 * @see app/Http/Controllers/Coaching/ModelTestController.php:68
 * @route '/model-tests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::store
 * @see app/Http/Controllers/Coaching/ModelTestController.php:68
 * @route '/model-tests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::store
 * @see app/Http/Controllers/Coaching/ModelTestController.php:68
 * @route '/model-tests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
export const show = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/model-tests/{model_test}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
show.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return show.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
show.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
show.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
    const showForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
        showForm.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::show
 * @see app/Http/Controllers/Coaching/ModelTestController.php:122
 * @route '/model-tests/{model_test}'
 */
        showForm.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
export const edit = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/model-tests/{model_test}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
edit.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return edit.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
edit.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
edit.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
    const editForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
        editForm.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::edit
 * @see app/Http/Controllers/Coaching/ModelTestController.php:0
 * @route '/model-tests/{model_test}/edit'
 */
        editForm.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
export const update = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/model-tests/{model_test}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
update.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return update.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
update.put = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
update.patch = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
    const updateForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
        updateForm.put = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::update
 * @see app/Http/Controllers/Coaching/ModelTestController.php:222
 * @route '/model-tests/{model_test}'
 */
        updateForm.patch = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::destroy
 * @see app/Http/Controllers/Coaching/ModelTestController.php:245
 * @route '/model-tests/{model_test}'
 */
export const destroy = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/model-tests/{model_test}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::destroy
 * @see app/Http/Controllers/Coaching/ModelTestController.php:245
 * @route '/model-tests/{model_test}'
 */
destroy.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return destroy.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::destroy
 * @see app/Http/Controllers/Coaching/ModelTestController.php:245
 * @route '/model-tests/{model_test}'
 */
destroy.delete = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::destroy
 * @see app/Http/Controllers/Coaching/ModelTestController.php:245
 * @route '/model-tests/{model_test}'
 */
    const destroyForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::destroy
 * @see app/Http/Controllers/Coaching/ModelTestController.php:245
 * @route '/model-tests/{model_test}'
 */
        destroyForm.delete = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
export const markEntry = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markEntry.url(args, options),
    method: 'get',
})

markEntry.definition = {
    methods: ["get","head"],
    url: '/model-tests/{model_test}/marks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
markEntry.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return markEntry.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
markEntry.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markEntry.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
markEntry.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: markEntry.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
    const markEntryForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: markEntry.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
        markEntryForm.get = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markEntry.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::markEntry
 * @see app/Http/Controllers/Coaching/ModelTestController.php:140
 * @route '/model-tests/{model_test}/marks'
 */
        markEntryForm.head = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markEntry.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    markEntry.form = markEntryForm
/**
* @see \App\Http\Controllers\Coaching\ModelTestController::saveMarks
 * @see app/Http/Controllers/Coaching/ModelTestController.php:179
 * @route '/model-tests/{model_test}/marks'
 */
export const saveMarks = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveMarks.url(args, options),
    method: 'post',
})

saveMarks.definition = {
    methods: ["post"],
    url: '/model-tests/{model_test}/marks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::saveMarks
 * @see app/Http/Controllers/Coaching/ModelTestController.php:179
 * @route '/model-tests/{model_test}/marks'
 */
saveMarks.url = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_test: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_test: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_test: args.model_test,
                }

    return saveMarks.definition.url
            .replace('{model_test}', parsedArgs.model_test.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\ModelTestController::saveMarks
 * @see app/Http/Controllers/Coaching/ModelTestController.php:179
 * @route '/model-tests/{model_test}/marks'
 */
saveMarks.post = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveMarks.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\ModelTestController::saveMarks
 * @see app/Http/Controllers/Coaching/ModelTestController.php:179
 * @route '/model-tests/{model_test}/marks'
 */
    const saveMarksForm = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: saveMarks.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\ModelTestController::saveMarks
 * @see app/Http/Controllers/Coaching/ModelTestController.php:179
 * @route '/model-tests/{model_test}/marks'
 */
        saveMarksForm.post = (args: { model_test: string | number } | [model_test: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: saveMarks.url(args, options),
            method: 'post',
        })
    
    saveMarks.form = saveMarksForm
const ModelTestController = { index, create, store, show, edit, update, destroy, markEntry, saveMarks }

export default ModelTestController