import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/coaching/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::index
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:16
 * @route '/coaching/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
export const sheet = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheet.url(args, options),
    method: 'get',
})

sheet.definition = {
    methods: ["get","head"],
    url: '/coaching/attendance/{batch}/sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
sheet.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return sheet.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
sheet.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheet.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
sheet.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sheet.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
    const sheetForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sheet.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
        sheetForm.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheet.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::sheet
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:104
 * @route '/coaching/attendance/{batch}/sheet'
 */
        sheetForm.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sheet.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sheet.form = sheetForm
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::save
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:168
 * @route '/coaching/attendance/{batch}'
 */
export const save = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(args, options),
    method: 'post',
})

save.definition = {
    methods: ["post"],
    url: '/coaching/attendance/{batch}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::save
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:168
 * @route '/coaching/attendance/{batch}'
 */
save.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return save.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::save
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:168
 * @route '/coaching/attendance/{batch}'
 */
save.post = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::save
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:168
 * @route '/coaching/attendance/{batch}'
 */
    const saveForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: save.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::save
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:168
 * @route '/coaching/attendance/{batch}'
 */
        saveForm.post = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: save.url(args, options),
            method: 'post',
        })
    
    save.form = saveForm
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
export const report = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(args, options),
    method: 'get',
})

report.definition = {
    methods: ["get","head"],
    url: '/coaching/attendance/{batch}/report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
report.url = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { batch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { batch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    batch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        batch: typeof args.batch === 'object'
                ? args.batch.id
                : args.batch,
                }

    return report.definition.url
            .replace('{batch}', parsedArgs.batch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
report.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
report.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: report.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
    const reportForm = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: report.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
        reportForm.get = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchAttendanceController::report
 * @see app/Http/Controllers/Coaching/BatchAttendanceController.php:206
 * @route '/coaching/attendance/{batch}/report'
 */
        reportForm.head = (args: { batch: number | { id: number } } | [batch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: report.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    report.form = reportForm
const BatchAttendanceController = { index, sheet, save, report }

export default BatchAttendanceController