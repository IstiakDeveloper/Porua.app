import CourseController from './CourseController'
import BatchController from './BatchController'
import BatchEnrollmentController from './BatchEnrollmentController'
import CoachingFeeController from './CoachingFeeController'
import TeacherPayoutController from './TeacherPayoutController'
import ModelTestController from './ModelTestController'
import BatchAttendanceController from './BatchAttendanceController'
import BatchRoutineController from './BatchRoutineController'
const Coaching = {
    CourseController: Object.assign(CourseController, CourseController),
BatchController: Object.assign(BatchController, BatchController),
BatchEnrollmentController: Object.assign(BatchEnrollmentController, BatchEnrollmentController),
CoachingFeeController: Object.assign(CoachingFeeController, CoachingFeeController),
TeacherPayoutController: Object.assign(TeacherPayoutController, TeacherPayoutController),
ModelTestController: Object.assign(ModelTestController, ModelTestController),
BatchAttendanceController: Object.assign(BatchAttendanceController, BatchAttendanceController),
BatchRoutineController: Object.assign(BatchRoutineController, BatchRoutineController),
}

export default Coaching