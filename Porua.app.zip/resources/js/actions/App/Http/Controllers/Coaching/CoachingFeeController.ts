import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
export const getEnrollment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEnrollment.url(options),
    method: 'get',
})

getEnrollment.definition = {
    methods: ["get","head"],
    url: '/api/coaching/enrollment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
getEnrollment.url = (options?: RouteQueryOptions) => {
    return getEnrollment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
getEnrollment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEnrollment.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
getEnrollment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEnrollment.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
    const getEnrollmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEnrollment.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
        getEnrollmentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEnrollment.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::getEnrollment
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:172
 * @route '/api/coaching/enrollment'
 */
        getEnrollmentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEnrollment.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEnrollment.form = getEnrollmentForm
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/coaching/fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::index
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:22
 * @route '/coaching/fees'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::store
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:82
 * @route '/coaching/fees'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/coaching/fees',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::store
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:82
 * @route '/coaching/fees'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::store
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:82
 * @route '/coaching/fees'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::store
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:82
 * @route '/coaching/fees'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\CoachingFeeController::store
 * @see app/Http/Controllers/Coaching/CoachingFeeController.php:82
 * @route '/coaching/fees'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const CoachingFeeController = { getEnrollment, index, store }

export default CoachingFeeController