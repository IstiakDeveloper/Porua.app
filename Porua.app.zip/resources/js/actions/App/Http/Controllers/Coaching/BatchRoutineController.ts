import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/coaching/routine',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\BatchRoutineController::index
 * @see app/Http/Controllers/Coaching/BatchRoutineController.php:13
 * @route '/coaching/routine'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const BatchRoutineController = { index }

export default BatchRoutineController