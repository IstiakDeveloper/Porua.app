import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher-payouts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::index
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:21
 * @route '/teacher-payouts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::store
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:126
 * @route '/teacher-payouts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teacher-payouts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::store
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:126
 * @route '/teacher-payouts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::store
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:126
 * @route '/teacher-payouts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::store
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:126
 * @route '/teacher-payouts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::store
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:126
 * @route '/teacher-payouts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::destroy
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:195
 * @route '/teacher-payouts/{teacher_payout}'
 */
export const destroy = (args: { teacher_payout: string | number } | [teacher_payout: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/teacher-payouts/{teacher_payout}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::destroy
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:195
 * @route '/teacher-payouts/{teacher_payout}'
 */
destroy.url = (args: { teacher_payout: string | number } | [teacher_payout: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher_payout: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    teacher_payout: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher_payout: args.teacher_payout,
                }

    return destroy.definition.url
            .replace('{teacher_payout}', parsedArgs.teacher_payout.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::destroy
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:195
 * @route '/teacher-payouts/{teacher_payout}'
 */
destroy.delete = (args: { teacher_payout: string | number } | [teacher_payout: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::destroy
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:195
 * @route '/teacher-payouts/{teacher_payout}'
 */
    const destroyForm = (args: { teacher_payout: string | number } | [teacher_payout: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Coaching\TeacherPayoutController::destroy
 * @see app/Http/Controllers/Coaching/TeacherPayoutController.php:195
 * @route '/teacher-payouts/{teacher_payout}'
 */
        destroyForm.delete = (args: { teacher_payout: string | number } | [teacher_payout: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TeacherPayoutController = { index, store, destroy }

export default TeacherPayoutController