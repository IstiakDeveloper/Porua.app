import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exam-halls',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamHallController::index
 * @see app/Http/Controllers/Exam/ExamHallController.php:12
 * @route '/exam-halls'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\ExamHallController::store
 * @see app/Http/Controllers/Exam/ExamHallController.php:23
 * @route '/exam-halls'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/exam-halls',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ExamHallController::store
 * @see app/Http/Controllers/Exam/ExamHallController.php:23
 * @route '/exam-halls'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamHallController::store
 * @see app/Http/Controllers/Exam/ExamHallController.php:23
 * @route '/exam-halls'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ExamHallController::store
 * @see app/Http/Controllers/Exam/ExamHallController.php:23
 * @route '/exam-halls'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamHallController::store
 * @see app/Http/Controllers/Exam/ExamHallController.php:23
 * @route '/exam-halls'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
export const update = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/exam-halls/{exam_hall}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
update.url = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_hall: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_hall: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_hall: args.exam_hall,
                }

    return update.definition.url
            .replace('{exam_hall}', parsedArgs.exam_hall.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
update.put = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
update.patch = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
    const updateForm = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
        updateForm.put = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamHallController::update
 * @see app/Http/Controllers/Exam/ExamHallController.php:43
 * @route '/exam-halls/{exam_hall}'
 */
        updateForm.patch = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Exam\ExamHallController::destroy
 * @see app/Http/Controllers/Exam/ExamHallController.php:63
 * @route '/exam-halls/{exam_hall}'
 */
export const destroy = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/exam-halls/{exam_hall}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\ExamHallController::destroy
 * @see app/Http/Controllers/Exam/ExamHallController.php:63
 * @route '/exam-halls/{exam_hall}'
 */
destroy.url = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_hall: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_hall: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_hall: args.exam_hall,
                }

    return destroy.definition.url
            .replace('{exam_hall}', parsedArgs.exam_hall.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamHallController::destroy
 * @see app/Http/Controllers/Exam/ExamHallController.php:63
 * @route '/exam-halls/{exam_hall}'
 */
destroy.delete = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\ExamHallController::destroy
 * @see app/Http/Controllers/Exam/ExamHallController.php:63
 * @route '/exam-halls/{exam_hall}'
 */
    const destroyForm = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamHallController::destroy
 * @see app/Http/Controllers/Exam/ExamHallController.php:63
 * @route '/exam-halls/{exam_hall}'
 */
        destroyForm.delete = (args: { exam_hall: string | number } | [exam_hall: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ExamHallController = { index, store, update, destroy }

export default ExamHallController