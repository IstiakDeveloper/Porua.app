import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/grade-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::index
 * @see app/Http/Controllers/Exam/GradeSettingController.php:12
 * @route '/grade-settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::store
 * @see app/Http/Controllers/Exam/GradeSettingController.php:23
 * @route '/grade-settings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/grade-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::store
 * @see app/Http/Controllers/Exam/GradeSettingController.php:23
 * @route '/grade-settings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::store
 * @see app/Http/Controllers/Exam/GradeSettingController.php:23
 * @route '/grade-settings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\GradeSettingController::store
 * @see app/Http/Controllers/Exam/GradeSettingController.php:23
 * @route '/grade-settings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::store
 * @see app/Http/Controllers/Exam/GradeSettingController.php:23
 * @route '/grade-settings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
export const update = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/grade-settings/{grade_setting}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
update.url = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { grade_setting: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    grade_setting: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        grade_setting: args.grade_setting,
                }

    return update.definition.url
            .replace('{grade_setting}', parsedArgs.grade_setting.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
update.put = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
update.patch = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
    const updateForm = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
        updateForm.put = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::update
 * @see app/Http/Controllers/Exam/GradeSettingController.php:42
 * @route '/grade-settings/{grade_setting}'
 */
        updateForm.patch = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Exam\GradeSettingController::destroy
 * @see app/Http/Controllers/Exam/GradeSettingController.php:61
 * @route '/grade-settings/{grade_setting}'
 */
export const destroy = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/grade-settings/{grade_setting}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::destroy
 * @see app/Http/Controllers/Exam/GradeSettingController.php:61
 * @route '/grade-settings/{grade_setting}'
 */
destroy.url = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { grade_setting: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    grade_setting: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        grade_setting: args.grade_setting,
                }

    return destroy.definition.url
            .replace('{grade_setting}', parsedArgs.grade_setting.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\GradeSettingController::destroy
 * @see app/Http/Controllers/Exam/GradeSettingController.php:61
 * @route '/grade-settings/{grade_setting}'
 */
destroy.delete = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\GradeSettingController::destroy
 * @see app/Http/Controllers/Exam/GradeSettingController.php:61
 * @route '/grade-settings/{grade_setting}'
 */
    const destroyForm = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\GradeSettingController::destroy
 * @see app/Http/Controllers/Exam/GradeSettingController.php:61
 * @route '/grade-settings/{grade_setting}'
 */
        destroyForm.delete = (args: { grade_setting: string | number } | [grade_setting: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const GradeSettingController = { index, store, update, destroy }

export default GradeSettingController