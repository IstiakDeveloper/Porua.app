import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exam-invigilators',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::index
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:16
 * @route '/exam-invigilators'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/exam-invigilators/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::create
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:35
 * @route '/exam-invigilators/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::store
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:46
 * @route '/exam-invigilators'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/exam-invigilators',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::store
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:46
 * @route '/exam-invigilators'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::store
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:46
 * @route '/exam-invigilators'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::store
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:46
 * @route '/exam-invigilators'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::store
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:46
 * @route '/exam-invigilators'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
export const show = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/exam-invigilators/{exam_invigilator}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
show.url = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_invigilator: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_invigilator: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_invigilator: args.exam_invigilator,
                }

    return show.definition.url
            .replace('{exam_invigilator}', parsedArgs.exam_invigilator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
show.get = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
show.head = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
    const showForm = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
        showForm.get = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::show
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:0
 * @route '/exam-invigilators/{exam_invigilator}'
 */
        showForm.head = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
export const edit = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/exam-invigilators/{exam_invigilator}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
edit.url = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_invigilator: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_invigilator: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_invigilator: args.exam_invigilator,
                }

    return edit.definition.url
            .replace('{exam_invigilator}', parsedArgs.exam_invigilator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
edit.get = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
edit.head = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
    const editForm = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
        editForm.get = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::edit
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:68
 * @route '/exam-invigilators/{exam_invigilator}/edit'
 */
        editForm.head = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
export const update = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/exam-invigilators/{exam_invigilator}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
update.url = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_invigilator: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_invigilator: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_invigilator: args.exam_invigilator,
                }

    return update.definition.url
            .replace('{exam_invigilator}', parsedArgs.exam_invigilator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
update.put = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
update.patch = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
    const updateForm = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
        updateForm.put = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::update
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:82
 * @route '/exam-invigilators/{exam_invigilator}'
 */
        updateForm.patch = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::destroy
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:104
 * @route '/exam-invigilators/{exam_invigilator}'
 */
export const destroy = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/exam-invigilators/{exam_invigilator}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::destroy
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:104
 * @route '/exam-invigilators/{exam_invigilator}'
 */
destroy.url = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exam_invigilator: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    exam_invigilator: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exam_invigilator: args.exam_invigilator,
                }

    return destroy.definition.url
            .replace('{exam_invigilator}', parsedArgs.exam_invigilator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::destroy
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:104
 * @route '/exam-invigilators/{exam_invigilator}'
 */
destroy.delete = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::destroy
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:104
 * @route '/exam-invigilators/{exam_invigilator}'
 */
    const destroyForm = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::destroy
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:104
 * @route '/exam-invigilators/{exam_invigilator}'
 */
        destroyForm.delete = (args: { exam_invigilator: string | number } | [exam_invigilator: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
export const schedule = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: schedule.url(options),
    method: 'get',
})

schedule.definition = {
    methods: ["get","head"],
    url: '/exam-invigilators/schedule',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
schedule.url = (options?: RouteQueryOptions) => {
    return schedule.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
schedule.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: schedule.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
schedule.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: schedule.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
    const scheduleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: schedule.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
        scheduleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: schedule.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Exam\ExamInvigilatorController::schedule
 * @see app/Http/Controllers/Exam/ExamInvigilatorController.php:116
 * @route '/exam-invigilators/schedule'
 */
        scheduleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: schedule.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    schedule.form = scheduleForm
const ExamInvigilatorController = { index, create, store, show, edit, update, destroy, schedule }

export default ExamInvigilatorController