import ExamController from './ExamController'
import ExamScheduleController from './ExamScheduleController'
import ExamHallController from './ExamHallController'
import ExamSeatPlanController from './ExamSeatPlanController'
import ExamInvigilatorController from './ExamInvigilatorController'
import MarkController from './MarkController'
import ResultController from './ResultController'
import GradeSettingController from './GradeSettingController'
const Exam = {
    ExamController: Object.assign(ExamController, ExamController),
ExamScheduleController: Object.assign(ExamScheduleController, ExamScheduleController),
ExamHallController: Object.assign(ExamHallController, ExamHallController),
ExamSeatPlanController: Object.assign(ExamSeatPlanController, ExamSeatPlanController),
ExamInvigilatorController: Object.assign(ExamInvigilatorController, ExamInvigilatorController),
MarkController: Object.assign(MarkController, MarkController),
ResultController: Object.assign(ResultController, ResultController),
GradeSettingController: Object.assign(GradeSettingController, GradeSettingController),
}

export default Exam