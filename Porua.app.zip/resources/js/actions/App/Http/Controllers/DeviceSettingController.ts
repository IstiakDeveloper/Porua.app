import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
export const getStatus = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatus.url(options),
    method: 'get',
})

getStatus.definition = {
    methods: ["get","head"],
    url: '/api/zkteco/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
getStatus.url = (options?: RouteQueryOptions) => {
    return getStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
getStatus.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatus.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
getStatus.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStatus.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
    const getStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStatus.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
        getStatusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatus.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DeviceSettingController::getStatus
 * @see app/Http/Controllers/DeviceSettingController.php:252
 * @route '/api/zkteco/status'
 */
        getStatusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatus.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStatus.form = getStatusForm
/**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
export const getHolidays = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getHolidays.url(options),
    method: 'get',
})

getHolidays.definition = {
    methods: ["get","head"],
    url: '/api/zkteco/holidays',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
getHolidays.url = (options?: RouteQueryOptions) => {
    return getHolidays.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
getHolidays.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getHolidays.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
getHolidays.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getHolidays.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
    const getHolidaysForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getHolidays.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
        getHolidaysForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getHolidays.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DeviceSettingController::getHolidays
 * @see app/Http/Controllers/DeviceSettingController.php:321
 * @route '/api/zkteco/holidays'
 */
        getHolidaysForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getHolidays.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getHolidays.form = getHolidaysForm
/**
* @see \App\Http\Controllers\DeviceSettingController::checkWorkingDay
 * @see app/Http/Controllers/DeviceSettingController.php:337
 * @route '/api/zkteco/check-working-day'
 */
export const checkWorkingDay = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkWorkingDay.url(options),
    method: 'post',
})

checkWorkingDay.definition = {
    methods: ["post"],
    url: '/api/zkteco/check-working-day',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::checkWorkingDay
 * @see app/Http/Controllers/DeviceSettingController.php:337
 * @route '/api/zkteco/check-working-day'
 */
checkWorkingDay.url = (options?: RouteQueryOptions) => {
    return checkWorkingDay.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::checkWorkingDay
 * @see app/Http/Controllers/DeviceSettingController.php:337
 * @route '/api/zkteco/check-working-day'
 */
checkWorkingDay.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkWorkingDay.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::checkWorkingDay
 * @see app/Http/Controllers/DeviceSettingController.php:337
 * @route '/api/zkteco/check-working-day'
 */
    const checkWorkingDayForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkWorkingDay.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::checkWorkingDay
 * @see app/Http/Controllers/DeviceSettingController.php:337
 * @route '/api/zkteco/check-working-day'
 */
        checkWorkingDayForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkWorkingDay.url(options),
            method: 'post',
        })
    
    checkWorkingDay.form = checkWorkingDayForm
/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/device-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DeviceSettingController::index
 * @see app/Http/Controllers/DeviceSettingController.php:15
 * @route '/device-settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/device-settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::update
 * @see app/Http/Controllers/DeviceSettingController.php:48
 * @route '/device-settings'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateDevice
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
export const updateDevice = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDevice.url(options),
    method: 'put',
})

updateDevice.definition = {
    methods: ["put"],
    url: '/device-settings/device',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateDevice
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
updateDevice.url = (options?: RouteQueryOptions) => {
    return updateDevice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateDevice
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
updateDevice.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDevice.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateDevice
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
    const updateDeviceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDevice.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateDevice
 * @see app/Http/Controllers/DeviceSettingController.php:112
 * @route '/device-settings/device'
 */
        updateDeviceForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDevice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDevice.form = updateDeviceForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateTeacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
export const updateTeacher = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTeacher.url(options),
    method: 'put',
})

updateTeacher.definition = {
    methods: ["put"],
    url: '/device-settings/teacher',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateTeacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
updateTeacher.url = (options?: RouteQueryOptions) => {
    return updateTeacher.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateTeacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
updateTeacher.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTeacher.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateTeacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
    const updateTeacherForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTeacher.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateTeacher
 * @see app/Http/Controllers/DeviceSettingController.php:131
 * @route '/device-settings/teacher'
 */
        updateTeacherForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTeacher.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTeacher.form = updateTeacherForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateStudent
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
export const updateStudent = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStudent.url(options),
    method: 'put',
})

updateStudent.definition = {
    methods: ["put"],
    url: '/device-settings/student',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateStudent
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
updateStudent.url = (options?: RouteQueryOptions) => {
    return updateStudent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateStudent
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
updateStudent.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStudent.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateStudent
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
    const updateStudentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStudent.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateStudent
 * @see app/Http/Controllers/DeviceSettingController.php:155
 * @route '/device-settings/student'
 */
        updateStudentForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStudent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStudent.form = updateStudentForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateWeekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
export const updateWeekend = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateWeekend.url(options),
    method: 'put',
})

updateWeekend.definition = {
    methods: ["put"],
    url: '/device-settings/weekend',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateWeekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
updateWeekend.url = (options?: RouteQueryOptions) => {
    return updateWeekend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateWeekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
updateWeekend.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateWeekend.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateWeekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
    const updateWeekendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateWeekend.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateWeekend
 * @see app/Http/Controllers/DeviceSettingController.php:178
 * @route '/device-settings/weekend'
 */
        updateWeekendForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateWeekend.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateWeekend.form = updateWeekendForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateAutomation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
export const updateAutomation = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAutomation.url(options),
    method: 'put',
})

updateAutomation.definition = {
    methods: ["put"],
    url: '/device-settings/automation',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateAutomation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
updateAutomation.url = (options?: RouteQueryOptions) => {
    return updateAutomation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateAutomation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
updateAutomation.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAutomation.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateAutomation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
    const updateAutomationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAutomation.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateAutomation
 * @see app/Http/Controllers/DeviceSettingController.php:194
 * @route '/device-settings/automation'
 */
        updateAutomationForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAutomation.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAutomation.form = updateAutomationForm
/**
* @see \App\Http\Controllers\DeviceSettingController::testConnection
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
export const testConnection = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(options),
    method: 'post',
})

testConnection.definition = {
    methods: ["post"],
    url: '/device-settings/test-connection',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::testConnection
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
testConnection.url = (options?: RouteQueryOptions) => {
    return testConnection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::testConnection
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
testConnection.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::testConnection
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
    const testConnectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testConnection.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::testConnection
 * @see app/Http/Controllers/DeviceSettingController.php:218
 * @route '/device-settings/test-connection'
 */
        testConnectionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testConnection.url(options),
            method: 'post',
        })
    
    testConnection.form = testConnectionForm
/**
* @see \App\Http\Controllers\DeviceSettingController::storeHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:275
 * @route '/holidays'
 */
export const storeHoliday = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeHoliday.url(options),
    method: 'post',
})

storeHoliday.definition = {
    methods: ["post"],
    url: '/holidays',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::storeHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:275
 * @route '/holidays'
 */
storeHoliday.url = (options?: RouteQueryOptions) => {
    return storeHoliday.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::storeHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:275
 * @route '/holidays'
 */
storeHoliday.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeHoliday.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::storeHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:275
 * @route '/holidays'
 */
    const storeHolidayForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeHoliday.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::storeHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:275
 * @route '/holidays'
 */
        storeHolidayForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeHoliday.url(options),
            method: 'post',
        })
    
    storeHoliday.form = storeHolidayForm
/**
* @see \App\Http\Controllers\DeviceSettingController::updateHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:293
 * @route '/holidays/{holiday}'
 */
export const updateHoliday = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateHoliday.url(args, options),
    method: 'put',
})

updateHoliday.definition = {
    methods: ["put"],
    url: '/holidays/{holiday}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::updateHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:293
 * @route '/holidays/{holiday}'
 */
updateHoliday.url = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holiday: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holiday: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holiday: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holiday: typeof args.holiday === 'object'
                ? args.holiday.id
                : args.holiday,
                }

    return updateHoliday.definition.url
            .replace('{holiday}', parsedArgs.holiday.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::updateHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:293
 * @route '/holidays/{holiday}'
 */
updateHoliday.put = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateHoliday.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::updateHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:293
 * @route '/holidays/{holiday}'
 */
    const updateHolidayForm = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateHoliday.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::updateHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:293
 * @route '/holidays/{holiday}'
 */
        updateHolidayForm.put = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateHoliday.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateHoliday.form = updateHolidayForm
/**
* @see \App\Http\Controllers\DeviceSettingController::destroyHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:311
 * @route '/holidays/{holiday}'
 */
export const destroyHoliday = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyHoliday.url(args, options),
    method: 'delete',
})

destroyHoliday.definition = {
    methods: ["delete"],
    url: '/holidays/{holiday}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DeviceSettingController::destroyHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:311
 * @route '/holidays/{holiday}'
 */
destroyHoliday.url = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holiday: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holiday: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holiday: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holiday: typeof args.holiday === 'object'
                ? args.holiday.id
                : args.holiday,
                }

    return destroyHoliday.definition.url
            .replace('{holiday}', parsedArgs.holiday.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeviceSettingController::destroyHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:311
 * @route '/holidays/{holiday}'
 */
destroyHoliday.delete = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyHoliday.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DeviceSettingController::destroyHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:311
 * @route '/holidays/{holiday}'
 */
    const destroyHolidayForm = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyHoliday.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DeviceSettingController::destroyHoliday
 * @see app/Http/Controllers/DeviceSettingController.php:311
 * @route '/holidays/{holiday}'
 */
        destroyHolidayForm.delete = (args: { holiday: number | { id: number } } | [holiday: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyHoliday.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyHoliday.form = destroyHolidayForm
const DeviceSettingController = { getStatus, getHolidays, checkWorkingDay, index, update, updateDevice, updateTeacher, updateStudent, updateWeekend, updateAutomation, testConnection, storeHoliday, updateHoliday, destroyHoliday }

export default DeviceSettingController