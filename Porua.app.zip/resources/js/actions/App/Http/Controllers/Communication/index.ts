import NoticeController from './NoticeController'
import MessageController from './MessageController'
import NotificationController from './NotificationController'
import EventController from './EventController'
const Communication = {
    NoticeController: Object.assign(NoticeController, NoticeController),
MessageController: Object.assign(MessageController, MessageController),
NotificationController: Object.assign(NotificationController, NotificationController),
EventController: Object.assign(EventController, EventController),
}

export default Communication