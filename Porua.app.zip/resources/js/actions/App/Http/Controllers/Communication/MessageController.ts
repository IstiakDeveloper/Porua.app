import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/messages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::index
 * @see app/Http/Controllers/Communication/MessageController.php:13
 * @route '/messages'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/messages/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::create
 * @see app/Http/Controllers/Communication/MessageController.php:32
 * @route '/messages/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Communication\MessageController::store
 * @see app/Http/Controllers/Communication/MessageController.php:39
 * @route '/messages'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/messages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::store
 * @see app/Http/Controllers/Communication/MessageController.php:39
 * @route '/messages'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::store
 * @see app/Http/Controllers/Communication/MessageController.php:39
 * @route '/messages'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::store
 * @see app/Http/Controllers/Communication/MessageController.php:39
 * @route '/messages'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::store
 * @see app/Http/Controllers/Communication/MessageController.php:39
 * @route '/messages'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
export const show = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/messages/{message}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
show.url = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { message: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: typeof args.message === 'object'
                ? args.message.id
                : args.message,
                }

    return show.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
show.get = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
show.head = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
    const showForm = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
        showForm.get = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::show
 * @see app/Http/Controllers/Communication/MessageController.php:64
 * @route '/messages/{message}'
 */
        showForm.head = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Communication\MessageController::destroy
 * @see app/Http/Controllers/Communication/MessageController.php:111
 * @route '/messages/{message}'
 */
export const destroy = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/messages/{message}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::destroy
 * @see app/Http/Controllers/Communication/MessageController.php:111
 * @route '/messages/{message}'
 */
destroy.url = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { message: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: typeof args.message === 'object'
                ? args.message.id
                : args.message,
                }

    return destroy.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::destroy
 * @see app/Http/Controllers/Communication/MessageController.php:111
 * @route '/messages/{message}'
 */
destroy.delete = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::destroy
 * @see app/Http/Controllers/Communication/MessageController.php:111
 * @route '/messages/{message}'
 */
    const destroyForm = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::destroy
 * @see app/Http/Controllers/Communication/MessageController.php:111
 * @route '/messages/{message}'
 */
        destroyForm.delete = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Communication\MessageController::reply
 * @see app/Http/Controllers/Communication/MessageController.php:85
 * @route '/messages/{message}/reply'
 */
export const reply = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

reply.definition = {
    methods: ["post"],
    url: '/messages/{message}/reply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::reply
 * @see app/Http/Controllers/Communication/MessageController.php:85
 * @route '/messages/{message}/reply'
 */
reply.url = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { message: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    message: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        message: typeof args.message === 'object'
                ? args.message.id
                : args.message,
                }

    return reply.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::reply
 * @see app/Http/Controllers/Communication/MessageController.php:85
 * @route '/messages/{message}/reply'
 */
reply.post = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::reply
 * @see app/Http/Controllers/Communication/MessageController.php:85
 * @route '/messages/{message}/reply'
 */
    const replyForm = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reply.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::reply
 * @see app/Http/Controllers/Communication/MessageController.php:85
 * @route '/messages/{message}/reply'
 */
        replyForm.post = (args: { message: number | { id: number } } | [message: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reply.url(args, options),
            method: 'post',
        })
    
    reply.form = replyForm
/**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
export const inbox = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inbox.url(options),
    method: 'get',
})

inbox.definition = {
    methods: ["get","head"],
    url: '/messages/inbox',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
inbox.url = (options?: RouteQueryOptions) => {
    return inbox.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
inbox.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inbox.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
inbox.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: inbox.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
    const inboxForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: inbox.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
        inboxForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: inbox.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::inbox
 * @see app/Http/Controllers/Communication/MessageController.php:125
 * @route '/messages/inbox'
 */
        inboxForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: inbox.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    inbox.form = inboxForm
/**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
export const sent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sent.url(options),
    method: 'get',
})

sent.definition = {
    methods: ["get","head"],
    url: '/messages/sent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
sent.url = (options?: RouteQueryOptions) => {
    return sent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
sent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sent.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
sent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sent.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
    const sentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sent.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
        sentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sent.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::sent
 * @see app/Http/Controllers/Communication/MessageController.php:137
 * @route '/messages/sent'
 */
        sentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sent.form = sentForm
/**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
export const unread = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unread.url(options),
    method: 'get',
})

unread.definition = {
    methods: ["get","head"],
    url: '/messages/unread-count',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
unread.url = (options?: RouteQueryOptions) => {
    return unread.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
unread.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unread.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
unread.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: unread.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
    const unreadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: unread.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
        unreadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unread.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Communication\MessageController::unread
 * @see app/Http/Controllers/Communication/MessageController.php:149
 * @route '/messages/unread-count'
 */
        unreadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unread.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    unread.form = unreadForm
const MessageController = { index, create, store, show, destroy, reply, inbox, sent, unread }

export default MessageController