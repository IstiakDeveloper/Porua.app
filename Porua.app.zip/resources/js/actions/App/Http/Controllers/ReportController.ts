import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:21
 * @route '/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
export const attendanceReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendanceReport.url(options),
    method: 'get',
})

attendanceReport.definition = {
    methods: ["get","head"],
    url: '/reports/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendanceReport.url = (options?: RouteQueryOptions) => {
    return attendanceReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendanceReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendanceReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
attendanceReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendanceReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
    const attendanceReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendanceReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
        attendanceReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendanceReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::attendanceReport
 * @see app/Http/Controllers/ReportController.php:28
 * @route '/reports/attendance'
 */
        attendanceReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendanceReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendanceReport.form = attendanceReportForm
/**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
export const feeReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feeReport.url(options),
    method: 'get',
})

feeReport.definition = {
    methods: ["get","head"],
    url: '/reports/fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
feeReport.url = (options?: RouteQueryOptions) => {
    return feeReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
feeReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feeReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
feeReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: feeReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
    const feeReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: feeReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
        feeReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: feeReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::feeReport
 * @see app/Http/Controllers/ReportController.php:79
 * @route '/reports/fees'
 */
        feeReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: feeReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    feeReport.form = feeReportForm
/**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
export const academicReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academicReport.url(options),
    method: 'get',
})

academicReport.definition = {
    methods: ["get","head"],
    url: '/reports/academic',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academicReport.url = (options?: RouteQueryOptions) => {
    return academicReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academicReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: academicReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
academicReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: academicReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
    const academicReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: academicReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
        academicReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academicReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::academicReport
 * @see app/Http/Controllers/ReportController.php:122
 * @route '/reports/academic'
 */
        academicReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: academicReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    academicReport.form = academicReportForm
/**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
export const studentReport = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentReport.url(args, options),
    method: 'get',
})

studentReport.definition = {
    methods: ["get","head"],
    url: '/reports/student/{student}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
studentReport.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return studentReport.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
studentReport.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentReport.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
studentReport.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: studentReport.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
    const studentReportForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: studentReport.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
        studentReportForm.get = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentReport.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::studentReport
 * @see app/Http/Controllers/ReportController.php:158
 * @route '/reports/student/{student}'
 */
        studentReportForm.head = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentReport.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    studentReport.form = studentReportForm
/**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
export const teacherReport = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacherReport.url(args, options),
    method: 'get',
})

teacherReport.definition = {
    methods: ["get","head"],
    url: '/reports/teacher/{teacher}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacherReport.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return teacherReport.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacherReport.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacherReport.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
teacherReport.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: teacherReport.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
    const teacherReportForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: teacherReport.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
        teacherReportForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacherReport.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::teacherReport
 * @see app/Http/Controllers/ReportController.php:192
 * @route '/reports/teacher/{teacher}'
 */
        teacherReportForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacherReport.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    teacherReport.form = teacherReportForm
/**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
export const classReport = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classReport.url(args, options),
    method: 'get',
})

classReport.definition = {
    methods: ["get","head"],
    url: '/reports/class/{class}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classReport.url = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { class: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { class: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    class: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        class: typeof args.class === 'object'
                ? args.class.id
                : args.class,
                }

    return classReport.definition.url
            .replace('{class}', parsedArgs.class.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classReport.get = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classReport.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
classReport.head = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classReport.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
    const classReportForm = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: classReport.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
        classReportForm.get = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classReport.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::classReport
 * @see app/Http/Controllers/ReportController.php:224
 * @route '/reports/class/{class}'
 */
        classReportForm.head = (args: { class: number | { id: number } } | [classParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: classReport.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    classReport.form = classReportForm
/**
* @see \App\Http\Controllers\ReportController::exportReport
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
export const exportReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportReport.url(options),
    method: 'post',
})

exportReport.definition = {
    methods: ["post"],
    url: '/reports/export',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::exportReport
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
exportReport.url = (options?: RouteQueryOptions) => {
    return exportReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::exportReport
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
exportReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::exportReport
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
    const exportReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: exportReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::exportReport
 * @see app/Http/Controllers/ReportController.php:243
 * @route '/reports/export'
 */
        exportReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: exportReport.url(options),
            method: 'post',
        })
    
    exportReport.form = exportReportForm
const ReportController = { index, attendanceReport, feeReport, academicReport, studentReport, teacherReport, classReport, exportReport }

export default ReportController