import Api from './Api'
import DeviceSettingController from './DeviceSettingController'
import OnboardingController from './OnboardingController'
import Auth from './Auth'
import DashboardController from './DashboardController'
import UserController from './UserController'
import RoleController from './RoleController'
import PermissionController from './PermissionController'
import Academic from './Academic'
import Coaching from './Coaching'
import Student from './Student'
import Teacher from './Teacher'
import StaffController from './StaffController'
import SalaryController from './SalaryController'
import Salary from './Salary'
import Attendance from './Attendance'
import OtherStaffController from './OtherStaffController'
import OtherStaffAttendanceController from './OtherStaffAttendanceController'
import Exam from './Exam'
import Fee from './Fee'
import Library from './Library'
import Accounting from './Accounting'
import Communication from './Communication'
import ReportController from './ReportController'
import ActivityLogController from './ActivityLogController'
import SettingController from './SettingController'
import Parent from './Parent'
const Controllers = {
    Api: Object.assign(Api, Api),
DeviceSettingController: Object.assign(DeviceSettingController, DeviceSettingController),
OnboardingController: Object.assign(OnboardingController, OnboardingController),
Auth: Object.assign(Auth, Auth),
DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
RoleController: Object.assign(RoleController, RoleController),
PermissionController: Object.assign(PermissionController, PermissionController),
Academic: Object.assign(Academic, Academic),
Coaching: Object.assign(Coaching, Coaching),
Student: Object.assign(Student, Student),
Teacher: Object.assign(Teacher, Teacher),
StaffController: Object.assign(StaffController, StaffController),
SalaryController: Object.assign(SalaryController, SalaryController),
Salary: Object.assign(Salary, Salary),
Attendance: Object.assign(Attendance, Attendance),
OtherStaffController: Object.assign(OtherStaffController, OtherStaffController),
OtherStaffAttendanceController: Object.assign(OtherStaffAttendanceController, OtherStaffAttendanceController),
Exam: Object.assign(Exam, Exam),
Fee: Object.assign(Fee, Fee),
Library: Object.assign(Library, Library),
Accounting: Object.assign(Accounting, Accounting),
Communication: Object.assign(Communication, Communication),
ReportController: Object.assign(ReportController, ReportController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
SettingController: Object.assign(SettingController, SettingController),
Parent: Object.assign(Parent, Parent),
}

export default Controllers