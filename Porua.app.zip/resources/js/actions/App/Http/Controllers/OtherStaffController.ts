import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/other-staff',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OtherStaffController::index
 * @see app/Http/Controllers/OtherStaffController.php:14
 * @route '/other-staff'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/other-staff/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OtherStaffController::create
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\OtherStaffController::store
 * @see app/Http/Controllers/OtherStaffController.php:52
 * @route '/other-staff'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/other-staff',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OtherStaffController::store
 * @see app/Http/Controllers/OtherStaffController.php:52
 * @route '/other-staff'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::store
 * @see app/Http/Controllers/OtherStaffController.php:52
 * @route '/other-staff'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::store
 * @see app/Http/Controllers/OtherStaffController.php:52
 * @route '/other-staff'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::store
 * @see app/Http/Controllers/OtherStaffController.php:52
 * @route '/other-staff'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
export const show = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/other-staff/{other_staff}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
show.url = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { other_staff: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    other_staff: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        other_staff: args.other_staff,
                }

    return show.definition.url
            .replace('{other_staff}', parsedArgs.other_staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
show.get = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
show.head = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
    const showForm = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
        showForm.get = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OtherStaffController::show
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}'
 */
        showForm.head = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
export const edit = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/other-staff/{other_staff}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
edit.url = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { other_staff: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    other_staff: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        other_staff: args.other_staff,
                }

    return edit.definition.url
            .replace('{other_staff}', parsedArgs.other_staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
edit.get = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
edit.head = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
    const editForm = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
        editForm.get = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OtherStaffController::edit
 * @see app/Http/Controllers/OtherStaffController.php:0
 * @route '/other-staff/{other_staff}/edit'
 */
        editForm.head = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
export const update = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/other-staff/{other_staff}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
update.url = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { other_staff: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    other_staff: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        other_staff: args.other_staff,
                }

    return update.definition.url
            .replace('{other_staff}', parsedArgs.other_staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
update.put = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
update.patch = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
    const updateForm = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
        updateForm.put = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\OtherStaffController::update
 * @see app/Http/Controllers/OtherStaffController.php:85
 * @route '/other-staff/{other_staff}'
 */
        updateForm.patch = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\OtherStaffController::destroy
 * @see app/Http/Controllers/OtherStaffController.php:118
 * @route '/other-staff/{other_staff}'
 */
export const destroy = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/other-staff/{other_staff}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\OtherStaffController::destroy
 * @see app/Http/Controllers/OtherStaffController.php:118
 * @route '/other-staff/{other_staff}'
 */
destroy.url = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { other_staff: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    other_staff: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        other_staff: args.other_staff,
                }

    return destroy.definition.url
            .replace('{other_staff}', parsedArgs.other_staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::destroy
 * @see app/Http/Controllers/OtherStaffController.php:118
 * @route '/other-staff/{other_staff}'
 */
destroy.delete = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::destroy
 * @see app/Http/Controllers/OtherStaffController.php:118
 * @route '/other-staff/{other_staff}'
 */
    const destroyForm = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::destroy
 * @see app/Http/Controllers/OtherStaffController.php:118
 * @route '/other-staff/{other_staff}'
 */
        destroyForm.delete = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\OtherStaffController::toggleStatus
 * @see app/Http/Controllers/OtherStaffController.php:130
 * @route '/other-staff/{other_staff}/toggle-status'
 */
export const toggleStatus = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/other-staff/{other_staff}/toggle-status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\OtherStaffController::toggleStatus
 * @see app/Http/Controllers/OtherStaffController.php:130
 * @route '/other-staff/{other_staff}/toggle-status'
 */
toggleStatus.url = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { other_staff: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    other_staff: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        other_staff: args.other_staff,
                }

    return toggleStatus.definition.url
            .replace('{other_staff}', parsedArgs.other_staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffController::toggleStatus
 * @see app/Http/Controllers/OtherStaffController.php:130
 * @route '/other-staff/{other_staff}/toggle-status'
 */
toggleStatus.patch = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\OtherStaffController::toggleStatus
 * @see app/Http/Controllers/OtherStaffController.php:130
 * @route '/other-staff/{other_staff}/toggle-status'
 */
    const toggleStatusForm = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OtherStaffController::toggleStatus
 * @see app/Http/Controllers/OtherStaffController.php:130
 * @route '/other-staff/{other_staff}/toggle-status'
 */
        toggleStatusForm.patch = (args: { other_staff: string | number } | [other_staff: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const OtherStaffController = { index, create, store, show, edit, update, destroy, toggleStatus }

export default OtherStaffController