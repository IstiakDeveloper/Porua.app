import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/other-staff-attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OtherStaffAttendanceController::index
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:17
 * @route '/other-staff-attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::store
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:72
 * @route '/other-staff-attendance'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/other-staff-attendance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::store
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:72
 * @route '/other-staff-attendance'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OtherStaffAttendanceController::store
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:72
 * @route '/other-staff-attendance'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OtherStaffAttendanceController::store
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:72
 * @route '/other-staff-attendance'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OtherStaffAttendanceController::store
 * @see app/Http/Controllers/OtherStaffAttendanceController.php:72
 * @route '/other-staff-attendance'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const OtherStaffAttendanceController = { index, store }

export default OtherStaffAttendanceController