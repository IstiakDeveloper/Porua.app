import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::index
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:13
 * @route '/teacher/students'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
export const list = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})

list.definition = {
    methods: ["get","head"],
    url: '/teacher/students/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
list.url = (options?: RouteQueryOptions) => {
    return list.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
list.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
list.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: list.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
    const listForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: list.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
        listForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::list
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:38
 * @route '/teacher/students/list'
 */
        listForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    list.form = listForm
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
export const show = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teacher/students/{student}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
show.url = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: args.student,
                }

    return show.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
show.get = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
show.head = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
    const showForm = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
        showForm.get = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherStudentController::show
 * @see app/Http/Controllers/Teacher/TeacherStudentController.php:95
 * @route '/teacher/students/{student}'
 */
        showForm.head = (args: { student: string | number } | [student: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const TeacherStudentController = { index, list, show }

export default TeacherStudentController