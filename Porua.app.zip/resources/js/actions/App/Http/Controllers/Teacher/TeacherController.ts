import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
export const printProfile = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printProfile.url(args, options),
    method: 'get',
})

printProfile.definition = {
    methods: ["get","head"],
    url: '/teachers/{teacher}/print-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
printProfile.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return printProfile.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
printProfile.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printProfile.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
printProfile.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printProfile.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
    const printProfileForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: printProfile.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
        printProfileForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printProfile.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::printProfile
 * @see app/Http/Controllers/Teacher/TeacherController.php:176
 * @route '/teachers/{teacher}/print-profile'
 */
        printProfileForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printProfile.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    printProfile.form = printProfileForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
export const printIdCard = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printIdCard.url(args, options),
    method: 'get',
})

printIdCard.definition = {
    methods: ["get","head"],
    url: '/teachers/{teacher}/print-id-card',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
printIdCard.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return printIdCard.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
printIdCard.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printIdCard.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
printIdCard.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printIdCard.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
    const printIdCardForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: printIdCard.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
        printIdCardForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printIdCard.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::printIdCard
 * @see app/Http/Controllers/Teacher/TeacherController.php:217
 * @route '/teachers/{teacher}/print-id-card'
 */
        printIdCardForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printIdCard.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    printIdCard.form = printIdCardForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::toggleStatus
 * @see app/Http/Controllers/Teacher/TeacherController.php:356
 * @route '/teachers/{teacher}/toggle-status'
 */
export const toggleStatus = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/teachers/{teacher}/toggle-status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::toggleStatus
 * @see app/Http/Controllers/Teacher/TeacherController.php:356
 * @route '/teachers/{teacher}/toggle-status'
 */
toggleStatus.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return toggleStatus.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::toggleStatus
 * @see app/Http/Controllers/Teacher/TeacherController.php:356
 * @route '/teachers/{teacher}/toggle-status'
 */
toggleStatus.patch = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::toggleStatus
 * @see app/Http/Controllers/Teacher/TeacherController.php:356
 * @route '/teachers/{teacher}/toggle-status'
 */
    const toggleStatusForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::toggleStatus
 * @see app/Http/Controllers/Teacher/TeacherController.php:356
 * @route '/teachers/{teacher}/toggle-status'
 */
        toggleStatusForm.patch = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teachers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::index
 * @see app/Http/Controllers/Teacher/TeacherController.php:17
 * @route '/teachers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/teachers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::create
 * @see app/Http/Controllers/Teacher/TeacherController.php:62
 * @route '/teachers/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::store
 * @see app/Http/Controllers/Teacher/TeacherController.php:69
 * @route '/teachers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teachers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::store
 * @see app/Http/Controllers/Teacher/TeacherController.php:69
 * @route '/teachers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::store
 * @see app/Http/Controllers/Teacher/TeacherController.php:69
 * @route '/teachers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::store
 * @see app/Http/Controllers/Teacher/TeacherController.php:69
 * @route '/teachers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::store
 * @see app/Http/Controllers/Teacher/TeacherController.php:69
 * @route '/teachers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
export const show = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teachers/{teacher}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
show.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return show.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
show.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
show.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
    const showForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
        showForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::show
 * @see app/Http/Controllers/Teacher/TeacherController.php:159
 * @route '/teachers/{teacher}'
 */
        showForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
export const edit = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/teachers/{teacher}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
edit.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return edit.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
edit.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
edit.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
    const editForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
        editForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::edit
 * @see app/Http/Controllers/Teacher/TeacherController.php:245
 * @route '/teachers/{teacher}/edit'
 */
        editForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
export const update = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/teachers/{teacher}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
update.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return update.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
update.put = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
update.patch = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
    const updateForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
        updateForm.put = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherController::update
 * @see app/Http/Controllers/Teacher/TeacherController.php:268
 * @route '/teachers/{teacher}'
 */
        updateForm.patch = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Teacher\TeacherController::destroy
 * @see app/Http/Controllers/Teacher/TeacherController.php:382
 * @route '/teachers/{teacher}'
 */
export const destroy = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/teachers/{teacher}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherController::destroy
 * @see app/Http/Controllers/Teacher/TeacherController.php:382
 * @route '/teachers/{teacher}'
 */
destroy.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return destroy.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherController::destroy
 * @see app/Http/Controllers/Teacher/TeacherController.php:382
 * @route '/teachers/{teacher}'
 */
destroy.delete = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherController::destroy
 * @see app/Http/Controllers/Teacher/TeacherController.php:382
 * @route '/teachers/{teacher}'
 */
    const destroyForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherController::destroy
 * @see app/Http/Controllers/Teacher/TeacherController.php:382
 * @route '/teachers/{teacher}'
 */
        destroyForm.delete = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TeacherController = { printProfile, printIdCard, toggleStatus, index, create, store, show, edit, update, destroy }

export default TeacherController