import TeacherController from './TeacherController'
import TeacherSubjectController from './TeacherSubjectController'
import TeacherDashboardController from './TeacherDashboardController'
import TeacherProfileController from './TeacherProfileController'
import TeacherAttendanceController from './TeacherAttendanceController'
import TeacherStudentController from './TeacherStudentController'
import TeacherExamController from './TeacherExamController'
import TeacherMessageController from './TeacherMessageController'
import TeacherNoticeController from './TeacherNoticeController'
const Teacher = {
    TeacherController: Object.assign(TeacherController, TeacherController),
TeacherSubjectController: Object.assign(TeacherSubjectController, TeacherSubjectController),
TeacherDashboardController: Object.assign(TeacherDashboardController, TeacherDashboardController),
TeacherProfileController: Object.assign(TeacherProfileController, TeacherProfileController),
TeacherAttendanceController: Object.assign(TeacherAttendanceController, TeacherAttendanceController),
TeacherStudentController: Object.assign(TeacherStudentController, TeacherStudentController),
TeacherExamController: Object.assign(TeacherExamController, TeacherExamController),
TeacherMessageController: Object.assign(TeacherMessageController, TeacherMessageController),
TeacherNoticeController: Object.assign(TeacherNoticeController, TeacherNoticeController),
}

export default Teacher