import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/exams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::index
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:16
 * @route '/teacher/exams'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
export const markEntry = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markEntry.url(options),
    method: 'get',
})

markEntry.definition = {
    methods: ["get","head"],
    url: '/teacher/exams/marks/entry',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
markEntry.url = (options?: RouteQueryOptions) => {
    return markEntry.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
markEntry.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markEntry.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
markEntry.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: markEntry.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
    const markEntryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: markEntry.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
        markEntryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markEntry.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::markEntry
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:74
 * @route '/teacher/exams/marks/entry'
 */
        markEntryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markEntry.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    markEntry.form = markEntryForm
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::storeMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
export const storeMarks = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMarks.url(options),
    method: 'post',
})

storeMarks.definition = {
    methods: ["post"],
    url: '/teacher/exams/marks/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::storeMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
storeMarks.url = (options?: RouteQueryOptions) => {
    return storeMarks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::storeMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
storeMarks.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMarks.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::storeMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
    const storeMarksForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMarks.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::storeMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:143
 * @route '/teacher/exams/marks/store'
 */
        storeMarksForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMarks.url(options),
            method: 'post',
        })
    
    storeMarks.form = storeMarksForm
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
export const viewMarks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewMarks.url(options),
    method: 'get',
})

viewMarks.definition = {
    methods: ["get","head"],
    url: '/teacher/exams/marks/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
viewMarks.url = (options?: RouteQueryOptions) => {
    return viewMarks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
viewMarks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewMarks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
viewMarks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: viewMarks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
    const viewMarksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: viewMarks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
        viewMarksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewMarks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherExamController::viewMarks
 * @see app/Http/Controllers/Teacher/TeacherExamController.php:208
 * @route '/teacher/exams/marks/view'
 */
        viewMarksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewMarks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    viewMarks.form = viewMarksForm
const TeacherExamController = { index, markEntry, storeMarks, viewMarks }

export default TeacherExamController