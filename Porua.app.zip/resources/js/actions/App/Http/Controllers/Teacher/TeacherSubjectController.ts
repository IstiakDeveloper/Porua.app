import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher-subjects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::index
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:17
 * @route '/teacher-subjects'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/teacher-subjects/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::create
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:89
 * @route '/teacher-subjects/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::store
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:102
 * @route '/teacher-subjects'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/teacher-subjects',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::store
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:102
 * @route '/teacher-subjects'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::store
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:102
 * @route '/teacher-subjects'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::store
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:102
 * @route '/teacher-subjects'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::store
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:102
 * @route '/teacher-subjects'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::destroy
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:174
 * @route '/teacher-subjects/{teacher_subject}'
 */
export const destroy = (args: { teacher_subject: string | number } | [teacher_subject: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/teacher-subjects/{teacher_subject}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::destroy
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:174
 * @route '/teacher-subjects/{teacher_subject}'
 */
destroy.url = (args: { teacher_subject: string | number } | [teacher_subject: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher_subject: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    teacher_subject: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher_subject: args.teacher_subject,
                }

    return destroy.definition.url
            .replace('{teacher_subject}', parsedArgs.teacher_subject.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::destroy
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:174
 * @route '/teacher-subjects/{teacher_subject}'
 */
destroy.delete = (args: { teacher_subject: string | number } | [teacher_subject: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::destroy
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:174
 * @route '/teacher-subjects/{teacher_subject}'
 */
    const destroyForm = (args: { teacher_subject: string | number } | [teacher_subject: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::destroy
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:174
 * @route '/teacher-subjects/{teacher_subject}'
 */
        destroyForm.delete = (args: { teacher_subject: string | number } | [teacher_subject: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
export const teacherSchedule = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacherSchedule.url(args, options),
    method: 'get',
})

teacherSchedule.definition = {
    methods: ["get","head"],
    url: '/teachers/{teacher}/schedule',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
teacherSchedule.url = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { teacher: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { teacher: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    teacher: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        teacher: typeof args.teacher === 'object'
                ? args.teacher.id
                : args.teacher,
                }

    return teacherSchedule.definition.url
            .replace('{teacher}', parsedArgs.teacher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
teacherSchedule.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: teacherSchedule.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
teacherSchedule.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: teacherSchedule.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
    const teacherScheduleForm = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: teacherSchedule.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
        teacherScheduleForm.get = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacherSchedule.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherSubjectController::teacherSchedule
 * @see app/Http/Controllers/Teacher/TeacherSubjectController.php:185
 * @route '/teachers/{teacher}/schedule'
 */
        teacherScheduleForm.head = (args: { teacher: number | { id: number } } | [teacher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: teacherSchedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    teacherSchedule.form = teacherScheduleForm
const TeacherSubjectController = { index, create, store, destroy, teacherSchedule }

export default TeacherSubjectController