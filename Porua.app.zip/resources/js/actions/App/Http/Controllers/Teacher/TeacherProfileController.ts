import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teacher/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::show
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:17
 * @route '/teacher/profile'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::update
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:57
 * @route '/teacher/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/teacher/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::update
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:57
 * @route '/teacher/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::update
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:57
 * @route '/teacher/profile'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::update
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:57
 * @route '/teacher/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::update
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:57
 * @route '/teacher/profile'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePhoto
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:75
 * @route '/teacher/profile/photo'
 */
export const updatePhoto = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePhoto.url(options),
    method: 'post',
})

updatePhoto.definition = {
    methods: ["post"],
    url: '/teacher/profile/photo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePhoto
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:75
 * @route '/teacher/profile/photo'
 */
updatePhoto.url = (options?: RouteQueryOptions) => {
    return updatePhoto.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePhoto
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:75
 * @route '/teacher/profile/photo'
 */
updatePhoto.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePhoto.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePhoto
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:75
 * @route '/teacher/profile/photo'
 */
    const updatePhotoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePhoto.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePhoto
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:75
 * @route '/teacher/profile/photo'
 */
        updatePhotoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePhoto.url(options),
            method: 'post',
        })
    
    updatePhoto.form = updatePhotoForm
/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePassword
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:97
 * @route '/teacher/profile/password'
 */
export const updatePassword = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePassword.url(options),
    method: 'put',
})

updatePassword.definition = {
    methods: ["put"],
    url: '/teacher/profile/password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePassword
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:97
 * @route '/teacher/profile/password'
 */
updatePassword.url = (options?: RouteQueryOptions) => {
    return updatePassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePassword
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:97
 * @route '/teacher/profile/password'
 */
updatePassword.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePassword.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePassword
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:97
 * @route '/teacher/profile/password'
 */
    const updatePasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePassword.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherProfileController::updatePassword
 * @see app/Http/Controllers/Teacher/TeacherProfileController.php:97
 * @route '/teacher/profile/password'
 */
        updatePasswordForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePassword.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePassword.form = updatePasswordForm
const TeacherProfileController = { show, update, updatePhoto, updatePassword }

export default TeacherProfileController