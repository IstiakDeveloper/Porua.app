import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::index
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:16
 * @route '/teacher/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
export const markAttendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markAttendance.url(options),
    method: 'get',
})

markAttendance.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/mark',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
markAttendance.url = (options?: RouteQueryOptions) => {
    return markAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
markAttendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: markAttendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
markAttendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: markAttendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
    const markAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: markAttendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
        markAttendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markAttendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::markAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:42
 * @route '/teacher/attendance/mark'
 */
        markAttendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: markAttendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    markAttendance.form = markAttendanceForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::storeAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
export const storeAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendance.url(options),
    method: 'post',
})

storeAttendance.definition = {
    methods: ["post"],
    url: '/teacher/attendance/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::storeAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
storeAttendance.url = (options?: RouteQueryOptions) => {
    return storeAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::storeAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
storeAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::storeAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
    const storeAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAttendance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::storeAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:100
 * @route '/teacher/attendance/store'
 */
        storeAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAttendance.url(options),
            method: 'post',
        })
    
    storeAttendance.form = storeAttendanceForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
    const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
        historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::history
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:163
 * @route '/teacher/attendance/history'
 */
        historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
export const myAttendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myAttendance.url(options),
    method: 'get',
})

myAttendance.definition = {
    methods: ["get","head"],
    url: '/teacher/attendance/my',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
myAttendance.url = (options?: RouteQueryOptions) => {
    return myAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
myAttendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myAttendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
myAttendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myAttendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
    const myAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myAttendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
        myAttendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myAttendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherAttendanceController::myAttendance
 * @see app/Http/Controllers/Teacher/TeacherAttendanceController.php:203
 * @route '/teacher/attendance/my'
 */
        myAttendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myAttendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myAttendance.form = myAttendanceForm
const TeacherAttendanceController = { index, markAttendance, storeAttendance, history, myAttendance }

export default TeacherAttendanceController