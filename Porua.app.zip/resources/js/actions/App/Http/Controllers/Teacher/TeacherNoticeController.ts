import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teacher/notices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::index
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:12
 * @route '/teacher/notices'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
export const show = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teacher/notices/{notice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
show.url = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notice: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    notice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notice: args.notice,
                }

    return show.definition.url
            .replace('{notice}', parsedArgs.notice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
show.get = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
show.head = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
    const showForm = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
        showForm.get = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teacher\TeacherNoticeController::show
 * @see app/Http/Controllers/Teacher/TeacherNoticeController.php:58
 * @route '/teacher/notices/{notice}'
 */
        showForm.head = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const TeacherNoticeController = { index, show }

export default TeacherNoticeController