import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/overdue-fees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\OverdueController::index
 * @see app/Http/Controllers/Fee/OverdueController.php:18
 * @route '/overdue-fees'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Fee\OverdueController::sendReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:84
 * @route '/overdue-fees/reminder'
 */
export const sendReminder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendReminder.url(options),
    method: 'post',
})

sendReminder.definition = {
    methods: ["post"],
    url: '/overdue-fees/reminder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\OverdueController::sendReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:84
 * @route '/overdue-fees/reminder'
 */
sendReminder.url = (options?: RouteQueryOptions) => {
    return sendReminder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\OverdueController::sendReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:84
 * @route '/overdue-fees/reminder'
 */
sendReminder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendReminder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\OverdueController::sendReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:84
 * @route '/overdue-fees/reminder'
 */
    const sendReminderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendReminder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\OverdueController::sendReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:84
 * @route '/overdue-fees/reminder'
 */
        sendReminderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendReminder.url(options),
            method: 'post',
        })
    
    sendReminder.form = sendReminderForm
/**
* @see \App\Http\Controllers\Fee\OverdueController::bulkReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:110
 * @route '/overdue-fees/bulk-reminder'
 */
export const bulkReminder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkReminder.url(options),
    method: 'post',
})

bulkReminder.definition = {
    methods: ["post"],
    url: '/overdue-fees/bulk-reminder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\OverdueController::bulkReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:110
 * @route '/overdue-fees/bulk-reminder'
 */
bulkReminder.url = (options?: RouteQueryOptions) => {
    return bulkReminder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\OverdueController::bulkReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:110
 * @route '/overdue-fees/bulk-reminder'
 */
bulkReminder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkReminder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\OverdueController::bulkReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:110
 * @route '/overdue-fees/bulk-reminder'
 */
    const bulkReminderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkReminder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\OverdueController::bulkReminder
 * @see app/Http/Controllers/Fee/OverdueController.php:110
 * @route '/overdue-fees/bulk-reminder'
 */
        bulkReminderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkReminder.url(options),
            method: 'post',
        })
    
    bulkReminder.form = bulkReminderForm
/**
* @see \App\Http\Controllers\Fee\OverdueController::markPaid
 * @see app/Http/Controllers/Fee/OverdueController.php:139
 * @route '/overdue-fees/mark-paid'
 */
export const markPaid = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markPaid.url(options),
    method: 'post',
})

markPaid.definition = {
    methods: ["post"],
    url: '/overdue-fees/mark-paid',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\OverdueController::markPaid
 * @see app/Http/Controllers/Fee/OverdueController.php:139
 * @route '/overdue-fees/mark-paid'
 */
markPaid.url = (options?: RouteQueryOptions) => {
    return markPaid.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\OverdueController::markPaid
 * @see app/Http/Controllers/Fee/OverdueController.php:139
 * @route '/overdue-fees/mark-paid'
 */
markPaid.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markPaid.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\OverdueController::markPaid
 * @see app/Http/Controllers/Fee/OverdueController.php:139
 * @route '/overdue-fees/mark-paid'
 */
    const markPaidForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markPaid.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\OverdueController::markPaid
 * @see app/Http/Controllers/Fee/OverdueController.php:139
 * @route '/overdue-fees/mark-paid'
 */
        markPaidForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markPaid.url(options),
            method: 'post',
        })
    
    markPaid.form = markPaidForm
const OverdueController = { index, sendReminder, bulkReminder, markPaid }

export default OverdueController