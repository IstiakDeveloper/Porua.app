import FeeTypeController from './FeeTypeController'
import FeeStructureController from './FeeStructureController'
import FeeCollectionController from './FeeCollectionController'
import FeeWaiverController from './FeeWaiverController'
import OverdueController from './OverdueController'
const Fee = {
    FeeTypeController: Object.assign(FeeTypeController, FeeTypeController),
FeeStructureController: Object.assign(FeeStructureController, FeeStructureController),
FeeCollectionController: Object.assign(FeeCollectionController, FeeCollectionController),
FeeWaiverController: Object.assign(FeeWaiverController, FeeWaiverController),
OverdueController: Object.assign(OverdueController, OverdueController),
}

export default Fee