import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/fee-waivers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::index
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:13
 * @route '/fee-waivers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/fee-waivers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::create
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:29
 * @route '/fee-waivers/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::store
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:38
 * @route '/fee-waivers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/fee-waivers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::store
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:38
 * @route '/fee-waivers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::store
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:38
 * @route '/fee-waivers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::store
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:38
 * @route '/fee-waivers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::store
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:38
 * @route '/fee-waivers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
export const edit = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/fee-waivers/{fee_waiver}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
edit.url = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_waiver: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_waiver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_waiver: args.fee_waiver,
                }

    return edit.definition.url
            .replace('{fee_waiver}', parsedArgs.fee_waiver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
edit.get = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
edit.head = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
    const editForm = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
        editForm.get = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::edit
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:60
 * @route '/fee-waivers/{fee_waiver}/edit'
 */
        editForm.head = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
export const update = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/fee-waivers/{fee_waiver}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
update.url = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_waiver: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_waiver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_waiver: args.fee_waiver,
                }

    return update.definition.url
            .replace('{fee_waiver}', parsedArgs.fee_waiver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
update.put = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
update.patch = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
    const updateForm = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
        updateForm.put = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::update
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:72
 * @route '/fee-waivers/{fee_waiver}'
 */
        updateForm.patch = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::destroy
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:94
 * @route '/fee-waivers/{fee_waiver}'
 */
export const destroy = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/fee-waivers/{fee_waiver}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::destroy
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:94
 * @route '/fee-waivers/{fee_waiver}'
 */
destroy.url = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fee_waiver: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fee_waiver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fee_waiver: args.fee_waiver,
                }

    return destroy.definition.url
            .replace('{fee_waiver}', parsedArgs.fee_waiver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Fee\FeeWaiverController::destroy
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:94
 * @route '/fee-waivers/{fee_waiver}'
 */
destroy.delete = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::destroy
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:94
 * @route '/fee-waivers/{fee_waiver}'
 */
    const destroyForm = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Fee\FeeWaiverController::destroy
 * @see app/Http/Controllers/Fee/FeeWaiverController.php:94
 * @route '/fee-waivers/{fee_waiver}'
 */
        destroyForm.delete = (args: { fee_waiver: string | number } | [fee_waiver: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const FeeWaiverController = { index, create, store, edit, update, destroy }

export default FeeWaiverController