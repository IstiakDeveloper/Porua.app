import BookController from './BookController'
import BookIssueController from './BookIssueController'
const Library = {
    BookController: Object.assign(BookController, BookController),
BookIssueController: Object.assign(BookIssueController, BookIssueController),
}

export default Library