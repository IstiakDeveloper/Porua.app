import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parent/notices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::index
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:12
 * @route '/parent/notices'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
export const show = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parent/notices/{notice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
show.url = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notice: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    notice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notice: args.notice,
                }

    return show.definition.url
            .replace('{notice}', parsedArgs.notice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
show.get = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
show.head = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
    const showForm = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
        showForm.get = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentNoticeController::show
 * @see app/Http/Controllers/Parent/ParentNoticeController.php:54
 * @route '/parent/notices/{notice}'
 */
        showForm.head = (args: { notice: string | number } | [notice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const ParentNoticeController = { index, show }

export default ParentNoticeController