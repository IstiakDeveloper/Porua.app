import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parent/exams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentExamController::index
 * @see app/Http/Controllers/Parent/ParentExamController.php:16
 * @route '/parent/exams'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
export const resultDetail = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resultDetail.url(args, options),
    method: 'get',
})

resultDetail.definition = {
    methods: ["get","head"],
    url: '/parent/exams/result/{result}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
resultDetail.url = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: args.result,
                }

    return resultDetail.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
resultDetail.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resultDetail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
resultDetail.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resultDetail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
    const resultDetailForm = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resultDetail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
        resultDetailForm.get = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resultDetail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Parent\ParentExamController::resultDetail
 * @see app/Http/Controllers/Parent/ParentExamController.php:95
 * @route '/parent/exams/result/{result}'
 */
        resultDetailForm.head = (args: { result: string | number } | [result: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resultDetail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resultDetail.form = resultDetailForm
const ParentExamController = { index, resultDetail }

export default ParentExamController