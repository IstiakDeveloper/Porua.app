import ParentDashboardController from './ParentDashboardController'
import ParentProfileController from './ParentProfileController'
import ParentStudentController from './ParentStudentController'
import ParentAttendanceController from './ParentAttendanceController'
import ParentExamController from './ParentExamController'
import ParentFeeController from './ParentFeeController'
import ParentMessageController from './ParentMessageController'
import ParentNoticeController from './ParentNoticeController'
const Parent = {
    ParentDashboardController: Object.assign(ParentDashboardController, ParentDashboardController),
ParentProfileController: Object.assign(ParentProfileController, ParentProfileController),
ParentStudentController: Object.assign(ParentStudentController, ParentStudentController),
ParentAttendanceController: Object.assign(ParentAttendanceController, ParentAttendanceController),
ParentExamController: Object.assign(ParentExamController, ParentExamController),
ParentFeeController: Object.assign(ParentFeeController, ParentFeeController),
ParentMessageController: Object.assign(ParentMessageController, ParentMessageController),
ParentNoticeController: Object.assign(ParentNoticeController, ParentNoticeController),
}

export default Parent