import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/investors',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::index
 * @see app/Http/Controllers/Accounting/InvestorController.php:12
 * @route '/accounting/investors'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/accounting/investors/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::create
 * @see app/Http/Controllers/Accounting/InvestorController.php:46
 * @route '/accounting/investors/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::store
 * @see app/Http/Controllers/Accounting/InvestorController.php:60
 * @route '/accounting/investors'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/investors',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::store
 * @see app/Http/Controllers/Accounting/InvestorController.php:60
 * @route '/accounting/investors'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::store
 * @see app/Http/Controllers/Accounting/InvestorController.php:60
 * @route '/accounting/investors'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::store
 * @see app/Http/Controllers/Accounting/InvestorController.php:60
 * @route '/accounting/investors'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::store
 * @see app/Http/Controllers/Accounting/InvestorController.php:60
 * @route '/accounting/investors'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
export const show = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/accounting/investors/{investor}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
show.url = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { investor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { investor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    investor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        investor: typeof args.investor === 'object'
                ? args.investor.id
                : args.investor,
                }

    return show.definition.url
            .replace('{investor}', parsedArgs.investor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
show.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
show.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
    const showForm = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
        showForm.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::show
 * @see app/Http/Controllers/Accounting/InvestorController.php:84
 * @route '/accounting/investors/{investor}'
 */
        showForm.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
export const edit = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/accounting/investors/{investor}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
edit.url = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { investor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { investor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    investor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        investor: typeof args.investor === 'object'
                ? args.investor.id
                : args.investor,
                }

    return edit.definition.url
            .replace('{investor}', parsedArgs.investor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
edit.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
edit.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
    const editForm = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
        editForm.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::edit
 * @see app/Http/Controllers/Accounting/InvestorController.php:105
 * @route '/accounting/investors/{investor}/edit'
 */
        editForm.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
export const update = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/accounting/investors/{investor}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
update.url = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { investor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { investor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    investor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        investor: typeof args.investor === 'object'
                ? args.investor.id
                : args.investor,
                }

    return update.definition.url
            .replace('{investor}', parsedArgs.investor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
update.put = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
update.patch = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
    const updateForm = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
        updateForm.put = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::update
 * @see app/Http/Controllers/Accounting/InvestorController.php:114
 * @route '/accounting/investors/{investor}'
 */
        updateForm.patch = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::destroy
 * @see app/Http/Controllers/Accounting/InvestorController.php:138
 * @route '/accounting/investors/{investor}'
 */
export const destroy = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/accounting/investors/{investor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::destroy
 * @see app/Http/Controllers/Accounting/InvestorController.php:138
 * @route '/accounting/investors/{investor}'
 */
destroy.url = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { investor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { investor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    investor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        investor: typeof args.investor === 'object'
                ? args.investor.id
                : args.investor,
                }

    return destroy.definition.url
            .replace('{investor}', parsedArgs.investor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::destroy
 * @see app/Http/Controllers/Accounting/InvestorController.php:138
 * @route '/accounting/investors/{investor}'
 */
destroy.delete = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::destroy
 * @see app/Http/Controllers/Accounting/InvestorController.php:138
 * @route '/accounting/investors/{investor}'
 */
    const destroyForm = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::destroy
 * @see app/Http/Controllers/Accounting/InvestorController.php:138
 * @route '/accounting/investors/{investor}'
 */
        destroyForm.delete = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
export const ledger = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ledger.url(args, options),
    method: 'get',
})

ledger.definition = {
    methods: ["get","head"],
    url: '/accounting/investors/{investor}/ledger',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
ledger.url = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { investor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { investor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    investor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        investor: typeof args.investor === 'object'
                ? args.investor.id
                : args.investor,
                }

    return ledger.definition.url
            .replace('{investor}', parsedArgs.investor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
ledger.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ledger.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
ledger.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ledger.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
    const ledgerForm = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ledger.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
        ledgerForm.get = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ledger.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\InvestorController::ledger
 * @see app/Http/Controllers/Accounting/InvestorController.php:155
 * @route '/accounting/investors/{investor}/ledger'
 */
        ledgerForm.head = (args: { investor: number | { id: number } } | [investor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ledger.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ledger.form = ledgerForm
const InvestorController = { index, create, store, show, edit, update, destroy, ledger }

export default InvestorController