import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/funds',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\FundController::index
 * @see app/Http/Controllers/Accounting/FundController.php:16
 * @route '/accounting/funds'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\FundController::fundIn
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
export const fundIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fundIn.url(options),
    method: 'post',
})

fundIn.definition = {
    methods: ["post"],
    url: '/accounting/funds/in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::fundIn
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
fundIn.url = (options?: RouteQueryOptions) => {
    return fundIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::fundIn
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
fundIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fundIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::fundIn
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
    const fundInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: fundIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::fundIn
 * @see app/Http/Controllers/Accounting/FundController.php:50
 * @route '/accounting/funds/in'
 */
        fundInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: fundIn.url(options),
            method: 'post',
        })
    
    fundIn.form = fundInForm
/**
* @see \App\Http\Controllers\Accounting\FundController::fundOut
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
export const fundOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fundOut.url(options),
    method: 'post',
})

fundOut.definition = {
    methods: ["post"],
    url: '/accounting/funds/out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::fundOut
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
fundOut.url = (options?: RouteQueryOptions) => {
    return fundOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::fundOut
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
fundOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fundOut.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::fundOut
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
    const fundOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: fundOut.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::fundOut
 * @see app/Http/Controllers/Accounting/FundController.php:116
 * @route '/accounting/funds/out'
 */
        fundOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: fundOut.url(options),
            method: 'post',
        })
    
    fundOut.form = fundOutForm
/**
* @see \App\Http\Controllers\Accounting\FundController::editTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:196
 * @route '/accounting/funds/transactions/{transaction}'
 */
export const editTransaction = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: editTransaction.url(args, options),
    method: 'put',
})

editTransaction.definition = {
    methods: ["put"],
    url: '/accounting/funds/transactions/{transaction}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::editTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:196
 * @route '/accounting/funds/transactions/{transaction}'
 */
editTransaction.url = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transaction: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    transaction: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transaction: args.transaction,
                }

    return editTransaction.definition.url
            .replace('{transaction}', parsedArgs.transaction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::editTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:196
 * @route '/accounting/funds/transactions/{transaction}'
 */
editTransaction.put = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: editTransaction.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::editTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:196
 * @route '/accounting/funds/transactions/{transaction}'
 */
    const editTransactionForm = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editTransaction.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::editTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:196
 * @route '/accounting/funds/transactions/{transaction}'
 */
        editTransactionForm.put = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editTransaction.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    editTransaction.form = editTransactionForm
/**
* @see \App\Http\Controllers\Accounting\FundController::deleteTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:245
 * @route '/accounting/funds/transactions/{transaction}'
 */
export const deleteTransaction = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTransaction.url(args, options),
    method: 'delete',
})

deleteTransaction.definition = {
    methods: ["delete"],
    url: '/accounting/funds/transactions/{transaction}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\FundController::deleteTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:245
 * @route '/accounting/funds/transactions/{transaction}'
 */
deleteTransaction.url = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transaction: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    transaction: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transaction: args.transaction,
                }

    return deleteTransaction.definition.url
            .replace('{transaction}', parsedArgs.transaction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\FundController::deleteTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:245
 * @route '/accounting/funds/transactions/{transaction}'
 */
deleteTransaction.delete = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTransaction.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\FundController::deleteTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:245
 * @route '/accounting/funds/transactions/{transaction}'
 */
    const deleteTransactionForm = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteTransaction.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\FundController::deleteTransaction
 * @see app/Http/Controllers/Accounting/FundController.php:245
 * @route '/accounting/funds/transactions/{transaction}'
 */
        deleteTransactionForm.delete = (args: { transaction: string | number } | [transaction: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteTransaction.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteTransaction.form = deleteTransactionForm
const FundController = { index, fundIn, fundOut, editTransaction, deleteTransaction }

export default FundController