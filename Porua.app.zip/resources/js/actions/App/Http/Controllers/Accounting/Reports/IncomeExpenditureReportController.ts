import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/income-expenditure',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\IncomeExpenditureReportController::index
 * @see app/Http/Controllers/Accounting/Reports/IncomeExpenditureReportController.php:15
 * @route '/accounting/reports/income-expenditure'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const IncomeExpenditureReportController = { index }

export default IncomeExpenditureReportController