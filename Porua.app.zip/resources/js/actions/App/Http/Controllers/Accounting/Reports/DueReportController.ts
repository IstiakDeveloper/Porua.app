import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/due-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\DueReportController::index
 * @see app/Http/Controllers/Accounting/Reports/DueReportController.php:48
 * @route '/accounting/reports/due-report'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DueReportController = { index }

export default DueReportController