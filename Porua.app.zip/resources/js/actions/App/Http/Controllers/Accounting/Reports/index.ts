import BankReportController from './BankReportController'
import ReceiptPaymentReportController from './ReceiptPaymentReportController'
import IncomeExpenditureReportController from './IncomeExpenditureReportController'
import BalanceSheetReportController from './BalanceSheetReportController'
import DueReportController from './DueReportController'
import StaffWelfareLoanLedgerReportController from './StaffWelfareLoanLedgerReportController'
const Reports = {
    BankReportController: Object.assign(BankReportController, BankReportController),
ReceiptPaymentReportController: Object.assign(ReceiptPaymentReportController, ReceiptPaymentReportController),
IncomeExpenditureReportController: Object.assign(IncomeExpenditureReportController, IncomeExpenditureReportController),
BalanceSheetReportController: Object.assign(BalanceSheetReportController, BalanceSheetReportController),
DueReportController: Object.assign(DueReportController, DueReportController),
StaffWelfareLoanLedgerReportController: Object.assign(StaffWelfareLoanLedgerReportController, StaffWelfareLoanLedgerReportController),
}

export default Reports