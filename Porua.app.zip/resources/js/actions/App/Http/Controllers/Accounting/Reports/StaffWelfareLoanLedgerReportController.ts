import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/staff-welfare-loan-ledger',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\StaffWelfareLoanLedgerReportController::index
 * @see app/Http/Controllers/Accounting/Reports/StaffWelfareLoanLedgerReportController.php:15
 * @route '/accounting/reports/staff-welfare-loan-ledger'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const StaffWelfareLoanLedgerReportController = { index }

export default StaffWelfareLoanLedgerReportController