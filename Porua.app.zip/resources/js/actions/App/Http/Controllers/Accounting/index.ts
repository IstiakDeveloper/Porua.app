import DashboardController from './DashboardController'
import AccountController from './AccountController'
import TransactionController from './TransactionController'
import FixedAssetController from './FixedAssetController'
import ExpenseCategoryController from './ExpenseCategoryController'
import IncomeCategoryController from './IncomeCategoryController'
import InvestorController from './InvestorController'
import FundController from './FundController'
import StaffWelfareLoanController from './StaffWelfareLoanController'
import Reports from './Reports'
const Accounting = {
    DashboardController: Object.assign(DashboardController, DashboardController),
AccountController: Object.assign(AccountController, AccountController),
TransactionController: Object.assign(TransactionController, TransactionController),
FixedAssetController: Object.assign(FixedAssetController, FixedAssetController),
ExpenseCategoryController: Object.assign(ExpenseCategoryController, ExpenseCategoryController),
IncomeCategoryController: Object.assign(IncomeCategoryController, IncomeCategoryController),
InvestorController: Object.assign(InvestorController, InvestorController),
FundController: Object.assign(FundController, FundController),
StaffWelfareLoanController: Object.assign(StaffWelfareLoanController, StaffWelfareLoanController),
Reports: Object.assign(Reports, Reports),
}

export default Accounting