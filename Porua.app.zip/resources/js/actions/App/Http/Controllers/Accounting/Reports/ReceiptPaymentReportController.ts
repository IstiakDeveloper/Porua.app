import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/reports/receipt-payment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\Reports\ReceiptPaymentReportController::index
 * @see app/Http/Controllers/Accounting/Reports/ReceiptPaymentReportController.php:16
 * @route '/accounting/reports/receipt-payment'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const ReceiptPaymentReportController = { index }

export default ReceiptPaymentReportController