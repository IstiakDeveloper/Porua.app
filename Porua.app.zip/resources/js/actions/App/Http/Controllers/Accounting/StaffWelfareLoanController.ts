import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting/welfare-loans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::index
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:56
 * @route '/accounting/welfare-loans'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
export const show = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/accounting/welfare-loans/{loan}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return show.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
show.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
    const showForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
        showForm.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::show
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:163
 * @route '/accounting/welfare-loans/{loan}'
 */
        showForm.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::store
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:243
 * @route '/accounting/welfare-loans'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::editLoan
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
export const editLoan = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: editLoan.url(args, options),
    method: 'put',
})

editLoan.definition = {
    methods: ["put"],
    url: '/accounting/welfare-loans/{loan}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::editLoan
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
editLoan.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return editLoan.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::editLoan
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
editLoan.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: editLoan.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::editLoan
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
    const editLoanForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editLoan.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::editLoan
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:561
 * @route '/accounting/welfare-loans/{loan}'
 */
        editLoanForm.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editLoan.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    editLoan.form = editLoanForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::addDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
export const addDonation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addDonation.url(options),
    method: 'post',
})

addDonation.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/donations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::addDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
addDonation.url = (options?: RouteQueryOptions) => {
    return addDonation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::addDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
addDonation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addDonation.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::addDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
    const addDonationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addDonation.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::addDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:485
 * @route '/accounting/welfare-loans/donations'
 */
        addDonationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addDonation.url(options),
            method: 'post',
        })
    
    addDonation.form = addDonationForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::deleteDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
export const deleteDonation = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteDonation.url(args, options),
    method: 'delete',
})

deleteDonation.definition = {
    methods: ["delete"],
    url: '/accounting/welfare-loans/donations/{donation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::deleteDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
deleteDonation.url = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { donation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    donation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        donation: args.donation,
                }

    return deleteDonation.definition.url
            .replace('{donation}', parsedArgs.donation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::deleteDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
deleteDonation.delete = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteDonation.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::deleteDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
    const deleteDonationForm = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteDonation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::deleteDonation
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:709
 * @route '/accounting/welfare-loans/donations/{donation}'
 */
        deleteDonationForm.delete = (args: { donation: string | number } | [donation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteDonation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteDonation.form = deleteDonationForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::payInstallment
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
export const payInstallment = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payInstallment.url(args, options),
    method: 'post',
})

payInstallment.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/installments/{installment}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::payInstallment
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
payInstallment.url = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { installment: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    installment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        installment: args.installment,
                }

    return payInstallment.definition.url
            .replace('{installment}', parsedArgs.installment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::payInstallment
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
payInstallment.post = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payInstallment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::payInstallment
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
    const payInstallmentForm = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: payInstallment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::payInstallment
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:356
 * @route '/accounting/welfare-loans/installments/{installment}/pay'
 */
        payInstallmentForm.post = (args: { installment: string | number } | [installment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: payInstallment.url(args, options),
            method: 'post',
        })
    
    payInstallment.form = payInstallmentForm
/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
export const cancel = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/accounting/welfare-loans/{loan}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
cancel.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loan: args.loan,
                }

    return cancel.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
cancel.post = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
    const cancelForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Accounting\StaffWelfareLoanController::cancel
 * @see app/Http/Controllers/Accounting/StaffWelfareLoanController.php:443
 * @route '/accounting/welfare-loans/{loan}/cancel'
 */
        cancelForm.post = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const StaffWelfareLoanController = { index, show, store, editLoan, addDonation, deleteDonation, payInstallment, cancel }

export default StaffWelfareLoanController