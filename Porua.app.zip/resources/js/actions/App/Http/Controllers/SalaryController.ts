import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/salaries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalaryController::index
 * @see app/Http/Controllers/SalaryController.php:14
 * @route '/salaries'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/salaries/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalaryController::create
 * @see app/Http/Controllers/SalaryController.php:32
 * @route '/salaries/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\SalaryController::store
 * @see app/Http/Controllers/SalaryController.php:42
 * @route '/salaries'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/salaries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalaryController::store
 * @see app/Http/Controllers/SalaryController.php:42
 * @route '/salaries'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::store
 * @see app/Http/Controllers/SalaryController.php:42
 * @route '/salaries'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalaryController::store
 * @see app/Http/Controllers/SalaryController.php:42
 * @route '/salaries'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalaryController::store
 * @see app/Http/Controllers/SalaryController.php:42
 * @route '/salaries'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
export const show = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/salaries/{salary}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
show.url = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salary: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salary: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salary: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salary: typeof args.salary === 'object'
                ? args.salary.id
                : args.salary,
                }

    return show.definition.url
            .replace('{salary}', parsedArgs.salary.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
show.get = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
show.head = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
    const showForm = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
        showForm.get = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalaryController::show
 * @see app/Http/Controllers/SalaryController.php:80
 * @route '/salaries/{salary}'
 */
        showForm.head = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
export const edit = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/salaries/{salary}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
edit.url = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salary: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salary: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salary: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salary: typeof args.salary === 'object'
                ? args.salary.id
                : args.salary,
                }

    return edit.definition.url
            .replace('{salary}', parsedArgs.salary.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
edit.get = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
edit.head = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
    const editForm = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
        editForm.get = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalaryController::edit
 * @see app/Http/Controllers/SalaryController.php:91
 * @route '/salaries/{salary}/edit'
 */
        editForm.head = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
export const update = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/salaries/{salary}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
update.url = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salary: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salary: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salary: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salary: typeof args.salary === 'object'
                ? args.salary.id
                : args.salary,
                }

    return update.definition.url
            .replace('{salary}', parsedArgs.salary.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
update.put = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
update.patch = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
    const updateForm = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
        updateForm.put = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\SalaryController::update
 * @see app/Http/Controllers/SalaryController.php:102
 * @route '/salaries/{salary}'
 */
        updateForm.patch = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SalaryController::destroy
 * @see app/Http/Controllers/SalaryController.php:127
 * @route '/salaries/{salary}'
 */
export const destroy = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/salaries/{salary}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SalaryController::destroy
 * @see app/Http/Controllers/SalaryController.php:127
 * @route '/salaries/{salary}'
 */
destroy.url = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salary: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salary: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salary: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salary: typeof args.salary === 'object'
                ? args.salary.id
                : args.salary,
                }

    return destroy.definition.url
            .replace('{salary}', parsedArgs.salary.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalaryController::destroy
 * @see app/Http/Controllers/SalaryController.php:127
 * @route '/salaries/{salary}'
 */
destroy.delete = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SalaryController::destroy
 * @see app/Http/Controllers/SalaryController.php:127
 * @route '/salaries/{salary}'
 */
    const destroyForm = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalaryController::destroy
 * @see app/Http/Controllers/SalaryController.php:127
 * @route '/salaries/{salary}'
 */
        destroyForm.delete = (args: { salary: number | { id: number } } | [salary: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SalaryController = { index, create, store, show, edit, update, destroy }

export default SalaryController