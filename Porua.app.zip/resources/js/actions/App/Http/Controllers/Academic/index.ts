import AcademicYearController from './AcademicYearController'
import ClassController from './ClassController'
import SectionController from './SectionController'
import SubjectController from './SubjectController'
const Academic = {
    AcademicYearController: Object.assign(AcademicYearController, AcademicYearController),
ClassController: Object.assign(ClassController, ClassController),
SectionController: Object.assign(SectionController, SectionController),
SubjectController: Object.assign(SubjectController, SubjectController),
}

export default Academic