import SalaryPaymentController from './SalaryPaymentController'
import ProvidentFundController from './ProvidentFundController'
const Salary = {
    SalaryPaymentController: Object.assign(SalaryPaymentController, SalaryPaymentController),
ProvidentFundController: Object.assign(ProvidentFundController, ProvidentFundController),
}

export default Salary